# Esthemax Academy — Espace commercial

Refonte de l’espace commercial Esthemax avec frontend React/Vite et backend Laravel API.

## Fonctionnalités livrées

- Connexion commerciale avec les identifiants `sihamf`, `ayab`, `majdaa`, `houdal`.
- Questionnaire initial obligatoire en réponses texte libre avant l’accès au parcours.
- Parcours de formation J1 le 23/09/2026, J2 le 24/09/2026 et J3 le 25/09/2026.
- Quiz QCM à la fin de chaque journée, avec calcul du score.
- Lien PDF de formation servi par le backend via `TRAINING_PDF_URL`.
- Connexion admin avec tableau de rapports par commercial : réponses du questionnaire initial, réponses QCM et corrections.

## Comptes de démonstration Laravel

- `sihamf` / `Esthemax2026!`
- `ayab` / `Esthemax2026!`
- `majdaa` / `Esthemax2026!`
- `houdal` / `Esthemax2026!`
- `admin` / `AdminEsthemax2026!`

Changez les mots de passe avant toute mise en production.

## Démarrage frontend

```bash
npm install
cp .env.example .env.local
# renseigner VITE_API_BASE_URL=http://localhost:8000/api/v1
npm run dev
```

## Démarrage backend

Voir [`laravel-backend/README.md`](laravel-backend/README.md). Le lien PDF définitif peut être placé dans `.env` avec `TRAINING_PDF_URL`.

Le build frontend a été vérifié avec `npm run lint` et `npm run build`.
