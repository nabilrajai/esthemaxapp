# Esthemax Academy — Backend Laravel

API Laravel 11 destinée à l’espace commercial Esthemax.

## Installation

```bash
composer create-project laravel/laravel .
composer require laravel/sanctum
php artisan migrate --seed
php artisan serve
```

Copier `.env.example` vers `.env`, puis définir `FRONTEND_URL` et `TRAINING_PDF_URL`.

## Comptes initiaux

| Rôle | Identifiant | Mot de passe |
|---|---|---|
| Commercial | `sihamf` | `Esthemax2026!` |
| Commercial | `ayab` | `Esthemax2026!` |
| Commercial | `majdaa` | `Esthemax2026!` |
| Commercial | `houdal` | `Esthemax2026!` |
| Admin | `admin` | `AdminEsthemax2026!` |

Les mots de passe doivent être changés en production.

## Contrats principaux

- `POST /api/v1/login` avec `{login, password}`
- `GET /api/v1/commercial/bootstrap`
- `GET /api/v1/commercial/training-days`
- `GET /api/v1/commercial/training-days/{day}/pdf`
- `GET/POST /api/v1/commercial/onboarding-assessment`
- `GET /api/v1/commercial/training-days/{day}/assessment`
- `POST /api/v1/commercial/training-days/{day}/assessment/submit`
- `GET /api/v1/admin/reports`
- `GET /api/v1/admin/reports/{commercial}`

Le PDF est volontairement piloté par `TRAINING_PDF_URL` afin de pouvoir recevoir le lien définitif sans modifier le code.
