<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Answer;
use App\Models\User;
use Illuminate\Http\Request;

class AdminReportController extends Controller
{
    public function index(Request $request)
    {
        abort_unless($request->user()->role === 'admin', 403);
        return User::where('role', 'commercial')->with(['answers.question.trainingDay'])->get()->map(fn ($user) => $this->format($user));
    }

    public function show(Request $request, User $user)
    {
        abort_unless($request->user()->role === 'admin' && $user->role === 'commercial', 403);
        return $this->format($user->load(['answers.question.trainingDay']));
    }

    private function format(User $user): array
    {
        $answers = $user->answers; $dayAnswers = $answers->filter(fn ($a) => $a->question->scope === 'day');
        return ['commercial' => $user, 'onboarding_answers' => $answers->filter(fn ($a) => $a->question->scope === 'onboarding')->values(), 'quiz_answers' => $dayAnswers->values(), 'score' => $dayAnswers->where('is_correct', true)->count(), 'answered' => $dayAnswers->count()];
    }
}
