<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $data = $request->validate(['login' => ['required', 'string'], 'password' => ['required', 'string']]);
        $user = User::where('login', strtolower(trim($data['login'])))->first();
        if (!$user || !Hash::check($data['password'], $user->password)) {
            throw ValidationException::withMessages(['login' => ['Identifiants incorrects.']]);
        }
        if ($user->status !== 'active') {
            return response()->json(['message' => 'Compte bloqué ou inactif.', 'account_status' => $user->status], 403);
        }
        $user->forceFill(['last_login_at' => now()])->save();
        return ['token' => $user->createToken('academy')->plainTextToken, 'user' => $user];
    }

    public function me(Request $request) { return $request->user(); }
    public function logout(Request $request) { $request->user()->currentAccessToken()?->delete(); return ['success' => true]; }
}
