<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Answer;
use App\Models\Question;
use App\Models\TrainingDay;
use Illuminate\Http\Request;

class CommercialController extends Controller
{
    public function bootstrap(Request $request)
    {
        return ['user' => $request->user(), 'training_days' => TrainingDay::orderBy('sort_order')->get(), 'onboarding' => Question::where('scope', 'onboarding')->orderBy('sort_order')->get()];
    }

    public function days() { return TrainingDay::orderBy('sort_order')->get(); }

    public function pdf(TrainingDay $trainingDay)
    {
        return ['code' => $trainingDay->code, 'title' => $trainingDay->title, 'pdf_url' => $trainingDay->pdf_url ?: config('app.training_pdf_url', env('TRAINING_PDF_URL'))];
    }

    public function onboarding(Request $request)
    {
        $questions = Question::where('scope', 'onboarding')->pluck('id');
        $data = $request->validate(['answers' => ['required', 'array'], 'answers.*' => ['nullable', 'string']]);
        foreach ($data['answers'] as $questionId => $text) {
            if ($questions->contains((int) $questionId)) Answer::updateOrCreate(['user_id' => $request->user()->id, 'question_id' => $questionId], ['answer_text' => $text, 'submitted_at' => now()]);
        }
        return ['success' => true, 'message' => 'Questionnaire initial enregistré.'];
    }

    public function assessment(TrainingDay $trainingDay) { return ['training_day' => $trainingDay, 'questions' => $trainingDay->questions()->where('scope', 'day')->orderBy('sort_order')->get()]; }

    public function submitAssessment(Request $request, TrainingDay $trainingDay)
    {
        $data = $request->validate(['answers' => ['required', 'array']]);
        $questions = $trainingDay->questions()->where('scope', 'day')->get(); $correct = 0;
        foreach ($questions as $question) {
            $value = $data['answers'][$question->id] ?? null;
            $isCorrect = $question->correct_answer !== null && (string) $value === (string) $question->correct_answer;
            if ($isCorrect) $correct++;
            Answer::updateOrCreate(['user_id' => $request->user()->id, 'question_id' => $question->id], ['answer_options' => is_array($value) ? $value : null, 'answer_text' => is_string($value) ? $value : null, 'is_correct' => $isCorrect, 'submitted_at' => now()]);
        }
        $total = $questions->count(); $percentage = $total ? round($correct / $total * 100) : 0;
        return ['score' => $correct, 'total_questions' => $total, 'score_percentage' => $percentage, 'passed' => $percentage >= 70, 'message' => 'Quiz enregistré avec succès.'];
    }
}
