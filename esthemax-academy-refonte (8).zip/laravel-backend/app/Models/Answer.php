<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Answer extends Model { protected $fillable=['user_id','question_id','answer_text','answer_options','is_correct','submitted_at']; protected $casts=['answer_options'=>'array','is_correct'=>'boolean','submitted_at'=>'datetime']; public function question(){return $this->belongsTo(Question::class);} public function user(){return $this->belongsTo(User::class);} }
