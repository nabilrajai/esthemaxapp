<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Question extends Model { protected $fillable=['training_day_id','scope','type','question_text','options','correct_answer','sort_order']; protected $casts=['options'=>'array']; public function trainingDay(){return $this->belongsTo(TrainingDay::class);} }
