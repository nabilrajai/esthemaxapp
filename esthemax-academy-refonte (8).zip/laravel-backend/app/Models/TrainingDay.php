<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class TrainingDay extends Model { protected $fillable=['code','title','scheduled_date','description','pdf_url','sort_order']; protected $casts=['scheduled_date'=>'date']; public function questions(){return $this->hasMany(Question::class);} }
