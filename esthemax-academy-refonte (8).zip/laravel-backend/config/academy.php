<?php
return ['training_pdf_url' => env('TRAINING_PDF_URL')];
