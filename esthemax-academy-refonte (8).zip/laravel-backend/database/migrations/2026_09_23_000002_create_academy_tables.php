<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('training_days', function (Blueprint $table) {
            $table->id();
            $table->string('code', 2)->unique();
            $table->string('title');
            $table->date('scheduled_date');
            $table->text('description')->nullable();
            $table->string('pdf_url')->nullable();
            $table->unsignedInteger('sort_order')->default(1);
            $table->timestamps();
        });
        Schema::create('questions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('training_day_id')->nullable()->constrained()->cascadeOnDelete();
            $table->enum('scope', ['onboarding', 'day'])->default('day');
            $table->enum('type', ['text', 'single_choice', 'multiple_choice']);
            $table->text('question_text');
            $table->json('options')->nullable();
            $table->string('correct_answer')->nullable();
            $table->unsignedInteger('sort_order')->default(1);
            $table->timestamps();
        });
        Schema::create('answers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('question_id')->constrained()->cascadeOnDelete();
            $table->text('answer_text')->nullable();
            $table->json('answer_options')->nullable();
            $table->boolean('is_correct')->nullable();
            $table->timestamp('submitted_at')->nullable();
            $table->timestamps();
            $table->unique(['user_id', 'question_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('answers');
        Schema::dropIfExists('questions');
        Schema::dropIfExists('training_days');
    }
};
