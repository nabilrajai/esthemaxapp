<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\CommercialController;
use App\Http\Controllers\Api\AdminReportController;
Route::prefix('v1')->group(function(){
 Route::post('/login',[AuthController::class,'login']);
 Route::middleware('auth:sanctum')->group(function(){
  Route::get('/user',[AuthController::class,'me']); Route::post('/logout',[AuthController::class,'logout']);
  Route::prefix('commercial')->group(function(){ Route::get('/bootstrap',[CommercialController::class,'bootstrap']); Route::get('/training-days',[CommercialController::class,'days']); Route::get('/training-days/{trainingDay}/pdf',[CommercialController::class,'pdf']); Route::get('/onboarding-assessment',[fn()=>['questions'=>\App\Models\Question::where('scope','onboarding')->orderBy('sort_order')->get()]]); Route::post('/onboarding-assessment',[CommercialController::class,'onboarding']); Route::get('/training-days/{trainingDay}/assessment',[CommercialController::class,'assessment']); Route::post('/training-days/{trainingDay}/assessment/submit',[CommercialController::class,'submitAssessment']); });
  Route::prefix('admin')->group(function(){Route::get('/reports',[AdminReportController::class,'index']); Route::get('/reports/{user}',[AdminReportController::class,'show']);});
 });
});
