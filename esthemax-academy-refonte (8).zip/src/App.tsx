/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { AuthProvider } from './context/AuthContext';
import CommercialRoute from './components/commercial/CommercialRoute';
import CommercialLayout from './components/commercial/CommercialLayout';

// Pages
import LoginPage from './pages/LoginPage';
import BlockedAccountPage from './pages/BlockedAccountPage';
import QrRedirectPage from './pages/QrRedirectPage';
import CommercialDashboardPage from './pages/commercial/CommercialDashboardPage';
import CommercialTrainingDaysPage from './pages/commercial/CommercialTrainingDaysPage';
import CommercialTrainingDayPage from './pages/commercial/CommercialTrainingDayPage';
import CommercialModuleViewerPage from './pages/commercial/CommercialModuleViewerPage';
import CommercialAssessmentPage from './pages/commercial/CommercialAssessmentPage';
import CommercialEvaluationsPage from './pages/commercial/CommercialEvaluationsPage';
import CommercialProgressPage from './pages/commercial/CommercialProgressPage';
import CommercialProfilePage from './pages/commercial/CommercialProfilePage';
import AdminReportsPage from './pages/AdminReportsPage';
import CommercialOnboardingPage from './pages/commercial/CommercialOnboardingPage';
import { useAuth } from './context/AuthContext';

// Configure TanStack React Query Client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      gcTime: 15 * 60 * 1000,
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <HashRouter>
          <Routes>
            {/* Public Routes */}
            <Route path="/login" element={<LoginPage />} />
            <Route path="/blocked" element={<BlockedAccountPage />} />
            <Route path="/admin" element={<AdminRoute><AdminReportsPage /></AdminRoute>} />

            {/* QR / NFC Entry Points */}
            <Route path="/qr/:code" element={<QrRedirectPage />} />
            <Route path="/nfc/:code" element={<QrRedirectPage />} />

            {/* Commercial Portal - Protected with CommercialRoute & CommercialLayout */}
            <Route
              path="/commercial"
              element={
                <CommercialRoute>
                  <CommercialLayout />
                </CommercialRoute>
              }
            >
              <Route index element={<CommercialDashboardPage />} />
              <Route path="onboarding" element={<CommercialOnboardingPage />} />
              <Route path="training-days" element={<CommercialTrainingDaysPage />} />
              <Route path="training-days/:trainingDayId" element={<CommercialTrainingDayPage />} />
              <Route
                path="training-days/:trainingDayId/modules/:moduleId"
                element={<CommercialModuleViewerPage />}
              />
              <Route
                path="training-days/:trainingDayId/assessment"
                element={<CommercialAssessmentPage />}
              />
              <Route path="evaluations" element={<CommercialEvaluationsPage />} />
              <Route path="progress" element={<CommercialProgressPage />} />
              <Route path="profile" element={<CommercialProfilePage />} />
            </Route>

            {/* Root & Catch-all: Route commercial users cleanly */}
            <Route path="/" element={<Navigate to="/commercial" replace />} />
            <Route path="*" element={<Navigate to="/commercial" replace />} />
          </Routes>
        </HashRouter>
      </AuthProvider>
    </QueryClientProvider>
  );
}

function AdminRoute({ children }: { children: React.ReactNode }) {
  const { isAuthenticated, isAdmin } = useAuth();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  if (!isAdmin) return <Navigate to="/commercial" replace />;
  return <>{children}</>;
}
