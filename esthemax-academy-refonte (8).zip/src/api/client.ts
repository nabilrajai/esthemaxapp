/**
 * Esthemax Academy - API Client
 * Configured for Laravel Sanctum REST API.
 * Normalizes responses ({ data: ... } vs direct objects) and handles token injection.
 */

export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL || 'https://esthemax.birdeye-intelligence.ma/Backend/api/v1';

// Les fallbacks locaux ne sont autorisés que si le développeur l'active explicitement.
// En production, toute erreur API doit être visible dans l'interface.
export const isDemoMode = import.meta.env.VITE_DEMO_MODE === 'true';

export class ApiError extends Error {
  status: number;
  data: unknown;

  constructor(message: string, status: number, data?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

export function getAuthToken(): string | null {
  return localStorage.getItem('esthemax_auth_token');
}

export function setAuthToken(token: string | null): void {
  if (token) {
    localStorage.setItem('esthemax_auth_token', token);
  } else {
    localStorage.removeItem('esthemax_auth_token');
  }
}

/**
 * Normalizes Laravel API response payloads
 */
export function normalizeLaravelResponse<T>(json: any): T {
  if (!json) return json as T;
  // If wrapped in { data: ... }
  if (typeof json === 'object' && 'data' in json && json.data !== undefined) {
    return json.data as T;
  }
  return json as T;
}

export interface RequestOptions extends RequestInit {
  params?: Record<string, string | number | boolean | undefined>;
}

export async function apiClient<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
  const { params, headers, ...customConfig } = options;

  let url = `${API_BASE_URL.replace(/\/$/, '')}/${endpoint.replace(/^\//, '')}`;

  if (params) {
    const searchParams = new URLSearchParams();
    Object.entries(params).forEach(([key, val]) => {
      if (val !== undefined && val !== null) {
        searchParams.append(key, String(val));
      }
    });
    const queryString = searchParams.toString();
    if (queryString) {
      url += (url.includes('?') ? '&' : '?') + queryString;
    }
  }

  const token = getAuthToken();
  const defaultHeaders: Record<string, string> = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    'X-Requested-With': 'XMLHttpRequest',
  };

  if (token) {
    defaultHeaders['Authorization'] = `Bearer ${token}`;
  }

  const config: RequestInit = {
    ...customConfig,
    headers: {
      ...defaultHeaders,
      ...headers,
    },
  };

  try {
    const response = await fetch(url, config);

    // Handle 401 Unauthorized -> Session Expired
    if (response.status === 401) {
      setAuthToken(null);
      window.dispatchEvent(new CustomEvent('esthemax:session-expired'));
      throw new ApiError('Votre session a expiré. Veuillez vous reconnecter.', 401);
    }

    // Handle 403 Forbidden -> Account Blocked or Access Denied
    if (response.status === 403) {
      const errBody = await response.json().catch(() => null);
      throw new ApiError(
        errBody?.message || 'Accès refusé. Votre compte est bloqué ou vous n’avez pas les droits nécessaires.',
        403,
        errBody
      );
    }

    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      const message = errorData?.message || `Erreur serveur (${response.status})`;
      throw new ApiError(message, response.status, errorData);
    }

    const data = await response.json();
    return normalizeLaravelResponse<T>(data);
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }
    // Network or CORS error
    throw new ApiError(
      'Impossible de contacter le serveur de formation Esthemax. Veuillez vérifier votre connexion.',
      0,
      error
    );
  }
}
