/**
 * Esthemax Academy - Commercial API Hub
 */

export * from './client';
export * from './commercialTrainingApi';
export * from './commercialAssessmentApi';
export * from './commercialProgressApi';

import { apiClient, setAuthToken, isDemoMode } from './client';
import { User } from '../types';
import { DEMO_USERS } from '../data/mockData';

export interface LoginResponse {
  user: User;
  token: string;
}

export async function loginUser(
  login: string,
  password: string,
  remember = false
): Promise<LoginResponse> {
  try {
    const res = await apiClient<LoginResponse>('/login', {
      method: 'POST',
      body: JSON.stringify({ login, password, remember }),
    });
    if (res && res.token && res.user) {
      setAuthToken(res.token);
      return res;
    }
    if (!isDemoMode) throw new Error('Réponse API de connexion invalide : token ou utilisateur manquant.');
  } catch (err: any) {
    // If backend returns 403 or specific validation error from Laravel, preserve it
    if (err.status === 403 || err.status === 422) {
      throw err;
    }
    if (!isDemoMode) throw err;
    console.warn('Mode démo activé : fallback local de connexion.', err);
  }

  const localAccounts: Record<string, { name: string; role: 'commercial' | 'admin' }> = {
    sihamf: { name: 'Siham F', role: 'commercial' },
    ayab: { name: 'Aya B', role: 'commercial' },
    majdaa: { name: 'Majda A', role: 'commercial' },
    houdal: { name: 'Houda L', role: 'commercial' },
    admin: { name: 'Administrateur Esthemax', role: 'admin' },
  };
  const localAccount = localAccounts[login.trim().toLowerCase()];
  if (localAccount && password === (localAccount.role === 'admin' ? 'AdminEsthemax2026!' : 'Esthemax2026!')) {
    const localUser: User = {
      id: `local-${login.trim().toLowerCase()}`,
      name: localAccount.name,
      email: `${login.trim().toLowerCase()}@esthemax.local`,
      role: localAccount.role,
      status: 'active',
      last_login_at: new Date().toISOString(),
    };
    const token = `local_token_${localUser.id}`;
    setAuthToken(token);
    return { user: localUser, token };
  }

  // Demo user matching
  const cleanLogin = login.trim().toLowerCase();
  const matched = Object.values(DEMO_USERS).find(
    (u) => u.email.toLowerCase() === cleanLogin || u.name.toLowerCase().replace(/\s+/g, '') === cleanLogin
  );

  if (matched) {
    if (matched.status === 'blocked') {
      const error: any = new Error('Votre compte est bloqué. Veuillez contacter la direction Esthemax.');
      error.status = 403;
      error.accountStatus = 'blocked';
      throw error;
    }
    if (matched.status === 'inactive') {
      const error: any = new Error('Votre compte commercial est actuellement inactif.');
      error.status = 403;
      error.accountStatus = 'inactive';
      throw error;
    }
    const token = `esthemax_token_${matched.id}`;
    setAuthToken(token);
    return {
      user: matched,
      token,
    };
  }

  // Generic demo fallback for any standard commercial test email
  if (cleanLogin.includes('commercial') || cleanLogin.includes('esthemax')) {
    const fallbackUser: User = {
      id: 'e0123456-789a-bcde-f012-3456789abcde',
      name: login.trim(),
      email: `${cleanLogin}@esthemax.local`,
      role: 'commercial',
      phone: '+33 6 12 34 56 78',
      region: 'Région Commerciale',
      sector: 'Instituts Esthemax',
      status: 'active',
      last_login_at: new Date().toISOString(),
    };
    const token = `esthemax_token_${fallbackUser.id}`;
    setAuthToken(token);
    return { user: fallbackUser, token };
  }

  const err: any = new Error('Identifiants incorrects. Veuillez vérifier votre identifiant et votre mot de passe.');
  err.status = 401;
  throw err;
}

export async function logoutUser(): Promise<void> {
  try {
    await apiClient('/logout', { method: 'POST' });
  } catch (e) {
    // ignore
  } finally {
    setAuthToken(null);
  }
}

export async function getCurrentUser(): Promise<User | null> {
  try {
    const user = await apiClient<User>('/user');
    if (user && user.id) return user;
  } catch (e) {
    // ignore
  }
  return null;
}
