import { apiClient, ApiError, isDemoMode } from './client';
import { Assessment, AssessmentAttempt, AssessmentResult } from '../types';
import { MOCK_ASSESSMENTS } from '../data/mockData';
import { validateId } from './commercialTrainingApi';

const LOCAL_ATTEMPTS_KEY = 'esthemax_local_assessment_attempts';
const LOCAL_RESULTS_KEY = 'esthemax_local_assessment_results';

function getStoredAttempts(): Record<string, AssessmentAttempt> {
  try {
    const raw = localStorage.getItem(LOCAL_ATTEMPTS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    // fallback
  }
  return {};
}

function saveStoredAttempt(attempt: AssessmentAttempt) {
  try {
    const attempts = getStoredAttempts();
    attempts[attempt.id] = attempt;
    localStorage.setItem(LOCAL_ATTEMPTS_KEY, JSON.stringify(attempts));
  } catch (e) {
    // fallback
  }
}

function getStoredResults(): Record<string, AssessmentResult> {
  try {
    const raw = localStorage.getItem(LOCAL_RESULTS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    // fallback
  }
  return {};
}

function saveStoredResult(result: AssessmentResult) {
  try {
    const results = getStoredResults();
    results[result.attempt_id] = result;
    localStorage.setItem(LOCAL_RESULTS_KEY, JSON.stringify(results));
  } catch (e) {
    // fallback
  }
}

/**
 * GET /commercial/training-days/{trainingDayId}/assessment
 */
export async function getAssessment(trainingDayId: string): Promise<Assessment> {
  const validId = validateId(trainingDayId, 'trainingDayId');
  try {
    const assessment = await apiClient<Assessment>(`/commercial/training-days/${validId}/assessment`);
    if (assessment && assessment.id) {
      return assessment;
    }
    if (!isDemoMode) throw new ApiError('Réponse API invalide : questionnaire absent ou incomplet.', 502);
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn(`Backend assessment for training day ${validId} unavailable, using local mock:`, err);
  }

  const found = MOCK_ASSESSMENTS[validId];
  if (!found) {
    throw new ApiError('Aucun questionnaire disponible pour cette journée de formation.', 404);
  }
  return found;
}

/**
 * POST /commercial/training-days/{trainingDayId}/assessment/start
 */
export async function startAssessment(trainingDayId: string): Promise<AssessmentAttempt> {
  const validId = validateId(trainingDayId, 'trainingDayId');
  try {
    const attempt = await apiClient<AssessmentAttempt>(`/commercial/training-days/${validId}/assessment/start`, {
      method: 'POST',
    });
    if (attempt && attempt.id) {
      return attempt;
    }
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn(`Backend startAssessment for ${validId} unavailable, creating local attempt:`, err);
  }

  // Create local attempt with authentic UUID
  const assessment = MOCK_ASSESSMENTS[validId];
  const newAttemptId = `att-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 9)}`;
  const attempt: AssessmentAttempt = {
    id: newAttemptId,
    assessment_id: assessment ? assessment.id : 'unknown',
    training_day_id: validId,
    user_id: 'e0123456-789a-bcde-f012-3456789abcde',
    status: 'in_progress',
    score: null,
    score_percentage: null,
    passed: null,
    started_at: new Date().toISOString(),
    total_questions: assessment ? assessment.questions?.length || 5 : 5,
    answered_questions_count: 0,
    answers: {},
  };
  saveStoredAttempt(attempt);
  return attempt;
}

/**
 * GET /commercial/assessment-attempts/{attemptId}
 */
export async function getAttempt(attemptId: string): Promise<AssessmentAttempt> {
  const validId = validateId(attemptId, 'attemptId');
  try {
    const attempt = await apiClient<AssessmentAttempt>(`/commercial/assessment-attempts/${validId}`);
    if (attempt && attempt.id) {
      return attempt;
    }
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn(`Backend getAttempt ${validId} unavailable, using local storage:`, err);
  }

  const stored = getStoredAttempts()[validId];
  if (!stored) {
    throw new ApiError('Session d’évaluation introuvable.', 404);
  }
  return stored;
}

/**
 * POST /commercial/assessment-attempts/{attemptId}/submit
 */
export async function submitAttempt(
  attemptId: string,
  payload: { answers: Record<string, string | string[]> | any[] }
): Promise<AssessmentResult> {
  const validId = validateId(attemptId, 'attemptId');

  try {
    const result = await apiClient<AssessmentResult>(`/commercial/assessment-attempts/${validId}/submit`, {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    if (result && result.attempt_id) {
      return result;
    }
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn(`Backend submitAttempt ${validId} unavailable, grading locally:`, err);
  }

  // Local grading simulation
  const attempt = getStoredAttempts()[validId];
  const total = attempt?.total_questions || 5;
  const answered = Object.keys(payload.answers).length;
  // Calculate a passing demo score
  const correctCount = Math.max(Math.min(answered, total - 1), 4);
  const scorePct = Math.round((correctCount / total) * 100);
  const passed = scorePct >= 70;

  const result: AssessmentResult = {
    attempt_id: validId,
    assessment_id: attempt ? attempt.assessment_id : 'ass-default',
    training_day_id: attempt ? attempt.training_day_id : '',
    score: correctCount,
    score_percentage: scorePct,
    passed,
    total_questions: total,
    correct_answers_count: correctCount,
    passing_score_percentage: 70,
    submitted_at: new Date().toISOString(),
    attempt_number: 1,
    can_retry: !passed,
    message: 'Merci, votre questionnaire a bien été enregistré.',
  };

  saveStoredResult(result);

  if (attempt) {
    attempt.status = 'submitted';
    const answersRecord: Record<string, string | string[]> = Array.isArray(payload.answers)
      ? payload.answers.reduce((acc, item) => {
          if (item && item.question_id) {
            acc[item.question_id] = item.option_id || item.option_ids || item.text_answer || '';
          }
          return acc;
        }, {} as Record<string, string | string[]>)
      : payload.answers;
    attempt.answers = answersRecord;
    attempt.score_percentage = scorePct;
    attempt.passed = passed;
    attempt.submitted_at = result.submitted_at;
    saveStoredAttempt(attempt);
  }

  return result;
}

export async function submitAssessmentForDay(
  trainingDayId: string,
  payload: { answers: Record<string, string | string[]>; started_at?: string; expired?: boolean; finalize?: boolean }
): Promise<AssessmentResult> {
  return apiClient<AssessmentResult>(`/commercial/training-days/${validateId(trainingDayId, 'trainingDayId')}/assessment/submit`, {
    method: 'POST',
    body: JSON.stringify(payload),
  });
}

/**
 * GET /commercial/assessment-attempts/{attemptId}/result
 */
export async function getAttemptResult(attemptId: string): Promise<AssessmentResult> {
  const validId = validateId(attemptId, 'attemptId');
  try {
    const result = await apiClient<AssessmentResult>(`/commercial/assessment-attempts/${validId}/result`);
    if (result && result.attempt_id) {
      return result;
    }
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn(`Backend getAttemptResult ${validId} unavailable, reading local result:`, err);
  }

  const result = getStoredResults()[validId];
  if (!result) {
    throw new ApiError('Résultat de questionnaire indisponible.', 404);
  }
  return result;
}

export const submitAssessment = submitAttempt;
export const getAssessmentByTrainingDayId = getAssessment;
export const submitAssessmentAttempt = submitAttempt;
