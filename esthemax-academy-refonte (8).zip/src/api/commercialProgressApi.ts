import { apiClient, isDemoMode } from './client';
import { CommercialProgress } from '../types';
import { MOCK_PROGRESS } from '../data/mockData';
import { validateId } from './commercialTrainingApi';

/**
 * GET /commercial/progress
 * Loads personal progress of the logged-in commercial user
 */
export async function getProgress(): Promise<CommercialProgress> {
  try {
    const progress = await apiClient<CommercialProgress>('/commercial/progress');
    if (progress && typeof progress === 'object') {
      return progress;
    }
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn('Backend /commercial/progress unavailable, using local progress:', err);
  }

  return MOCK_PROGRESS;
}

/**
 * GET /commercial/training-days/{trainingDayId}/progress
 */
export async function getTrainingDayProgress(trainingDayId: string): Promise<any> {
  const validId = validateId(trainingDayId, 'trainingDayId');
  try {
    return await apiClient(`/commercial/training-days/${validId}/progress`);
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn(`Backend progress for ${validId} unavailable:`, err);
  }

  const dayProgress = MOCK_PROGRESS.days_progress.find((d) => d.training_day_id === validId);
  return (
    dayProgress || {
      training_day_id: validId,
      progress_percentage: 0,
      completed_modules: 0,
      total_modules: 3,
      assessment_passed: false,
    }
  );
}
