import { apiClient, ApiError, isDemoMode } from './client';
import { TrainingDay, ContentModule } from '../types';
import { INITIAL_TRAINING_DAYS, MOCK_MODULES } from '../data/mockData';

// Local storage key for interactive persistence when working offline
const LOCAL_TRAINING_DAYS_KEY = 'esthemax_local_training_days';
const LOCAL_MODULES_KEY = 'esthemax_local_modules';

function getStoredTrainingDays(): TrainingDay[] {
  try {
    const raw = localStorage.getItem(LOCAL_TRAINING_DAYS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    // fallback
  }
  return INITIAL_TRAINING_DAYS;
}

function saveStoredTrainingDays(days: TrainingDay[]) {
  try {
    localStorage.setItem(LOCAL_TRAINING_DAYS_KEY, JSON.stringify(days));
  } catch (e) {
    // fallback
  }
}

function getStoredModules(trainingDayId: string): ContentModule[] {
  try {
    const raw = localStorage.getItem(`${LOCAL_MODULES_KEY}_${trainingDayId}`);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    // fallback
  }
  return MOCK_MODULES[trainingDayId] || [];
}

function saveStoredModules(trainingDayId: string, modules: ContentModule[]) {
  try {
    localStorage.setItem(`${LOCAL_MODULES_KEY}_${trainingDayId}`, JSON.stringify(modules));
  } catch (e) {
    // fallback
  }
}

/**
 * Validates that an ID is a valid, non-empty string
 */
export function validateId(id: unknown, label = 'identifiant'): string {
  if (typeof id !== 'string' || !id.trim()) {
    throw new Error(`Erreur d'identifiant : ${label} invalide ou manquant.`);
  }
  return id.trim();
}

/**
 * GET /commercial/training-days
 * Returns only available/authorized training days for the commercial user
 */
export async function getTrainingDays(): Promise<TrainingDay[]> {
  try {
    const days = await apiClient<TrainingDay[]>('/commercial/training-days');
    if (Array.isArray(days)) {
      return days;
    }
    if (!isDemoMode) throw new ApiError('Réponse API invalide : la liste des formations est absente.', 502);
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn('Mode démo activé : formations locales.', err);
  }
  return getStoredTrainingDays().map((day, index, all) => {
    const previous = all[index - 1];
    const previousPassed = !previous || localStorage.getItem(`esthemax_quiz_passed_${previous.id}`) === '1';
    const passed = localStorage.getItem(`esthemax_quiz_passed_${day.id}`) === '1';
    return {
      ...day,
      status: passed ? 'completed' : previousPassed ? (index === 0 ? 'in_progress' : 'available') : 'locked',
      assessment_status: passed ? 'passed' : previousPassed ? 'pending' : 'locked',
      formation_url: `https://esthemax.birdeye-intelligence.ma/j${index + 1}`,
    };
  });
}

/**
 * GET /commercial/training-days/{trainingDayId}
 */
export async function getTrainingDay(trainingDayId: string): Promise<TrainingDay> {
  const validId = validateId(trainingDayId, 'trainingDayId');
  try {
    const day = await apiClient<TrainingDay>(`/commercial/training-days/${validId}`);
    if (day && typeof day === 'object' && day.id) {
      return day;
    }
    if (!isDemoMode) throw new ApiError('Réponse API invalide : la journée de formation est absente.', 502);
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn('Mode démo activé : journée locale.', err);
  }
  const days = getStoredTrainingDays();
  const found = days.find((d) => d.id === validId);
  if (!found) {
    throw new ApiError('Journée de formation introuvable.', 404);
  }
  return found;
}

/**
 * POST /commercial/training-days/{trainingDayId}/start
 */
export async function startTrainingDay(trainingDayId: string): Promise<{ success: boolean; message?: string }> {
  const validId = validateId(trainingDayId, 'trainingDayId');
  try {
    return await apiClient<{ success: boolean; message?: string }>(`/commercial/training-days/${validId}/start`, {
      method: 'POST',
    });
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn('Mode démo activé : démarrage local.', err);
  }

  // Local fallback update
  const days = getStoredTrainingDays();
  const updated = days.map((d) => {
    if (d.id === validId && d.status === 'available') {
      return { ...d, status: 'in_progress' as const };
    }
    return d;
  });
  saveStoredTrainingDays(updated);
  return { success: true, message: 'Formation démarrée avec succès.' };
}

/**
 * GET /commercial/training-days/{trainingDayId}/modules
 * Returns only published modules in sort_order
 */
export async function getTrainingDayModules(trainingDayId: string): Promise<ContentModule[]> {
  const validId = validateId(trainingDayId, 'trainingDayId');
  try {
    const modules = await apiClient<ContentModule[]>(`/commercial/training-days/${validId}/modules`);
    if (Array.isArray(modules)) {
      return modules
        .filter((m) => m.status === 'published')
        .sort((a, b) => a.sort_order - b.sort_order);
    }
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn('Mode démo activé : modules locaux.', err);
  }

  const modules = getStoredModules(validId);
  return modules
    .filter((m) => m.status === 'published')
    .sort((a, b) => a.sort_order - b.sort_order);
}

/**
 * GET /commercial/modules/{moduleId}
 */
export async function getModule(moduleId: string): Promise<ContentModule> {
  const validId = validateId(moduleId, 'moduleId');
  try {
    const mod = await apiClient<ContentModule>(`/commercial/modules/${validId}`);
    if (mod && mod.id) {
      return mod;
    }
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn('Mode démo activé : module local.', err);
  }

  // Search across all modules
  const allDays = getStoredTrainingDays();
  for (const day of allDays) {
    const modules = getStoredModules(day.id);
    const found = modules.find((m) => m.id === validId);
    if (found) return found;
  }

  throw new ApiError('Module de formation introuvable ou non publié.', 404);
}

/**
 * POST /commercial/modules/{moduleId}/view
 */
export async function markModuleViewed(moduleId: string): Promise<{ success: boolean }> {
  const validId = validateId(moduleId, 'moduleId');
  try {
    return await apiClient<{ success: boolean }>(`/commercial/modules/${validId}/view`, {
      method: 'POST',
    });
  } catch (err) {
    if (!isDemoMode) throw err;
    console.warn('Mode démo activé : progression locale.', err);
  }

  // Local fallback update
  const allDays = getStoredTrainingDays();
  for (const day of allDays) {
    const modules = getStoredModules(day.id);
    const modIndex = modules.findIndex((m) => m.id === validId);
    if (modIndex !== -1) {
      if (!modules[modIndex].is_completed) {
        modules[modIndex].is_completed = true;
        modules[modIndex].viewed_at = new Date().toISOString();
        saveStoredModules(day.id, modules);

        // Update day stats
        const completedCount = modules.filter((m) => m.is_completed).length;
        const progressPct = Math.round((completedCount / modules.length) * 100);
        const updatedDays = allDays.map((d) =>
          d.id === day.id
            ? {
                ...d,
                completed_modules_count: completedCount,
                progress_percentage: progressPct,
                status: progressPct === 100 && d.status === 'in_progress' ? ('completed' as const) : d.status,
              }
            : d
        );
        saveStoredTrainingDays(updatedDays);
      }
      break;
    }
  }

  return { success: true };
}

export const getTrainingDayDetail = getTrainingDay;
export const getTrainingDayById = getTrainingDay;
export const getModuleDetail = getModule;
export const getModuleById = getModule;
export const completeModule = markModuleViewed;
