import React from 'react';
import { BookOpen, AlertCircle, Award, CheckCircle2, FileQuestion, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

export interface EmptyStateProps {
  type?: 'training-days' | 'modules' | 'assessment' | 'progress' | 'completed-days' | 'general';
  title?: string;
  description?: string;
  actionText?: string;
  actionHref?: string;
  onActionClick?: () => void;
}

export const CommercialEmptyState: React.FC<EmptyStateProps> = ({
  type = 'general',
  title,
  description,
  actionText,
  actionHref,
  onActionClick,
}) => {
  const getIcon = () => {
    switch (type) {
      case 'training-days':
        return <BookOpen className="w-8 h-8 text-[#D41472]" />;
      case 'modules':
        return <AlertCircle className="w-8 h-8 text-[#C47A16]" />;
      case 'assessment':
        return <FileQuestion className="w-8 h-8 text-[#D41472]" />;
      case 'completed-days':
        return <Award className="w-8 h-8 text-[#16866A]" />;
      case 'progress':
      default:
        return <CheckCircle2 className="w-8 h-8 text-[#D41472]" />;
    }
  };

  const getDefaultTitle = () => {
    switch (type) {
      case 'training-days':
        return 'Aucune journée de formation disponible';
      case 'modules':
        return 'Aucun module publié';
      case 'assessment':
        return 'Aucun questionnaire disponible';
      case 'completed-days':
        return 'Aucune formation terminée pour le moment';
      case 'progress':
        return 'Aucune activité enregistrée';
      default:
        return 'Aucun élément trouvé';
    }
  };

  const getDefaultDescription = () => {
    switch (type) {
      case 'training-days':
        return 'Les journées de formation seront débloquées par votre responsable commercial au fil de votre parcours.';
      case 'modules':
        return 'Les modules de cette journée sont en cours de mise en ligne. Veuillez revenir ultérieurement.';
      case 'assessment':
        return 'Le questionnaire d’évaluation sera accessible une fois tous les modules de la journée complétés.';
      case 'completed-days':
        return 'Complétez votre première journée de formation (J1) pour débloquer votre premier badge de réussite.';
      case 'progress':
        return 'Démarrez votre première journée de formation pour visualiser votre progression personnelle.';
      default:
        return 'Le contenu demandé n’est pas disponible actuellement.';
    }
  };

  return (
    <div
      id={`commercial-empty-state-${type}`}
      className="bg-white border border-[#F0E5E9] rounded-3xl p-8 md:p-12 text-center max-w-lg mx-auto shadow-sm"
    >
      <div className="w-16 h-16 rounded-2xl bg-[#FCE7F3] flex items-center justify-center mx-auto mb-4">
        {getIcon()}
      </div>
      <h3 className="text-lg font-bold text-[#241B22] mb-2">{title || getDefaultTitle()}</h3>
      <p className="text-xs sm:text-sm text-[#766A72] leading-relaxed mb-6">{description || getDefaultDescription()}</p>

      {(actionText || actionHref) && (
        <div>
          {actionHref ? (
            <Link
              to={actionHref}
              className="inline-flex items-center justify-center px-5 py-2.5 rounded-xl bg-[#D41472] text-white text-xs font-bold hover:bg-[#A90F59] transition-colors focus:ring-2 focus:ring-[#D41472] focus:outline-none min-h-[44px]"
            >
              {actionText || 'Retourner aux formations'}
            </Link>
          ) : (
            <button
              type="button"
              onClick={onActionClick}
              className="inline-flex items-center justify-center px-5 py-2.5 rounded-xl bg-[#D41472] text-white text-xs font-bold hover:bg-[#A90F59] transition-colors focus:ring-2 focus:ring-[#D41472] focus:outline-none min-h-[44px]"
            >
              {actionText || 'Actualiser'}
            </button>
          )}
        </div>
      )}
    </div>
  );
};

export default CommercialEmptyState;
