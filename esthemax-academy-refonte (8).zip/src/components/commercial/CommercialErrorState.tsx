import React from 'react';
import { AlertTriangle, RefreshCw, LogIn, Lock } from 'lucide-react';
import { Link } from 'react-router-dom';

export interface ErrorStateProps {
  title?: string;
  message?: string;
  errorType?: 'network' | 'blocked' | 'session' | 'notFound' | 'general';
  onRetry?: () => void;
  actionText?: string;
  actionHref?: string;
}

export const CommercialErrorState: React.FC<ErrorStateProps> = ({
  title,
  message,
  errorType = 'general',
  onRetry,
  actionText,
  actionHref,
}) => {
  const getDefaultTitle = () => {
    switch (errorType) {
      case 'network':
        return 'Connexion réseau instable';
      case 'blocked':
        return 'Accès commercial restreint';
      case 'session':
        return 'Session expirée';
      case 'notFound':
        return 'Ressource introuvable';
      default:
        return 'Une erreur est survenue';
    }
  };

  const getDefaultMessage = () => {
    switch (errorType) {
      case 'network':
        return 'Impossible de charger les données de formation. Veuillez vérifier votre connexion Internet et réessayer.';
      case 'blocked':
        return 'Votre compte commercial est actuellement inactif ou bloqué. Veuillez contacter votre responsable régional.';
      case 'session':
        return 'Votre session a expiré. Veuillez vous reconnecter pour poursuivre votre formation.';
      case 'notFound':
        return 'Le contenu ou la journée de formation demandée n’existe pas ou a été archivée.';
      default:
        return 'Un problème est survenu lors du chargement des informations. Notre équipe technique en a été informée.';
    }
  };

  return (
    <div
      id="commercial-error-state"
      className="bg-white border border-[#F0E5E9] rounded-3xl p-8 md:p-10 text-center max-w-lg mx-auto shadow-sm"
    >
      <div className="w-16 h-16 rounded-2xl bg-rose-50 text-[#C2415D] flex items-center justify-center mx-auto mb-4 border border-rose-100">
        {errorType === 'blocked' ? (
          <Lock className="w-8 h-8" />
        ) : (
          <AlertTriangle className="w-8 h-8" />
        )}
      </div>

      <h3 className="text-lg font-bold text-[#241B22] mb-2">{title || getDefaultTitle()}</h3>

      <p className="text-xs sm:text-sm text-[#766A72] leading-relaxed mb-6">{message || getDefaultMessage()}</p>

      <div className="flex flex-wrap items-center justify-center gap-3">
        {onRetry && (
          <button
            type="button"
            onClick={onRetry}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#D41472] text-white text-xs font-bold hover:bg-[#A90F59] transition-colors focus:ring-2 focus:ring-[#D41472] focus:outline-none min-h-[44px]"
          >
            <RefreshCw className="w-4 h-4" />
            <span>{actionText || 'Réessayer'}</span>
          </button>
        )}

        {actionHref && (
          <Link
            to={actionHref}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl border border-[#F0E5E9] bg-white text-[#241B22] text-xs font-bold hover:bg-[#FFF9F7] transition-colors min-h-[44px]"
          >
            {errorType === 'session' ? <LogIn className="w-4 h-4" /> : null}
            <span>{actionText || 'Retour'}</span>
          </Link>
        )}
      </div>
    </div>
  );
};

export default CommercialErrorState;
