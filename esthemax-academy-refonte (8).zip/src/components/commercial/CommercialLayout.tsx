import React from 'react';
import { Outlet } from 'react-router-dom';
import CommercialSidebar from './CommercialSidebar';
import CommercialMobileNavigation from './CommercialMobileNavigation';

export const CommercialLayout: React.FC = () => {
  return (
    <div className="min-h-screen bg-[#FAF7F5] text-[#1E161D] flex flex-col lg:flex-row antialiased selection:bg-[#D41472] selection:text-white relative overflow-x-hidden">
      {/* 2030 Futuristic Ambient Glowing Halos */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden" aria-hidden="true">
        {/* Rose blush halo */}
        <div className="absolute top-[-5%] left-[-5%] w-[45vw] h-[45vw] min-w-[320px] min-h-[320px] rounded-full bg-[#FCE7F3]/60 blur-[130px] animate-orb-1" />
        {/* Champagne gold halo */}
        <div className="absolute top-[35%] right-[-8%] w-[40vw] h-[40vw] min-w-[280px] min-h-[280px] rounded-full bg-[#FDF3E7]/70 blur-[120px] animate-orb-2" />
        {/* Soft mauve / rose halo */}
        <div className="absolute bottom-[-10%] left-[20%] w-[50vw] h-[50vw] min-w-[340px] min-h-[340px] rounded-full bg-[#FDF0F5]/80 blur-[140px]" />
      </div>

      {/* Main App Container */}
      <div className="relative z-10 flex flex-col lg:flex-row w-full min-h-screen">
        {/* Desktop Lateral Sidebar */}
        <CommercialSidebar />

        {/* Mobile Top Header & Floating Bottom Dock */}
        <CommercialMobileNavigation />

        {/* Main View Area (with sufficient padding-bottom on mobile so dock never overlaps content) */}
        <main
          id="commercial-main-content"
          className="flex-1 flex flex-col min-w-0 w-full overflow-x-hidden pb-28 lg:pb-12"
        >
          <div className="w-full max-w-6xl mx-auto px-3.5 sm:px-6 lg:px-8 py-4 sm:py-6 md:py-8">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};

export default CommercialLayout;
