import React from 'react';

export interface SkeletonProps {
  type?: 'dashboard' | 'training-days' | 'training-day' | 'module' | 'content' | 'assessment' | 'progress';
}

export const CommercialLoadingState: React.FC<SkeletonProps> = ({ type = 'dashboard' }) => {
  if (type === 'dashboard') {
    return (
      <div className="space-y-6 animate-pulse" id="commercial-loading-dashboard">
        {/* Header banner skeleton */}
        <div className="h-44 bg-[#FCE7F3]/60 rounded-3xl p-6 sm:p-8 flex flex-col justify-between border border-[#F0E5E9]">
          <div className="space-y-2.5">
            <div className="h-4 w-36 bg-white/80 rounded-full" />
            <div className="h-8 w-64 bg-white/90 rounded-xl" />
            <div className="h-4 w-80 bg-white/70 rounded-lg" />
          </div>
          <div className="h-3 w-full bg-white/60 rounded-full" />
        </div>

        {/* Metric cards grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-white border border-[#F0E5E9] rounded-2xl p-5 shadow-sm flex flex-col justify-between">
              <div className="h-3 w-28 bg-[#F0E5E9] rounded" />
              <div className="h-7 w-20 bg-[#F0E5E9] rounded" />
            </div>
          ))}
        </div>

        {/* Section skeleton */}
        <div className="space-y-4">
          <div className="h-6 w-44 bg-[#F0E5E9] rounded" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-64 bg-white border border-[#F0E5E9] rounded-3xl p-6 shadow-sm flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="h-5 w-16 bg-[#FCE7F3] rounded-full" />
                  <div className="h-6 w-3/4 bg-[#F0E5E9] rounded" />
                  <div className="h-4 w-full bg-[#FFF9F7] rounded" />
                  <div className="h-4 w-2/3 bg-[#FFF9F7] rounded" />
                </div>
                <div className="h-10 w-full bg-[#F0E5E9] rounded-xl mt-4" />
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (type === 'training-days') {
    return (
      <div className="space-y-6 animate-pulse" id="commercial-loading-training-days">
        <div className="space-y-2">
          <div className="h-8 w-60 bg-[#F0E5E9] rounded-xl" />
          <div className="h-4 w-80 bg-[#FFF9F7] rounded" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white border border-[#F0E5E9] rounded-3xl p-6 space-y-4 shadow-sm">
              <div className="flex justify-between items-center">
                <div className="h-7 w-16 bg-[#FCE7F3] rounded-full" />
                <div className="h-5 w-24 bg-[#FFF9F7] rounded-full" />
              </div>
              <div className="h-6 w-3/4 bg-[#F0E5E9] rounded" />
              <div className="h-16 w-full bg-[#FFF9F7] rounded" />
              <div className="h-2 w-full bg-[#F0E5E9] rounded-full" />
              <div className="h-11 w-full bg-[#F0E5E9] rounded-xl" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (type === 'training-day') {
    return (
      <div className="space-y-6 animate-pulse" id="commercial-loading-training-day">
        <div className="h-5 w-32 bg-[#F0E5E9] rounded" />
        <div className="bg-white border border-[#F0E5E9] rounded-3xl p-6 sm:p-8 space-y-4 shadow-sm">
          <div className="h-6 w-20 bg-[#FCE7F3] rounded-full" />
          <div className="h-8 w-2/3 bg-[#F0E5E9] rounded" />
          <div className="h-4 w-full bg-[#FFF9F7] rounded" />
          <div className="h-3 w-full bg-[#FFF9F7] rounded-full" />
        </div>
        <div className="space-y-3">
          <div className="h-6 w-40 bg-[#F0E5E9] rounded" />
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-20 bg-white border border-[#F0E5E9] rounded-2xl p-4 flex items-center justify-between">
              <div className="space-y-2">
                <div className="h-5 w-48 bg-[#F0E5E9] rounded" />
                <div className="h-4 w-32 bg-[#FFF9F7] rounded" />
              </div>
              <div className="h-8 w-24 bg-[#F0E5E9] rounded-lg" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (type === 'module' || type === 'content') {
    return (
      <div className="space-y-6 animate-pulse max-w-4xl mx-auto" id="commercial-loading-module">
        <div className="h-5 w-40 bg-[#F0E5E9] rounded" />
        <div className="bg-white border border-[#F0E5E9] rounded-3xl p-6 md:p-8 space-y-6 shadow-sm">
          <div className="space-y-3">
            <div className="h-4 w-28 bg-[#FCE7F3] rounded-full" />
            <div className="h-9 w-3/4 bg-[#F0E5E9] rounded" />
            <div className="h-4 w-full bg-[#FFF9F7] rounded" />
          </div>
          <div className="h-52 bg-[#F0E5E9] rounded-2xl" />
          <div className="space-y-3">
            <div className="h-4 w-full bg-[#F0E5E9] rounded" />
            <div className="h-4 w-full bg-[#F0E5E9] rounded" />
            <div className="h-4 w-4/5 bg-[#F0E5E9] rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (type === 'assessment') {
    return (
      <div className="space-y-6 animate-pulse max-w-3xl mx-auto" id="commercial-loading-assessment">
        <div className="h-6 w-48 bg-[#F0E5E9] rounded" />
        <div className="bg-white border border-[#F0E5E9] rounded-3xl p-6 md:p-8 space-y-6 shadow-sm">
          <div className="h-3 w-full bg-[#FFF9F7] rounded-full" />
          <div className="h-8 w-3/4 bg-[#F0E5E9] rounded" />
          <div className="space-y-3 pt-4">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-16 bg-[#FFF9F7] border border-[#F0E5E9] rounded-2xl p-4 flex items-center gap-3">
                <div className="w-5 h-5 rounded-full bg-[#F0E5E9]" />
                <div className="h-4 w-2/3 bg-[#F0E5E9] rounded" />
              </div>
            ))}
          </div>
          <div className="flex justify-between pt-4">
            <div className="h-11 w-28 bg-[#F0E5E9] rounded-xl" />
            <div className="h-11 w-32 bg-[#FCE7F3] rounded-xl" />
          </div>
        </div>
      </div>
    );
  }

  // Progress skeleton
  return (
    <div className="space-y-6 animate-pulse" id="commercial-loading-progress">
      <div className="h-8 w-56 bg-[#F0E5E9] rounded-xl" />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-24 bg-white border border-[#F0E5E9] rounded-2xl p-4 shadow-sm flex flex-col justify-between">
            <div className="h-3 w-20 bg-[#F0E5E9] rounded" />
            <div className="h-7 w-16 bg-[#F0E5E9] rounded" />
          </div>
        ))}
      </div>
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <div key={i} className="h-32 bg-white border border-[#F0E5E9] rounded-3xl p-6 shadow-sm flex flex-col justify-between">
            <div className="h-6 w-48 bg-[#F0E5E9] rounded" />
            <div className="h-3 w-full bg-[#FFF9F7] rounded-full" />
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommercialLoadingState;
