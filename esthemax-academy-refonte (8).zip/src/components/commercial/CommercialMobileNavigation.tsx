import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  BarChart3,
  FileQuestion,
  UserCheck,
  Bell,
  Sparkles,
  X,
  CheckCircle2,
  Award,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const CommercialMobileNavigation: React.FC = () => {
  const { user } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);

  const navItems = [
    { to: '/commercial', end: true, label: 'Accueil', icon: LayoutDashboard },
    { to: '/commercial/training-days', end: false, label: 'Formations', icon: BookOpen },
    { to: '/commercial/progress', end: false, label: 'Progression', icon: BarChart3 },
    { to: '/commercial/evaluations', end: false, label: 'Évaluations', icon: FileQuestion },
    { to: '/commercial/profile', end: false, label: 'Profil', icon: UserCheck },
  ];

  const notifications = [
    {
      id: 1,
      title: 'Certification J1 débloquée',
      time: 'Il y a 2h',
      desc: 'Votre quiz sur l’univers Esthemax a été validé à 100%.',
      icon: Award,
      color: 'text-[#16866A] bg-emerald-50',
    },
    {
      id: 2,
      title: 'Nouveau protocole Hydrojelly®',
      time: 'Hier',
      desc: 'Découvrez la fiche technique cabine mise à jour pour J2.',
      icon: Sparkles,
      color: 'text-[#D41472] bg-[#FCE7F3]',
    },
    {
      id: 3,
      title: 'Objectif hebdomadaire',
      time: 'Il y a 3j',
      desc: 'Complétez 2 modules supplémentaires pour valider votre semaine.',
      icon: CheckCircle2,
      color: 'text-[#C59B27] bg-[#FDF3E7]',
    },
  ];

  return (
    <>
      {/* Mobile Top App Bar (2030 Glass Header) */}
      <header
        id="commercial-mobile-header"
        className="lg:hidden sticky top-0 z-40 bg-white/80 backdrop-blur-xl border-b border-white/80 px-4 py-3 flex items-center justify-between shadow-[0_4px_20px_rgba(36,27,34,0.03)]"
      >
        <div className="flex items-center gap-2.5">
          <img
            src="https://www.esthemax-morocco.com/wp-content/uploads/2023/12/esthemaxl-logo.png"
            alt="Esthemax Academy"
            className="h-7 w-auto object-contain"
          />
          <span className="text-[10px] font-extrabold uppercase tracking-widest px-2 py-0.5 rounded-full bg-[#FCE7F3] text-[#D41472]">
            Academy
          </span>
        </div>

        <div className="flex items-center gap-2">
          {/* Notifications button */}
          <button
            type="button"
            onClick={() => setShowNotifications(true)}
            className="relative p-2 rounded-full glass-card hover:bg-white text-[#1E161D] transition-colors focus:outline-none"
            aria-label="Voir les notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#D41472] ring-2 ring-white animate-pulse" />
          </button>

          {/* User mini avatar pill */}
          <NavLink
            to="/commercial/profile"
            className="flex items-center gap-1.5 pl-1.5 pr-2.5 py-1 rounded-full glass-card hover:bg-white transition-all text-xs font-bold text-[#1E161D]"
          >
            <div
              className="w-6 h-6 rounded-full text-white text-[11px] font-extrabold flex items-center justify-center shadow-xs"
              style={{ backgroundColor: '#D41472' }}
            >
              {user?.name?.charAt(0) || 'C'}
            </div>
            <span className="max-w-[70px] truncate text-[11px] font-semibold">{user?.name?.split(' ')[0] || 'Moi'}</span>
          </NavLink>
        </div>
      </header>

      {/* Notifications Drawer / Modal */}
      {showNotifications && (
        <div className="fixed inset-0 z-50 flex items-start justify-center p-4 bg-black/30 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm glass-card rounded-[28px] p-5 shadow-2xl border border-white/90 animate-in zoom-in-95 duration-200 mt-14">
            <div className="flex items-center justify-between pb-3 border-b border-[#EFE6EB]">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-[#D41472]" />
                <h3 className="font-extrabold text-sm text-[#1E161D]">Notifications</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowNotifications(false)}
                className="p-1.5 rounded-full hover:bg-black/5 text-[#6E626B]"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 py-3 max-h-[60vh] overflow-y-auto">
              {notifications.map((n) => {
                const Icon = n.icon;
                return (
                  <div
                    key={n.id}
                    className="p-3 rounded-2xl bg-white/80 border border-white/90 shadow-2xs flex items-start gap-3 hover:bg-white transition-colors"
                  >
                    <div className={`w-8 h-8 rounded-xl ${n.color} flex items-center justify-center shrink-0 mt-0.5`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <h4 className="text-xs font-bold text-[#1E161D] truncate">{n.title}</h4>
                        <span className="text-[10px] text-[#6E626B] shrink-0">{n.time}</span>
                      </div>
                      <p className="text-[11px] text-[#6E626B] mt-0.5 leading-snug">{n.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setShowNotifications(false)}
              className="w-full py-2.5 rounded-xl bg-[#FAF7F5] hover:bg-[#FDF0F5] text-[#D41472] text-xs font-bold transition-colors"
            >
              Fermer
            </button>
          </div>
        </div>
      )}

      {/* Futuristic 2030 Glass Bottom Dock (Fixed, Thumb-friendly) */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-50 pointer-events-none px-3 pb-2 sm:pb-3">
        <nav
          id="commercial-mobile-bottom-bar"
          className="pointer-events-auto max-w-md mx-auto rounded-[28px] glass-dock px-2 py-1.5 flex items-center justify-around shadow-[0_12px_40px_rgba(36,27,34,0.12)] border border-white/90"
          aria-label="Navigation mobile principale"
        >
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) =>
                  `relative flex flex-col items-center justify-center py-2 px-2.5 rounded-2xl min-h-[50px] min-w-[56px] text-[10px] font-bold transition-all duration-300 ${
                    isActive
                      ? 'text-[#D41472] scale-105'
                      : 'text-[#6E626B] hover:text-[#1E161D] active:scale-95'
                  }`
                }
              >
                {({ isActive }) => (
                  <>
                    {/* Active ambient glass pill */}
                    {isActive && (
                      <div className="absolute inset-0 rounded-2xl bg-gradient-to-b from-[#FCE7F3]/90 to-[#FDF0F5]/80 border border-[#D41472]/20 shadow-xs -z-0 animate-in fade-in zoom-in-95 duration-200" />
                    )}

                    <Icon
                      className={`w-5 h-5 mb-0.5 relative z-10 transition-transform duration-200 ${
                        isActive ? 'stroke-[2.4] text-[#D41472]' : 'stroke-[1.8]'
                      }`}
                    />
                    <span className="relative z-10 font-semibold tracking-tight">{item.label}</span>

                    {/* Active dot indicator */}
                    {isActive && (
                      <span className="absolute bottom-1 w-1 h-1 rounded-full bg-[#D41472] z-10" />
                    )}
                  </>
                )}
              </NavLink>
            );
          })}
        </nav>
      </div>
    </>
  );
};

export default CommercialMobileNavigation;
