import React from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2, ChevronLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { ContentModule } from '../../types';

interface Props {
  trainingDayId: string;
  trainingDayCode?: string;
  currentModuleIndex: number;
  totalModules: number;
  currentModule: ContentModule;
  prevModule?: ContentModule | null;
  nextModule?: ContentModule | null;
  isCompleted: boolean;
  onMarkComplete?: () => void;
  onNavigateModule: (moduleId: string) => void;
  assessmentAvailable?: boolean;
  onGoToAssessment?: () => void;
}

export const CommercialModuleNavigation: React.FC<Props> = ({
  trainingDayId,
  trainingDayCode,
  currentModuleIndex,
  totalModules,
  currentModule,
  prevModule,
  nextModule,
  isCompleted,
  onMarkComplete,
  onNavigateModule,
  assessmentAvailable,
  onGoToAssessment,
}) => {
  return (
    <div className="space-y-4 pt-6 border-t border-[#F0E5E9]">
      {/* Action to mark as read/complete */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-[#FFF9F7] border border-[#F0E5E9] p-4 sm:p-5 rounded-2xl">
        <div className="flex items-center gap-3">
          <div
            className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 ${
              isCompleted ? 'bg-emerald-50 text-[#16866A] border border-emerald-200' : 'bg-[#F0E5E9] text-[#766A72]'
            }`}
          >
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <div className="text-sm font-bold text-[#241B22]">
              {isCompleted ? 'Module complété et validé' : 'Terminer la lecture de ce module'}
            </div>
            <div className="text-xs text-[#766A72]">
              Progression enregistrée sur votre compte commercial
            </div>
          </div>
        </div>

        {!isCompleted && onMarkComplete && (
          <button
            type="button"
            onClick={onMarkComplete}
            className="px-5 py-2.5 rounded-xl bg-[#D41472] hover:bg-[#A90F59] text-white text-xs font-bold shadow-sm min-h-[44px] transition-colors focus:ring-2 focus:ring-[#D41472] focus:outline-none"
          >
            Marquer comme terminé
          </button>
        )}
      </div>

      {/* Prev / Next controls */}
      <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {prevModule ? (
          <button
            type="button"
            onClick={() => onNavigateModule(prevModule.id)}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-[#F0E5E9] bg-white hover:bg-[#FFF9F7] text-[#241B22] text-xs font-bold transition-colors min-h-[44px]"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="truncate">Module précédent</span>
          </button>
        ) : (
          <Link
            to={`/commercial/training-days/${trainingDayId}`}
            className="flex items-center justify-center gap-2 px-4 py-3 rounded-xl border border-[#F0E5E9] bg-white hover:bg-[#FFF9F7] text-[#241B22] text-xs font-bold transition-colors min-h-[44px]"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Retour à la journée {trainingDayCode || ''}</span>
          </Link>
        )}

        <div className="text-center text-xs font-bold text-[#766A72] py-1">
          Module {currentModuleIndex + 1} sur {totalModules}
        </div>

        {nextModule ? (
          <button
            type="button"
            onClick={() => onNavigateModule(nextModule.id)}
            className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#D41472] hover:bg-[#A90F59] text-white text-xs font-bold transition-colors min-h-[44px] shadow-sm"
          >
            <span className="truncate">Module suivant</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button
            type="button"
            onClick={onGoToAssessment}
            className="flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-[#16866A] hover:bg-[#116b54] text-white text-xs font-bold shadow-sm transition-colors min-h-[44px]"
          >
            <span>Passer à l’évaluation</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    </div>
  );
};

export default CommercialModuleNavigation;
