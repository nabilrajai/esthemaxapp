import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

interface CommercialRouteProps {
  children?: React.ReactNode;
}

export const CommercialRoute: React.FC<CommercialRouteProps> = ({ children }) => {
  const { user, isAuthenticated, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#FAF9F6] flex items-center justify-center p-4">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-3 border-[#0F243E]/20 border-t-[#0D9488] rounded-full animate-spin" />
          <p className="text-sm text-[#0F243E]/70 font-medium">Vérification de l’accès commercial...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated || !user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // If user account is blocked or inactive
  if (user.status === 'blocked' || user.status === 'inactive') {
    return <Navigate to="/blocked" replace />;
  }

  // An admin must never see the commercial portal.
  if (user.role === 'admin') return <Navigate to="/admin" replace />;

  return <>{children}</>;
};

export default CommercialRoute;
