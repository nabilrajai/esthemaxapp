import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  BarChart3,
  FileQuestion,
  UserCheck,
  LogOut,
  Sparkles,
  ShieldCheck,
  Award,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const CommercialSidebar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  const navItems = [
    {
      to: '/commercial',
      end: true,
      label: 'Accueil',
      icon: LayoutDashboard,
      badge: undefined,
    },
    {
      to: '/commercial/training-days',
      end: false,
      label: 'Formations',
      icon: BookOpen,
      badge: '3 Jours',
    },
    {
      to: '/commercial/progress',
      end: false,
      label: 'Progression',
      icon: BarChart3,
      badge: undefined,
    },
    {
      to: '/commercial/evaluations',
      end: false,
      label: 'Évaluations',
      icon: FileQuestion,
      badge: 'Quiz',
    },
    {
      to: '/commercial/profile',
      end: false,
      label: 'Mon Profil',
      icon: UserCheck,
      badge: undefined,
    },
  ];

  return (
    <aside
      id="commercial-sidebar"
      className="hidden lg:flex lg:flex-col w-72 shrink-0 min-h-screen sticky top-0 justify-between select-none p-5 z-30"
    >
      {/* Floating Glassmorphism Container */}
      <div className="flex-1 flex flex-col justify-between glass-card rounded-[32px] p-5 shadow-[0_16px_48px_rgba(36,27,34,0.06)] border border-white/90 overflow-hidden relative">
        {/* Subtle internal gradient accent */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#FCE7F3]/40 rounded-full blur-2xl pointer-events-none" />

        {/* Top Header & Brand */}
        <div className="space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-[#EFE6EB]">
            <div className="flex items-center gap-3">
              <img
                src="https://www.esthemax-morocco.com/wp-content/uploads/2023/12/esthemaxl-logo.png"
                alt="Esthemax Logo"
                className="h-9 w-auto object-contain"
              />
              <div className="flex flex-col">
                <span className="text-[10px] font-black uppercase tracking-widest text-[#D41472]">
                  Academy
                </span>
                <span className="text-[11px] font-semibold text-[#6E626B]">
                  Espace Commercial
                </span>
              </div>
            </div>
          </div>

          {/* User Preview Glass Pill */}
          {user && (
            <div className="p-3.5 rounded-2xl bg-white/80 border border-white/90 shadow-xs flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-2xl text-white font-extrabold flex items-center justify-center text-sm shadow-md"
                style={{ backgroundColor: '#D41472' }}
              >
                {user.name.charAt(0)}
              </div>
              <div className="overflow-hidden flex-1">
                <div className="text-xs font-extrabold text-[#1E161D] truncate flex items-center gap-1">
                  <span>{user.name}</span>
                </div>
                <div className="flex items-center gap-1 text-[11px] text-[#6E626B] font-medium">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span>Délégué Commercial</span>
                </div>
              </div>
            </div>
          )}

          {/* Navigation Links */}
          <nav className="space-y-1.5" aria-label="Navigation principale commerciale">
            <div className="text-[10px] font-extrabold uppercase tracking-wider text-[#6E626B] px-3 mb-2">
              Menu Principal
            </div>

            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.end}
                  className={({ isActive }) =>
                    `group flex items-center justify-between px-4 py-3 rounded-2xl text-xs font-bold transition-all duration-200 min-h-[46px] ${
                      isActive
                        ? 'bg-gradient-to-r from-[#FCE7F3] to-[#FDF0F5] text-[#D41472] shadow-xs border border-[#D41472]/20 translate-x-1'
                        : 'text-[#6E626B] hover:bg-white/60 hover:text-[#1E161D]'
                    }`
                  }
                >
                  {({ isActive }) => (
                    <>
                      <div className="flex items-center gap-3">
                        <Icon
                          className={`w-4 h-4 transition-colors ${
                            isActive ? 'text-[#D41472] stroke-[2.4]' : 'text-[#6E626B] group-hover:text-[#1E161D]'
                          }`}
                        />
                        <span>{item.label}</span>
                      </div>

                      {item.badge && (
                        <span
                          className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-[#D41472] text-white shadow-xs'
                              : 'bg-white/80 text-[#6E626B] border border-black/5'
                          }`}
                        >
                          {item.badge}
                        </span>
                      )}
                    </>
                  )}
                </NavLink>
              );
            })}
          </nav>
        </div>

        {/* Footer Area with Cert & Logout */}
        <div className="space-y-3 pt-4 border-t border-[#EFE6EB]">
          <div className="p-3.5 rounded-2xl bg-gradient-to-br from-[#FDF3E7]/80 to-white/90 border border-[#C59B27]/25 text-xs">
            <div className="flex items-center gap-1.5 font-bold mb-1 text-[#C59B27]">
              <Award className="w-4 h-4" />
              <span>Cursus Certifiant Commercial</span>
            </div>
            <p className="text-[10px] text-[#6E626B] font-medium leading-relaxed">
              Standard d'excellence Esthemax pour les professionnels de la beauté.
            </p>
          </div>

          <button
            type="button"
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2.5 px-4 py-3 rounded-2xl bg-white/70 hover:bg-white text-[#6E626B] hover:text-[#D41472] text-xs font-bold transition-all min-h-[44px] border border-white shadow-2xs hover:shadow-xs"
            aria-label="Se déconnecter de l'espace commercial"
          >
            <LogOut className="w-4 h-4 shrink-0" />
            <span>Déconnexion</span>
          </button>
        </div>
      </div>
    </aside>
  );
};

export default CommercialSidebar;
