import React from 'react';
import { Question } from '../../../types';
import { Check, Sparkles, HelpCircle } from 'lucide-react';

interface Props {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  selectedAnswer: string | string[] | undefined;
  onAnswerChange: (value: string | string[]) => void;
  disabled?: boolean;
}

export const CommercialQuestionCard: React.FC<Props> = ({
  question,
  questionNumber,
  totalQuestions,
  selectedAnswer,
  onAnswerChange,
  disabled = false,
}) => {
  const isMultiple = question.question_type === 'multiple_choice';
  const isSingle = question.question_type === 'single_choice';
  const isFreeText = question.question_type === 'free_text';

  const handleSingleSelect = (optionId: string) => {
    if (disabled) return;
    onAnswerChange(optionId);
  };

  const handleMultipleToggle = (optionId: string) => {
    if (disabled) return;
    const currentArray = Array.isArray(selectedAnswer) ? [...selectedAnswer] : [];
    const index = currentArray.indexOf(optionId);
    if (index > -1) {
      currentArray.splice(index, 1);
    } else {
      currentArray.push(optionId);
    }
    onAnswerChange(currentArray);
  };

  return (
    <div
      id={`question-${question.id}`}
        className={`glass-card rounded-[28px] p-6 sm:p-8 shadow-sm space-y-6 border border-white/90 ${disabled ? 'opacity-75' : ''}`}
    >
      {/* Question Subheader */}
      <div className="flex items-center justify-between gap-2 border-b border-[#EFE6EB] pb-4">
        <span className="text-xs uppercase tracking-wider font-black text-[#D41472]">
          Question {questionNumber} sur {totalQuestions}
        </span>
        <div className="flex items-center gap-2">
          {question.is_required && (
            <span className="text-[10px] font-bold text-[#C59B27] bg-[#FDF3E7] border border-[#C59B27]/20 px-2.5 py-0.5 rounded-full">
              Obligatoire
            </span>
          )}
          <span className="text-[10px] font-bold text-[#6E626B] bg-white/80 border border-[#EFE6EB] px-2.5 py-0.5 rounded-full">
            {isSingle && 'Choix unique'}
            {isMultiple && 'Choix multiples'}
            {isFreeText && 'Argumentaire libre'}
          </span>
        </div>
      </div>

      {/* Question Prompt */}
      <h2 className="text-lg sm:text-xl font-black text-[#1E161D] leading-snug">
        {question.question_text}
      </h2>

      {/* Single / Multiple Choice Options */}
      {(isSingle || isMultiple) && question.options && (
        <div className="space-y-3 pt-1" role={isSingle ? 'radiogroup' : 'group'}>
          {question.options.map((opt) => {
            const isChecked = isMultiple
              ? Array.isArray(selectedAnswer) && selectedAnswer.includes(opt.id)
              : selectedAnswer === opt.id;

            return (
              <div
                key={opt.id}
                onClick={() => (isMultiple ? handleMultipleToggle(opt.id) : handleSingleSelect(opt.id))}
                className={`flex items-start gap-4 p-4 sm:p-5 rounded-2xl ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'} select-none transition-all duration-200 min-h-[56px] ${
                  isChecked
                    ? 'border-2 border-[#D41472] bg-gradient-to-r from-[#FCE7F3]/80 to-[#FDF0F5]/80 shadow-xs translate-x-1'
                    : 'glass-card border-white/90 hover:border-gray-300 hover:bg-white'
                }`}
              >
                <div
                  className={`w-6 h-6 rounded-${isMultiple ? 'lg' : 'full'} border-2 flex items-center justify-center shrink-0 mt-0.5 transition-all ${
                    isChecked
                      ? 'border-[#D41472] bg-[#D41472] text-white shadow-xs'
                      : 'border-gray-300 bg-white'
                  }`}
                >
                  {isChecked && <Check className="w-4 h-4 stroke-[3]" />}
                </div>

                <span
                  className={`text-xs sm:text-sm leading-relaxed ${
                    isChecked ? 'font-extrabold text-[#1E161D]' : 'font-semibold text-[#6E626B]'
                  }`}
                >
                  {opt.text}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* Free text input */}
      {isFreeText && (
        <div className="space-y-2 pt-1">
          <label
            htmlFor={`input-${question.id}`}
            className="block text-xs font-bold text-[#6E626B] uppercase tracking-wider"
          >
            Votre réponse commerciale argumentée :
          </label>
          <textarea
            id={`input-${question.id}`}
            rows={4}
            value={typeof selectedAnswer === 'string' ? selectedAnswer : ''}
            onChange={(e) => onAnswerChange(e.target.value)}
            disabled={disabled}
            placeholder="Rédigez ici votre réponse ou argumentaire de vente..."
            className="w-full rounded-2xl glass-card border-white/90 p-4 text-xs sm:text-sm text-[#1E161D] placeholder-gray-400 focus:border-[#D41472] focus:ring-2 focus:ring-[#D41472]/20 focus:outline-none"
          />
        </div>
      )}
    </div>
  );
};

export default CommercialQuestionCard;
