import React from 'react';
import { CalloutContentBlock } from '../../../types';
import { Info, AlertTriangle, CheckCircle2, Lightbulb, Bookmark } from 'lucide-react';

interface Props {
  block: CalloutContentBlock;
}

export const CommercialCalloutBlock: React.FC<Props> = ({ block }) => {
  const { variant, title, message } = block.content;

  const config = {
    info: {
      bg: 'bg-blue-50/60',
      border: 'border-blue-200',
      text: 'text-blue-950',
      iconColor: 'text-blue-600',
      icon: Info,
      defaultTitle: 'Information',
    },
    warning: {
      bg: 'bg-amber-50/60',
      border: 'border-amber-200',
      text: 'text-amber-950',
      iconColor: 'text-[#C47A16]',
      icon: AlertTriangle,
      defaultTitle: 'Attention',
    },
    success: {
      bg: 'bg-emerald-50/60',
      border: 'border-emerald-200',
      text: 'text-emerald-950',
      iconColor: 'text-[#16866A]',
      icon: CheckCircle2,
      defaultTitle: 'Rentabilité & Succès',
    },
    tip: {
      bg: 'bg-[#FCE7F3]/40',
      border: 'border-[#FCE7F3]',
      text: 'text-[#241B22]',
      iconColor: 'text-[#D41472]',
      icon: Lightbulb,
      defaultTitle: 'Conseil Commercial Esthemax',
    },
    note: {
      bg: 'bg-[#FFF9F7]',
      border: 'border-[#F0E5E9]',
      text: 'text-[#241B22]',
      iconColor: 'text-[#D41472]',
      icon: Bookmark,
      defaultTitle: 'Note Importante',
    },
  }[variant || 'info'];

  const Icon = config.icon;

  return (
    <div
      id={`block-${block.id}`}
      className={`my-6 rounded-3xl border p-5 sm:p-6 ${config.bg} ${config.border} shadow-2xs`}
    >
      <div className="flex items-start gap-4">
        <div className={`p-2.5 rounded-2xl bg-white shadow-2xs shrink-0 ${config.iconColor}`}>
          <Icon className="w-5 h-5" />
        </div>
        <div className="space-y-1.5 flex-1">
          <h4 className={`text-sm font-bold tracking-tight ${config.text}`}>
            {title || config.defaultTitle}
          </h4>
          <p className="text-xs sm:text-sm leading-relaxed text-[#766A72] whitespace-pre-line">
            {message}
          </p>
        </div>
      </div>
    </div>
  );
};

export default CommercialCalloutBlock;
