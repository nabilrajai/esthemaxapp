import React, { useMemo } from 'react';
import { TrainingDayCodeProject } from '../../../types';
import { Sparkles } from 'lucide-react';

interface Props {
  codeProject: TrainingDayCodeProject;
}

export const CommercialCodeProjectViewer: React.FC<Props> = ({ codeProject }) => {
  // Only render if published
  if (codeProject.status !== 'published') {
    return null;
  }

  // Construct safe sandboxed document
  const srcDoc = useMemo(() => {
    const rawHtml = codeProject.html_code || '';
    const rawCss = codeProject.css_code || '';
    // Note: JS code is placed strictly inside sandboxed iframe without parent DOM access
    const rawJs = codeProject.js_code || '';

    return `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      padding: 0;
      font-family: 'Manrope', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: transparent;
      overflow-x: hidden;
    }
    ${rawCss}
  </style>
</head>
<body>
  ${rawHtml}
  <script>
    // Strict sandbox execution: No parent access
    try {
      ${rawJs}
    } catch (e) {
      console.warn('Interactive formation runtime script notice');
    }
  </script>
</body>
</html>`;
  }, [codeProject]);

  return (
    <div id="commercial-code-project-viewer" className="my-6">
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <span className="p-1.5 rounded-xl bg-[#FCE7F3] text-[#D41472]">
            <Sparkles className="w-4 h-4" />
          </span>
          <h4 className="text-sm font-bold text-[#241B22]">
            Atelier Visuel Interactif
          </h4>
        </div>
        {codeProject.version && (
          <span className="text-[11px] font-semibold text-[#766A72] bg-[#FFF9F7] border border-[#F0E5E9] px-2.5 py-0.5 rounded-full">
            v{codeProject.version}
          </span>
        )}
      </div>

      <div className="w-full bg-white border border-[#F0E5E9] rounded-3xl overflow-hidden shadow-sm">
        {/* Strictly sandboxed iframe: allow-scripts only, no allow-same-origin, no parent DOM, no storage access */}
        <iframe
          title="Atelier Visuel Interactif Esthemax"
          srcDoc={srcDoc}
          sandbox="allow-scripts"
          className="w-full min-h-[360px] md:min-h-[420px] border-0"
          loading="lazy"
        />
      </div>
    </div>
  );
};

export default CommercialCodeProjectViewer;
