import React from 'react';
import { ContentBlock } from '../../../types';
import CommercialTextBlock from './CommercialTextBlock';
import CommercialImageBlock from './CommercialImageBlock';
import CommercialVideoBlock from './CommercialVideoBlock';
import CommercialCalloutBlock from './CommercialCalloutBlock';
import CommercialProductCard from './CommercialProductCard';
import CommercialDocumentBlock from './CommercialDocumentBlock';

interface Props {
  block: ContentBlock;
}

export const CommercialContentBlockRenderer: React.FC<Props> = ({ block }) => {
  // STRICT RULE: Only render published blocks. Never render draft or archived!
  if (block.status !== 'published') {
    return null;
  }

  switch (block.type) {
    case 'text':
      return <CommercialTextBlock block={block} />;
    case 'image':
      return <CommercialImageBlock block={block} />;
    case 'video':
      return <CommercialVideoBlock block={block} />;
    case 'callout':
      return <CommercialCalloutBlock block={block} />;
    case 'product_card':
      return <CommercialProductCard block={block} />;
    case 'document':
      return <CommercialDocumentBlock block={block} />;
    default:
      return null;
  }
};

export default CommercialContentBlockRenderer;
