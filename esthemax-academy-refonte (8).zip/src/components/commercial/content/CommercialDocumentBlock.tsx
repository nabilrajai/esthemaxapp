import React from 'react';
import { DocumentContentBlock } from '../../../types';
import { FileText, Eye } from 'lucide-react';

interface Props {
  block: DocumentContentBlock;
}

export const CommercialDocumentBlock: React.FC<Props> = ({ block }) => {
  const { title, file_name, pages_count } = block.content;

  return (
    <div
      id={`block-${block.id}`}
      className="my-6 border border-[#F0E5E9] rounded-3xl bg-white p-5 sm:p-6 shadow-sm"
    >
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-[#FCE7F3] text-[#D41472] flex items-center justify-center shrink-0">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-[#241B22]">{title || file_name}</h4>
            <div className="flex items-center gap-2 text-xs text-[#766A72] mt-0.5">
              <span>Aperçu consultation en ligne</span>
              {pages_count && <span>• {pages_count} pages</span>}
            </div>
          </div>
        </div>

        {/* Note: NO download button! Purely in-app consultation */}
        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#FFF9F7] border border-[#F0E5E9] text-[#766A72] text-xs font-semibold">
          <Eye className="w-3.5 h-3.5 text-[#D41472]" />
          <span>Consultation sécurisée</span>
        </div>
      </div>

      {/* Embedded Document Preview container */}
      <div className="mt-4 p-6 bg-[#FFF9F7] rounded-2xl border border-dashed border-[#F0E5E9] text-center">
        <p className="text-xs text-[#241B22] font-semibold">
          Fiche mémo et guide technique affichés directement dans la liseuse Esthemax.
        </p>
        <p className="text-[11px] text-[#766A72] mt-1">
          (Protection de la propriété intellectuelle : les téléchargements de supports ne sont pas autorisés)
        </p>
      </div>
    </div>
  );
};

export default CommercialDocumentBlock;
