import React, { useState } from 'react';
import { ZoomIn, X } from 'lucide-react';
import { ImageContentBlock } from '../../../types';

interface Props {
  block: ImageContentBlock;
}

export const CommercialImageBlock: React.FC<Props> = ({ block }) => {
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const { url, alt, caption } = block.content;

  return (
    <div id={`block-${block.id}`} className="my-6">
      <div className="relative group overflow-hidden rounded-3xl border border-[#F0E5E9] bg-[#FFF9F7] shadow-sm">
        <img
          src={url}
          alt={alt || 'Image de formation Esthemax'}
          loading="lazy"
          referrerPolicy="no-referrer"
          className="w-full h-auto max-h-[500px] object-cover object-center transition-transform duration-300 group-hover:scale-[1.01]"
        />

        {/* Lightbox trigger overlay */}
        <button
          type="button"
          onClick={() => setIsLightboxOpen(true)}
          className="absolute bottom-3 right-3 p-2.5 rounded-2xl bg-[#241B22]/80 hover:bg-[#241B22] text-white transition-opacity flex items-center gap-1.5 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-[#D41472]"
          title="Agrandir l'image"
          aria-label="Agrandir l'image"
        >
          <ZoomIn className="w-4 h-4" />
          <span className="hidden sm:inline">Agrandir</span>
        </button>
      </div>

      {caption && (
        <p className="mt-2 text-center text-xs text-[#766A72] italic px-4">
          {caption}
        </p>
      )}

      {/* Lightbox Modal without any download option */}
      {isLightboxOpen && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4"
          onClick={() => setIsLightboxOpen(false)}
        >
          <div
            className="relative max-w-5xl max-h-[90vh] flex flex-col items-center"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              onClick={() => setIsLightboxOpen(false)}
              className="absolute -top-12 right-0 p-2 text-white hover:text-white bg-white/20 hover:bg-white/40 rounded-full transition-colors focus:outline-none"
              aria-label="Fermer"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={url}
              alt={alt || 'Image de formation Esthemax'}
              className="max-h-[80vh] w-auto object-contain rounded-2xl shadow-2xl"
              referrerPolicy="no-referrer"
            />
            {caption && (
              <div className="mt-3 text-white/90 text-sm text-center max-w-lg">
                {caption}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CommercialImageBlock;
