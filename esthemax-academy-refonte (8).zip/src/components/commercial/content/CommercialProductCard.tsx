import React from 'react';
import { ProductCardContentBlock } from '../../../types';
import { Sparkles, Package, Check, Tag, Clock } from 'lucide-react';

interface Props {
  block: ProductCardContentBlock;
}

export const CommercialProductCard: React.FC<Props> = ({ block }) => {
  const {
    product_name,
    tagline,
    description,
    image_url,
    pack_type,
    benefits,
    skin_types,
    key_ingredients,
    recommended_usage,
    price,
  } = block.content;

  return (
    <div
      id={`block-${block.id}`}
      className="my-6 glass-card rounded-[28px] overflow-hidden shadow-sm hover:shadow-md transition-all duration-200 border border-white/90"
    >
      <div className="grid grid-cols-1 md:grid-cols-12 gap-0">
        {/* Product Image section */}
        <div className="md:col-span-5 bg-gradient-to-br from-[#FAF7F5] to-[#FDF0F5] p-6 flex flex-col items-center justify-center border-b md:border-b-0 md:border-r border-[#EFE6EB]">
          {image_url ? (
            <img
              src={image_url}
              alt={product_name}
              loading="lazy"
              referrerPolicy="no-referrer"
              className="max-h-56 w-auto object-contain rounded-2xl drop-shadow-sm hover:scale-105 transition-transform duration-300"
            />
          ) : (
            <div className="w-32 h-32 rounded-3xl bg-[#FCE7F3] flex items-center justify-center text-[#D41472]">
              <Sparkles className="w-12 h-12" />
            </div>
          )}

          {pack_type && (
            <div className="mt-4 inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-white/90 border border-white text-xs font-bold text-[#6E626B] shadow-2xs">
              <Package className="w-3.5 h-3.5 text-[#D41472]" />
              <span>{pack_type}</span>
            </div>
          )}
        </div>

        {/* Product Information */}
        <div className="md:col-span-7 p-6 sm:p-8 flex flex-col justify-between space-y-4">
          <div>
            <div className="flex items-center justify-between gap-2 mb-1.5">
              <span className="text-xs uppercase tracking-wider font-black text-[#D41472]">
                Fiche Produit Esthemax
              </span>
              {price && (
                <span className="inline-flex items-center gap-1 text-xs font-bold px-3 py-1 rounded-full bg-emerald-50 text-[#16866A] border border-emerald-200">
                  <Tag className="w-3 h-3" />
                  {price}
                </span>
              )}
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-[#1E161D]">{product_name}</h3>
            {tagline && (
              <p className="text-xs font-bold text-[#D41472] uppercase tracking-wide mt-0.5">
                {tagline}
              </p>
            )}

            <p className="text-xs sm:text-sm text-[#6E626B] mt-3 leading-relaxed">{description}</p>
          </div>

          {/* Benefits list */}
          {benefits && benefits.length > 0 && (
            <div className="space-y-2 pt-1">
              <h4 className="text-xs font-black text-[#1E161D] uppercase tracking-wider">
                Bénéfices Clés Cabine :
              </h4>
              <ul className="grid grid-cols-1 gap-1.5">
                {benefits.map((benefit, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-xs text-[#6E626B] font-medium">
                    <Check className="w-3.5 h-3.5 text-[#D41472] shrink-0 mt-0.5 stroke-[2.5]" />
                    <span>{benefit}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Badges: skin types and key ingredients */}
          <div className="flex flex-wrap gap-2 pt-3 border-t border-[#EFE6EB]">
            {skin_types?.map((skin, idx) => (
              <span
                key={idx}
                className="text-[11px] font-bold bg-white/80 text-[#1E161D] border border-white px-2.5 py-0.5 rounded-full shadow-2xs"
              >
                {skin}
              </span>
            ))}
            {key_ingredients?.map((ing, idx) => (
              <span
                key={idx}
                className="text-[11px] font-bold bg-[#FCE7F3] text-[#D41472] border border-[#FCE7F3] px-2.5 py-0.5 rounded-full"
              >
                {ing}
              </span>
            ))}
          </div>

          {recommended_usage && (
            <div className="bg-[#FAF7F5] p-3.5 rounded-2xl border border-[#EFE6EB] flex items-start gap-2.5 text-xs text-[#6E626B]">
              <Clock className="w-4 h-4 text-[#D41472] shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-[#1E161D]">Usage conseillé : </span>
                <span>{recommended_usage}</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CommercialProductCard;
