import React from 'react';
import DOMPurify from 'dompurify';
import { TextContentBlock } from '../../../types';

interface Props {
  block: TextContentBlock;
}

export const CommercialTextBlock: React.FC<Props> = ({ block }) => {
  const rawHtml = block.content.html || (block.content.text ? `<p>${block.content.text.replace(/\n/g, '<br/>')}</p>` : '');

  // Strict sanitization rules: allow only safe tags & attributes, ban scripts, event handlers, javascript:
  const sanitizedHtml = DOMPurify.sanitize(rawHtml, {
    ALLOWED_TAGS: [
      'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
      'p', 'b', 'i', 'strong', 'em', 'span', 'u', 's',
      'ul', 'ol', 'li', 'blockquote', 'pre', 'code', 'br', 'hr',
      'table', 'thead', 'tbody', 'tr', 'th', 'td'
    ],
    ALLOWED_ATTR: ['href', 'title', 'target', 'rel', 'class', 'style'],
    FORBID_TAGS: ['script', 'style', 'iframe', 'object', 'embed', 'form', 'input'],
    FORBID_ATTR: ['onerror', 'onload', 'onclick', 'onmouseover', 'data-*'],
  });

  return (
    <div
      id={`block-${block.id}`}
      className="prose prose-slate max-w-none text-[#241B22] leading-relaxed font-normal
        prose-headings:text-[#241B22] prose-headings:font-extrabold prose-headings:tracking-tight
        prose-h2:text-2xl prose-h2:mt-6 prose-h2:mb-3 prose-h2:border-b prose-h2:border-[#F0E5E9] prose-h2:pb-2
        prose-h3:text-lg prose-h3:mt-5 prose-h3:mb-2 prose-h3:text-[#D41472]
        prose-p:my-3.5 prose-p:text-sm md:prose-p:text-base prose-p:leading-relaxed prose-p:text-[#766A72]
        prose-ul:my-3 prose-ul:list-disc prose-ul:pl-5
        prose-ol:my-3 prose-ol:list-decimal prose-ol:pl-5
        prose-li:my-1.5 prose-li:text-sm md:prose-li:text-base prose-li:text-[#766A72]
        prose-blockquote:border-l-4 prose-blockquote:border-[#D41472] prose-blockquote:pl-4 prose-blockquote:italic prose-blockquote:text-[#241B22] prose-blockquote:bg-[#FFF9F7] prose-blockquote:py-2.5 prose-blockquote:rounded-r-2xl prose-blockquote:my-4
        prose-strong:font-bold prose-strong:text-[#241B22]
        prose-table:w-full prose-table:border-collapse prose-table:my-4
        prose-th:border prose-th:border-[#F0E5E9] prose-th:p-3 prose-th:bg-[#FFF9F7] prose-th:text-left prose-th:text-xs prose-th:font-bold prose-th:text-[#241B22]
        prose-td:border prose-td:border-[#F0E5E9] prose-td:p-3 prose-td:text-xs md:prose-td:text-sm text-[#766A72]"
      dangerouslySetInnerHTML={{ __html: sanitizedHtml }}
    />
  );
};

export default CommercialTextBlock;
