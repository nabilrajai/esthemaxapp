import React from 'react';
import { VideoContentBlock } from '../../../types';
import { Play } from 'lucide-react';

interface Props {
  block: VideoContentBlock;
}

export const CommercialVideoBlock: React.FC<Props> = ({ block }) => {
  const { url, title, duration_seconds } = block.content;

  // Safe URL validation: only allow YouTube (youtube.com, youtu.be, youtube-nocookie.com) or Vimeo (vimeo.com, player.vimeo.com)
  const getSafeEmbedUrl = (rawUrl: string): string | null => {
    if (!rawUrl || typeof rawUrl !== 'string') return null;
    const trimmed = rawUrl.trim();

    try {
      const parsed = new URL(trimmed);
      const hostname = parsed.hostname.toLowerCase();

      // YouTube embeds
      if (
        hostname.includes('youtube.com') ||
        hostname.includes('youtu.be') ||
        hostname.includes('youtube-nocookie.com')
      ) {
        let videoId = '';
        if (hostname.includes('youtu.be')) {
          videoId = parsed.pathname.replace(/^\//, '');
        } else if (parsed.pathname.includes('/embed/')) {
          videoId = parsed.pathname.split('/embed/')[1];
        } else {
          videoId = parsed.searchParams.get('v') || '';
        }

        // Clean video ID to alphanumeric and safe characters
        videoId = videoId.replace(/[^a-zA-Z0-9_-]/g, '');
        if (videoId) {
          return `https://www.youtube-nocookie.com/embed/${videoId}?rel=0&modestbranding=1`;
        }
      }

      // Vimeo embeds
      if (hostname.includes('vimeo.com')) {
        const parts = parsed.pathname.split('/').filter(Boolean);
        const vimeoId = parts[parts.length - 1]?.replace(/[^0-9]/g, '');
        if (vimeoId) {
          return `https://player.vimeo.com/video/${vimeoId}?dnt=1&title=0&byline=0`;
        }
      }
    } catch (e) {
      return null;
    }

    return null;
  };

  const safeEmbedUrl = getSafeEmbedUrl(url);

  return (
    <div id={`block-${block.id}`} className="my-6 space-y-2.5">
      {title && (
        <div className="flex items-center gap-2 text-sm font-bold text-[#241B22]">
          <Play className="w-4 h-4 text-[#D41472]" />
          <span>{title}</span>
          {duration_seconds && (
            <span className="text-xs text-[#766A72] font-normal">
              ({Math.floor(duration_seconds / 60)} min {duration_seconds % 60 ? `${duration_seconds % 60}s` : ''})
            </span>
          )}
        </div>
      )}

      <div className="relative w-full aspect-video rounded-3xl overflow-hidden bg-black border border-[#F0E5E9] shadow-sm">
        {safeEmbedUrl ? (
          <iframe
            src={safeEmbedUrl}
            title={title || 'Vidéo de formation Esthemax'}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
            loading="lazy"
            className="absolute top-0 left-0 w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-presentation"
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-white/70 p-6 text-center">
            <Play className="w-10 h-10 mb-2 text-[#766A72]" />
            <p className="text-sm">Vidéo en cours de traitement ou source non certifiée.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CommercialVideoBlock;
