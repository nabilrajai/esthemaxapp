import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import { getAuthToken, setAuthToken } from '../api/client';
import { loginUser, logoutUser } from '../api/commercialApi';
import { DEMO_USERS } from '../data/mockData';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isCommercial: boolean;
  isAdmin: boolean;
  login: (email: string, password: string, remember?: boolean) => Promise<User>;
  logout: () => Promise<void>;
  updateProfile: (updatedData: Partial<User>) => Promise<User>;
  switchDemoUser: (userKey: keyof typeof DEMO_USERS) => void;
  sessionExpiredNotice: boolean;
  clearSessionExpiredNotice: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const USER_STORAGE_KEY = 'esthemax_auth_user';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem(USER_STORAGE_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });
  const [token, setToken] = useState<string | null>(() => getAuthToken());
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [sessionExpiredNotice, setSessionExpiredNotice] = useState<boolean>(false);

  useEffect(() => {
    // Listen for session expiration events from API client
    const handleSessionExpired = () => {
      setUser(null);
      setToken(null);
      localStorage.removeItem(USER_STORAGE_KEY);
      setSessionExpiredNotice(true);
    };

    window.addEventListener('esthemax:session-expired', handleSessionExpired);
    return () => {
      window.removeEventListener('esthemax:session-expired', handleSessionExpired);
    };
  }, []);

  const login = async (email: string, password: string, remember = false): Promise<User> => {
    setIsLoading(true);
    setSessionExpiredNotice(false);
    try {
      const res = await loginUser(email, password, remember);
      setUser(res.user);
      setToken(res.token);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(res.user));
      return res.user;
    } finally {
      setIsLoading(false);
    }
  };

  const updateProfile = async (updatedData: Partial<User>): Promise<User> => {
    if (!user) throw new Error('Utilisateur non connecté');
    const newUser: User = {
      ...user,
      ...updatedData,
    };
    setUser(newUser);
    localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(newUser));
    return newUser;
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      await logoutUser();
    } finally {
      setUser(null);
      setToken(null);
      localStorage.removeItem(USER_STORAGE_KEY);
      setAuthToken(null);
      setIsLoading(false);
    }
  };

  const switchDemoUser = (userKey: keyof typeof DEMO_USERS) => {
    const selected = DEMO_USERS[userKey];
    if (selected) {
      setUser(selected);
      const fakeToken = `token_${selected.id}`;
      setToken(fakeToken);
      setAuthToken(fakeToken);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(selected));
    }
  };

  const clearSessionExpiredNotice = () => {
    setSessionExpiredNotice(false);
  };

  const isAuthenticated = !!user && !!token;
  const isCommercial = user?.role === 'commercial';
  const isAdmin = user?.role === 'admin';

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isLoading,
        isAuthenticated,
        isCommercial,
        isAdmin,
        login,
        logout,
        updateProfile,
        switchDemoUser,
        sessionExpiredNotice,
        clearSessionExpiredNotice,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
