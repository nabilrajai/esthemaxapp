import { TrainingDay, ContentModule, Assessment, CommercialProgress, User } from '../types';

export const DEMO_USERS: Record<string, User> = {
  active_commercial: {
    id: 'e0123456-789a-bcde-f012-3456789abcde',
    name: 'Sophie Laurent',
    email: 'sophie.laurent@esthemax.com',
    role: 'commercial',
    phone: '+33 6 12 34 56 78',
    region: 'Île-de-France & Nord',
    sector: 'Instituts & Spas Premium',
    avatar_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80',
    status: 'active',
    last_login_at: '2026-09-12T14:30:00Z',
    created_at: '2026-01-15T09:00:00Z',
  },
  new_commercial: {
    id: 'f1234567-89ab-cdef-0123-456789abcdef',
    name: 'Thomas Morel',
    email: 'thomas.morel@esthemax.com',
    role: 'commercial',
    phone: '+33 6 98 76 54 32',
    region: 'Auvergne-Rhône-Alpes',
    sector: 'Cliniques Esthétiques',
    avatar_url: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=150&auto=format&fit=crop&q=80',
    status: 'active',
    last_login_at: '2026-09-13T08:15:00Z',
    created_at: '2026-09-10T10:00:00Z',
  },
  completed_commercial: {
    id: 'a9876543-210f-edcb-a987-6543210fedcb',
    name: 'Élodie Bernard',
    email: 'elodie.bernard@esthemax.com',
    role: 'commercial',
    phone: '+33 6 45 67 89 01',
    region: 'Provence-Alpes-Côte d’Azur',
    sector: 'Hotels & Spas de Luxe',
    avatar_url: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&auto=format&fit=crop&q=80',
    status: 'active',
    last_login_at: '2026-09-11T16:45:00Z',
    created_at: '2025-11-01T09:00:00Z',
  },
  blocked_user: {
    id: 'b5555555-5555-5555-5555-555555555555',
    name: 'Marc Lefebvre',
    email: 'marc.lefebvre@esthemax.com',
    role: 'commercial',
    phone: '+33 6 00 11 22 33',
    region: 'Grand Est',
    sector: 'Distribution',
    status: 'blocked',
    last_login_at: '2026-08-20T11:00:00Z',
    created_at: '2025-06-01T09:00:00Z',
  },
  admin_user: {
    id: 'c7777777-7777-7777-7777-777777777777',
    name: 'Claire Dupont',
    email: 'claire.dupont@esthemax.com',
    role: 'admin',
    phone: '+33 1 40 00 00 00',
    region: 'Siège International',
    sector: 'Direction de la Formation',
    status: 'active',
    last_login_at: '2026-09-13T07:00:00Z',
    created_at: '2025-01-01T09:00:00Z',
  },
};

// UUIDs for training days
export const TRAINING_DAY_IDS = {
  J1: '4f29a0e6-b6df-4a6c-9c71-2e6f4a8d0111',
  J2: '8c91b5f2-d421-4f90-a35b-7b8c2d1e0222',
  J3: 'd173c8a9-e854-46c2-b914-9e3f1c4a0333',
};

// UUIDs for modules
export const MODULE_IDS = {
  J1_M1: '11111111-aaaa-4444-8888-000000000001',
  J1_M2: '11111111-aaaa-4444-8888-000000000002',
  J1_M3: '11111111-aaaa-4444-8888-000000000003',
  J1_M4: '11111111-aaaa-4444-8888-000000000004',
  J2_M1: '22222222-bbbb-4444-8888-000000000001',
  J2_M2: '22222222-bbbb-4444-8888-000000000002',
  J2_M3: '22222222-bbbb-4444-8888-000000000003',
  J3_M1: '33333333-cccc-4444-8888-000000000001',
  J3_M2: '33333333-cccc-4444-8888-000000000002',
};

export const INITIAL_TRAINING_DAYS: TrainingDay[] = [
  {
    id: TRAINING_DAY_IDS.J1,
    code: 'J1',
    title: 'Marque et Produits',
    theme: 'Histoire Esthemax, Technologie Électrolytes & Masques Hydrojelly',
    description:
      'Découvrez les fondements de la marque Esthemax, la science révolutionnaire des électrolytes, la gamme complète des masques Hydrojelly et les protocoles cabine professionnels.',
    status: 'in_progress',
    sort_order: 1,
    modules_count: 4,
    completed_modules_count: 3,
    progress_percentage: 75,
    estimated_duration_minutes: 90,
    assessment_id: '99999999-1111-4444-8888-aaaaaaaaaaaa',
    assessment_status: 'pending',
    assessment_score: null,
    code_project: {
      id: 'cp-00000001-j1-code-project',
      training_day_id: TRAINING_DAY_IDS.J1,
      status: 'published',
      version: '1.4.0',
      html_code: `
        <div style="font-family: 'Segoe UI', sans-serif; padding: 24px; color: #0F243E; background: linear-gradient(135deg, #F8F9FA 0%, #EFF6F7 100%); border-radius: 12px;">
          <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 20px;">
            <div style="background: #0D9488; color: white; padding: 6px 14px; border-radius: 20px; font-weight: bold; font-size: 13px;">ESTHEMAX ACADEMY</div>
            <h2 style="margin: 0; font-size: 20px; color: #0F243E;">Guide Visuel Interactif : Protocole Hydrojelly</h2>
          </div>
          <p style="color: #4B5563; line-height: 1.6; margin-bottom: 20px;">
            Le masque Hydrojelly est formulé à base d'alginate raffiné et d'électrolytes purs pour restaurer l'équilibre osmotique cutané instantanément après tout soin esthétique.
          </p>
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-top: 16px;">
            <div style="background: white; padding: 16px; border-radius: 8px; border: 1px solid #E5E7EB; text-align: center;">
              <span style="display: inline-block; width: 36px; height: 36px; line-height: 36px; background: #E6FFFA; color: #0D9488; border-radius: 50%; font-weight: bold; margin-bottom: 8px;">1</span>
              <div style="font-weight: 600; color: #1F2937;">Dosage Précis</div>
              <div style="font-size: 13px; color: #6B7280; margin-top: 4px;">1,5 doseur poudre + 1 doseur eau purifiée fraîche</div>
            </div>
            <div style="background: white; padding: 16px; border-radius: 8px; border: 1px solid #E5E7EB; text-align: center;">
              <span style="display: inline-block; width: 36px; height: 36px; line-height: 36px; background: #E6FFFA; color: #0D9488; border-radius: 50%; font-weight: bold; margin-bottom: 8px;">2</span>
              <div style="font-weight: 600; color: #1F2937;">Mélange Rapide</div>
              <div style="font-size: 13px; color: #6B7280; margin-top: 4px;">Fouetter 60s énergiquement jusqu'à consistance lisse</div>
            </div>
            <div style="background: white; padding: 16px; border-radius: 8px; border: 1px solid #E5E7EB; text-align: center;">
              <span style="display: inline-block; width: 36px; height: 36px; line-height: 36px; background: #E6FFFA; color: #0D9488; border-radius: 50%; font-weight: bold; margin-bottom: 8px;">3</span>
              <div style="font-weight: 600; color: #1F2937;">Application & Retrait</div>
              <div style="font-size: 13px; color: #6B7280; margin-top: 4px;">Poser 15 à 20 min puis décoller en une seule pièce</div>
            </div>
          </div>
        </div>
      `,
      css_code: 'body { margin: 0; padding: 0; }',
      js_code: '// Visual component',
    },
  },
  {
    id: TRAINING_DAY_IDS.J2,
    code: 'J2',
    title: 'Force de Vente',
    theme: 'Techniques Commerciales, Pitch Instituts & Gestion des Objections',
    description:
      'Maîtrisez l’argumentaire de vente B2B Esthemax : calcul de rentabilité pour les esthéticiennes, construction d’offres d’implantation, et traitement des objections fréquentes.',
    status: 'available',
    sort_order: 2,
    modules_count: 3,
    completed_modules_count: 0,
    progress_percentage: 0,
    estimated_duration_minutes: 75,
    assessment_id: '99999999-2222-4444-8888-bbbbbbbbbbbb',
    assessment_status: 'not_started',
    assessment_score: null,
  },
  {
    id: TRAINING_DAY_IDS.J3,
    code: 'J3',
    title: 'Clients Potentiels',
    theme: 'Ciblage Spas, Cliniques Médico-Esthétiques & Suivi Portefeuille',
    description:
      'Identifiez les prospects cibles à forte valeur ajoutée, structurez vos visites terrain et pérennisez vos réapprovisionnements grâce au programme partenaire Esthemax.',
    status: 'locked',
    sort_order: 3,
    lock_reason: 'Complétez et validez l’évaluation de la Journée J2 pour débloquer cette formation.',
    modules_count: 2,
    completed_modules_count: 0,
    progress_percentage: 0,
    estimated_duration_minutes: 60,
    assessment_id: '99999999-3333-4444-8888-cccccccccccc',
    assessment_status: 'locked',
    assessment_score: null,
  },
];

export const MOCK_MODULES: Record<string, ContentModule[]> = {
  [TRAINING_DAY_IDS.J1]: [
    {
      id: MODULE_IDS.J1_M1,
      training_day_id: TRAINING_DAY_IDS.J1,
      title: 'Introduction à la Marque Esthemax',
      summary: 'Genèse internationale, positionnement professionnel et vision de la beauté personnalisée.',
      sort_order: 1,
      status: 'published',
      estimated_read_minutes: 15,
      is_completed: true,
      viewed_at: '2026-09-12T10:15:00Z',
      blocks_count: 4,
      content_blocks: [
        {
          id: 'b1111111-0001-4444-8888-000000000001',
          module_id: MODULE_IDS.J1_M1,
          sort_order: 1,
          status: 'published',
          type: 'text',
          content: {
            html: `
              <h2>Une Référence Mondiale des Soins Esthétiques Professionnels</h2>
              <p>Fondée en 1995, <strong>Esthemax</strong> s'est imposée comme la marque de prédilection des esthéticiennes, dermatologues et spas de luxe à travers plus de 60 pays.</p>
              <p>Notre mission : fournir aux professionnels des solutions de pointe, ultra-concentrées et hautement personnalisables, garantissant des résultats spectaculaires dès la première séance.</p>
              <h3>Nos Piliers Fondamentaux</h3>
              <ul>
                <li><strong>Innovation continue :</strong> Formulations avant-gardistes intégrant des extraits marins, des alginates nobles et des électrolytes essentiels.</li>
                <li><strong>Excellence cabine :</strong> Produits conçus exclusivement pour maximiser la satisfaction client et la rentabilité du praticien.</li>
                <li><strong>Éco-responsabilité :</strong> Ingrédients éthiques, biodégradables, sans sulfates ni parabènes, non testés sur les animaux.</li>
              </ul>
            `,
          },
        },
        {
          id: 'b1111111-0002-4444-8888-000000000002',
          module_id: MODULE_IDS.J1_M1,
          sort_order: 2,
          status: 'published',
          type: 'callout',
          content: {
            variant: 'tip',
            title: 'Conseil Commercial Clé',
            message:
              'Lorsque vous présentez Esthemax à un nouveau gérant d’institut, mettez l’accent sur la viralité des masques Hydrojelly sur Instagram et TikTok (+2,4 milliards de vues). C’est un levier d’attraction client immédiat pour leur salon.',
          },
        },
        {
          id: 'b1111111-0003-4444-8888-000000000003',
          module_id: MODULE_IDS.J1_M1,
          sort_order: 3,
          status: 'published',
          type: 'image',
          content: {
            url: 'https://images.unsplash.com/photo-1570172619644-dfd03ed5d881?w=900&auto=format&fit=crop&q=80',
            alt: 'Institut de beauté partenaire Esthemax',
            caption: 'Espace cabine Esthemax aménagé au sein d’un spa premium partenaire.',
          },
        },
        {
          id: 'b1111111-0004-4444-8888-000000000004',
          module_id: MODULE_IDS.J1_M1,
          sort_order: 4,
          status: 'published',
          type: 'callout',
          content: {
            variant: 'info',
            title: 'Positionnement Prix & Distribution',
            message:
              'Esthemax pratique une politique stricte de distribution réservée aux professionnels qualifiés. Aucun consommateur final ne peut acheter les formats cabine en grande surface ou sur Amazon.',
          },
        },
      ],
    },
    {
      id: MODULE_IDS.J1_M2,
      training_day_id: TRAINING_DAY_IDS.J1,
      title: 'La Révolution des Masques Hydrojelly®',
      summary: 'La technologie osmotique, composition alchimique et catalogue des best-sellers.',
      sort_order: 2,
      status: 'published',
      estimated_read_minutes: 25,
      is_completed: true,
      viewed_at: '2026-09-12T11:40:00Z',
      blocks_count: 5,
      content_blocks: [
        {
          id: 'b1111111-0005-4444-8888-000000000005',
          module_id: MODULE_IDS.J1_M2,
          sort_order: 1,
          status: 'published',
          type: 'text',
          content: {
            html: `
              <h2>Pourquoi le Masque Hydrojelly® est Unique au Monde</h2>
              <p>Contrairement aux masques alginates traditionnels qui durcissent et peuvent assécher l'épiderme, l'<strong>Hydrojelly®</strong> incorpore une matrice d'électrolytes brevetée.</p>
              <p>En créant un joint sous vide étanche sur le visage, il force la pénétration des sérums préalablement appliqués par osmose active.</p>
              <blockquote>
                « L'eau seule ne peut pas hydrater la peau si les électrolytes sont déficients. Nos masques rétablissent le potentiel hydrique intracellulaire. »
              </blockquote>
            `,
          },
        },
        {
          id: 'b1111111-0006-4444-8888-000000000006',
          module_id: MODULE_IDS.J1_M2,
          sort_order: 2,
          status: 'published',
          type: 'product_card',
          content: {
            product_name: 'Hydrojelly® 24K Gold & Truffle',
            tagline: 'Soin Rajeunissant & Éclat Précieux',
            description:
              'Enrichi en particules d’or 24 carats pures et extrait de truffe blanche d’Alba. Stimule la synthèse de collagène, raffermit l’ovale du visage et procure une luminosité immédiate.',
            image_url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600&auto=format&fit=crop&q=80',
            pack_type: 'Boîte professionnelle de 2 traitements (poudre + doseur)',
            benefits: [
              'Action anti-âge tenseur immédiate',
              'Renforce la barrière cutanée lipidique',
              'Effet coup d’éclat spectaculaire post-peeling',
            ],
            skin_types: ['Peaux matures', 'Peaux atones', 'Perte de fermeté'],
            key_ingredients: ['Or pur 24K', 'Truffe blanche', 'Alginate de potassium', 'Électrolytes'],
            recommended_usage: 'En fin de soin anti-âge ou protocole Glow intense. Temps de pose : 20 minutes.',
            price: 'Tarif pro conseillé : 38,00 € HT par pack',
          },
        },
        {
          id: 'b1111111-0007-4444-8888-000000000007',
          module_id: MODULE_IDS.J1_M2,
          sort_order: 3,
          status: 'published',
          type: 'product_card',
          content: {
            product_name: 'Hydrojelly® Vampire PLLA Infusion',
            tagline: 'Volumateur & Densifiant Cutané',
            description:
              'Formulé avec du Poly-L-Lactic Acid (PLLA), le même composant biodégradable utilisé dans les fils tenseurs médicaux. Réfère et redonne du volume aux zones creusées.',
            image_url: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=600&auto=format&fit=crop&q=80',
            pack_type: 'Pot pro 500g (environ 25 applications)',
            benefits: [
              'Atténue les rides et ridules d’expression',
              'Améliore la densité dermique',
              'Complément idéal après microneedling ou radiofréquence',
            ],
            skin_types: ['Rides profondes', 'Peaux relâchées', 'Prévention anti-âge'],
            key_ingredients: ['PLLA (Poly-L-Lactic Acid)', 'Collagène hydrolysé', 'Acide hyaluronique'],
            recommended_usage: 'Après une séance de microneedling pour sceller les actifs.',
          },
        },
        {
          id: 'b1111111-0008-4444-8888-000000000008',
          module_id: MODULE_IDS.J1_M2,
          sort_order: 4,
          status: 'published',
          type: 'product_card',
          content: {
            product_name: 'Hydrojelly® Purifying Activated Charcoal',
            tagline: 'Détoxifiant & Régulateur de Sébum',
            description:
              'Charbon actif de bambou microporeux et poudre d’arbre à thé. Absorbe l’excès de sébum, désincruste les pores et apaise les rougeurs inflammatoires.',
            image_url: 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=600&auto=format&fit=crop&q=80',
            pack_type: 'Pot pro 500g',
            benefits: [
              'Purifie sans dessécher l’épiderme',
              'Resserre visiblement le grain de peau',
              'Action antibactérienne ciblée',
            ],
            skin_types: ['Peaux grasses', 'Acnéiques', 'Teints ternes pollués'],
            key_ingredients: ['Charbon actif', 'Tea Tree australien', 'Extrait de saule blanc'],
            recommended_usage: 'Idéal après un nettoyage de peau profond ou hydrodermabrasion.',
          },
        },
        {
          id: 'b1111111-0009-4444-8888-000000000009',
          module_id: MODULE_IDS.J1_M2,
          sort_order: 5,
          status: 'published',
          type: 'callout',
          content: {
            variant: 'success',
            title: 'Marge Praticien Exceptionnelle',
            message:
              'Un pot de 500g coûte environ 45 € HT et permet 25 applications (1,80 € par soin). Facturé entre 20 € et 35 € en supplément cabine, le taux de marge brute dépasse 90% pour l’institut.',
          },
        },
      ],
    },
    {
      id: MODULE_IDS.J1_M3,
      training_day_id: TRAINING_DAY_IDS.J1,
      title: 'Ampoules, Sérums & Poudres Exfoliantes',
      summary: 'Compléments de soins essentiels : Curette Enzyme Powder, Ampoules Stériles et Masques LED.',
      sort_order: 3,
      status: 'published',
      estimated_read_minutes: 20,
      is_completed: true,
      viewed_at: '2026-09-12T15:10:00Z',
      blocks_count: 3,
      content_blocks: [
        {
          id: 'b1111111-0010-4444-8888-000000000010',
          module_id: MODULE_IDS.J1_M3,
          sort_order: 1,
          status: 'published',
          type: 'text',
          content: {
            html: `
              <h2>La Préparation Cutanée : Étape Indispensable</h2>
              <p>Pour garantir l'adhésion parfaite et l'efficacité optimale d'un masque Hydrojelly, la préparation cutanée doit éliminer les cellules mortes sans altérer le film hydrolipidique.</p>
              <h3>Le Nettoyant Enzymatique en Poudre</h3>
              <p>Formulé avec de la papaïne naturelle et de l'allantoïne, ce nettoyant moussant doux s'active au contact de l'eau. Il prépare idéalement la peau à recevoir les principes actifs.</p>
            `,
          },
        },
        {
          id: 'b1111111-0011-4444-8888-000000000011',
          module_id: MODULE_IDS.J1_M3,
          sort_order: 2,
          status: 'published',
          type: 'product_card',
          content: {
            product_name: 'Curette Enzyme Powder Wash',
            tagline: 'Nettoyant Exfoliant Enzymatique Doux',
            description:
              'Poudre micro-fine d’origine végétale activée par l’eau tiède. Élimine les impuretés superficielles, désobstrue les pores et illumine le teint.',
            image_url: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=600&auto=format&fit=crop&q=80',
            pack_type: 'Flacon poudreur 225g',
            benefits: [
              'Exfoliation non abrasive respectant la sensibilité cutanée',
              'Texture mousse soyeuse luxueuse',
              'Prépare parfaitement au protocole Hydrojelly',
            ],
            skin_types: ['Tous types de peaux, y compris sensibles et réactives'],
            key_ingredients: ['Papaïne', 'Extrait d’allantoïne', 'Amidon de maïs'],
          },
        },
        {
          id: 'b1111111-0012-4444-8888-000000000012',
          module_id: MODULE_IDS.J1_M3,
          sort_order: 3,
          status: 'published',
          type: 'callout',
          content: {
            variant: 'warning',
            title: 'Règle de Sécurité Produit',
            message:
              'Ne jamais utiliser d’exfoliants physiques à gros grains (type noyaux d’abricot) avant un masque Hydrojelly occlusif sur une peau à tendance couperosique.',
          },
        },
      ],
    },
    {
      id: MODULE_IDS.J1_M4,
      training_day_id: TRAINING_DAY_IDS.J1,
      title: 'Protocoles de Pose & Démonstration Cabine',
      summary: 'Vidéo pas à pas, technique de spatulage et erreurs fréquentes à éviter.',
      sort_order: 4,
      status: 'published',
      estimated_read_minutes: 20,
      is_completed: false,
      viewed_at: null,
      blocks_count: 4,
      content_blocks: [
        {
          id: 'b1111111-0013-4444-8888-000000000013',
          module_id: MODULE_IDS.J1_M4,
          sort_order: 1,
          status: 'published',
          type: 'text',
          content: {
            html: `
              <h2>La Maîtrise Technique : Votre Meilleur Atout Commercial</h2>
              <p>En tant que délégué commercial Esthemax, vous devez être capable de <strong>réaliser un masque parfait</strong> en démonstration chez un client en moins de 3 minutes.</p>
              <p>Voici les 4 règles d'or à enseigner aux praticiennes :</p>
              <ol>
                <li><strong>Ratio eau/poudre :</strong> Utilisez toujours les doseurs Esthemax fournis pour éviter un mélange trop liquide ou trop pâteux.</li>
                <li><strong>Température de l'eau :</strong> Eau fraîche (18-20°C). Une eau tiède accélère la polymérisation et réduit le temps d'application.</li>
                <li><strong>Application des bords :</strong> Créer des bordures épaisses pour faciliter le décollement en une pièce sans résidus.</li>
                <li><strong>Recouvrement :</strong> Les masques Hydrojelly peuvent couvrir les yeux et les lèvres fermées (avec l'accord préalable de la cliente).</li>
              </ol>
            `,
          },
        },
        {
          id: 'b1111111-0014-4444-8888-000000000014',
          module_id: MODULE_IDS.J1_M4,
          sort_order: 2,
          status: 'published',
          type: 'video',
          content: {
            url: 'https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ',
            title: 'Tutoriel Professionnel : Application Parfaite du Masque Hydrojelly',
            provider: 'youtube',
            duration_seconds: 340,
          },
        },
        {
          id: 'b1111111-0015-4444-8888-000000000015',
          module_id: MODULE_IDS.J1_M4,
          sort_order: 3,
          status: 'published',
          type: 'callout',
          content: {
            variant: 'tip',
            title: 'Démonstration en Institut',
            message:
              'Proposez toujours de poser le masque sur la moitié du visage de la praticienne ou de son assistante. L’effet tenseur et hydratant immédiat en comparaison de la moitié non traitée emporte l’adhésion dans 95% des rendez-vous.',
          },
        },
        {
          id: 'b1111111-0016-4444-8888-000000000016',
          module_id: MODULE_IDS.J1_M4,
          sort_order: 4,
          status: 'published',
          type: 'callout',
          content: {
            variant: 'note',
            title: 'Retrait du Masque',
            message:
              'Le masque se retire de bas en haut d’un seul geste souple. Nettoyer les contours avec une compresse tiède humide. Ne pas rincer à grande eau pour préserver le film d’électrolytes.',
          },
        },
      ],
    },
  ],
  [TRAINING_DAY_IDS.J2]: [
    {
      id: MODULE_IDS.J2_M1,
        training_day_id: TRAINING_DAY_IDS.J2,
        title: 'Argumentaire Commercial B2B & Packs d’Implantation',
        summary: 'Structure des 3 packs de démarrage (Starter, Salon & Spa Privilège) et retour sur investissement.',
        sort_order: 1,
        status: 'published',
        estimated_read_minutes: 20,
        is_completed: false,
        viewed_at: null,
        blocks_count: 2,
        content_blocks: [
          {
            id: 'b2222222-0001-4444-8888-000000000001',
            module_id: MODULE_IDS.J2_M1,
            sort_order: 1,
            status: 'published',
            type: 'text',
            content: {
              html: `
                <h2>La Stratégie d'Implantation Esthemax</h2>
                <p>Notre gamme est conçue pour s'intégrer facilement dans n'importe quel protocole de soin existant (peelings, soins manuels, microneedling, luminothérapie LED).</p>
                <p>Nous proposons 3 offres calibrées pour chaque profil d'établissement :</p>
                <ul>
                  <li><strong>Pack Starter Découverte :</strong> 4 pots de 500g + accessoires de préparation + présentoir comptoir. Investissement : 249 € HT.</li>
                  <li><strong>Pack Salon Pro :</strong> 10 pots best-sellers + 1 poudre Curette + formation équipe 2h en visio. Investissement : 590 € HT.</li>
                  <li><strong>Pack Spa Privilège :</strong> Gamme complète (18 pots) + marketing PLV premium + certification officielle Esthemax Academy. Investissement : 1 290 € HT.</li>
                </ul>
              `,
            },
          },
          {
            id: 'b2222222-0002-4444-8888-000000000002',
            module_id: MODULE_IDS.J2_M1,
            sort_order: 2,
            status: 'published',
            type: 'callout',
            content: {
              variant: 'success',
              title: 'Amortissement Éclair',
              message:
                'Le Pack Starter est amorti en seulement 10 soins vendus à 25 €. Les 90 soins restants représentent un bénéfice net pur pour l’institut.',
            },
          },
        ],
      },
      {
        id: MODULE_IDS.J2_M2,
        training_day_id: TRAINING_DAY_IDS.J2,
        title: 'Traitement des Objections Fréquentes',
        summary: '« J’ai déjà une marque de masques », « Le temps de pose est trop long », « C’est trop salissant ».',
        sort_order: 2,
        status: 'published',
        estimated_read_minutes: 25,
        is_completed: false,
        viewed_at: null,
        blocks_count: 2,
        content_blocks: [
          {
            id: 'b2222222-0003-4444-8888-000000000003',
            module_id: MODULE_IDS.J2_M2,
            sort_order: 1,
            status: 'published',
            type: 'text',
            content: {
              html: `
                <h2>Désamorcer les Résistances</h2>
                <h3>Objection 1 : « J'ai déjà une marque partenaire exclusive »</h3>
                <p><strong>Réponse :</strong> « Esthemax n'impose aucune exclusivité. L'Hydrojelly s'associe en complément parfait de votre marque principale pour booster vos ventes additionnelles sans changer vos habitudes. »</p>
                <h3>Objection 2 : « Les masques alginates collent et salissent la cabine »</h3>
                <p><strong>Réponse :</strong> « Grâce à notre formulation brevetée riche en électrolytes, le masque se décolle en une seule pièce élastique, sans miettes ni résidus dans les cheveux de la cliente. »</p>
              `,
            },
          },
          {
            id: 'b2222222-0004-4444-8888-000000000004',
            module_id: MODULE_IDS.J2_M2,
            sort_order: 2,
            status: 'published',
            type: 'callout',
            content: {
              variant: 'tip',
              title: 'L’Arme Absolue : L’Échantillon Démo',
              message:
                'Laissez systématiquement un sachet de 24K Gold lors du premier rendez-vous pour qu’elles testent personnellement le soir même.',
            },
          },
        ],
      },
    {
      id: MODULE_IDS.J2_M3,
      training_day_id: TRAINING_DAY_IDS.J2,
      title: 'Closing & Suivi de Réapprovisionnement',
      summary: 'Fréquence des commandes, fidélisation et calendrier promotionnel saisonnier.',
      sort_order: 3,
      status: 'published',
      estimated_read_minutes: 15,
      is_completed: false,
      viewed_at: null,
      blocks_count: 1,
      content_blocks: [
        {
          id: 'b2222222-0005-4444-8888-000000000005',
          module_id: MODULE_IDS.J2_M3,
          sort_order: 1,
          status: 'published',
          type: 'text',
          content: {
            html: `
              <h2>Pérenniser la Relation Commerciale</h2>
              <p>Un institut actif réapprovisionne en moyenne tous les 45 jours. Votre rôle de délégué commercial est d'anticiper leurs ruptures de stock sur les références phares.</p>
            `,
          },
        },
      ],
    },
  ],
  [TRAINING_DAY_IDS.J3]: [
    {
      id: MODULE_IDS.J3_M1,
      training_day_id: TRAINING_DAY_IDS.J3,
      title: 'Cartographie des Prospects & Prospection Digitale',
      summary: 'Identifier les instituts à fort potentiel, utilisation de Google Maps et Instagram.',
      sort_order: 1,
      status: 'published',
      estimated_read_minutes: 25,
      is_completed: false,
      viewed_at: null,
      blocks_count: 1,
      content_blocks: [],
    },
    {
      id: MODULE_IDS.J3_M2,
      training_day_id: TRAINING_DAY_IDS.J3,
      title: 'Approche Spas Hôteliers et Centres Médico-Esthétiques',
      summary: 'Les spécificités des grands comptes et cliniques médicales.',
      sort_order: 2,
      status: 'published',
      estimated_read_minutes: 20,
      is_completed: false,
      viewed_at: null,
      blocks_count: 1,
      content_blocks: [],
    },
  ],
};

export const MOCK_ASSESSMENTS: Record<string, Assessment> = {
  [TRAINING_DAY_IDS.J1]: {
    id: '99999999-1111-4444-8888-aaaaaaaaaaaa',
    training_day_id: TRAINING_DAY_IDS.J1,
    title: 'Évaluation J1 : Maîtrise Marque & Produits Esthemax',
    description:
      'Ce questionnaire valide vos connaissances sur la science des masques Hydrojelly, les ratios de préparation et les bénéfices des ingrédients clés. Score minimum de validation : 70%.',
    passing_score_percentage: 70,
    time_limit_minutes: 20,
    questions_count: 5,
    status: 'published',
    questions: [
      {
        id: 'q1111111-0001-4444-8888-000000000001',
        assessment_id: '99999999-1111-4444-8888-aaaaaaaaaaaa',
        question_text: 'Quel est le rôle principal de la technologie des électrolytes dans les masques Hydrojelly® ?',
        question_type: 'single_choice',
        sort_order: 1,
        is_required: true,
        explanation:
          'Les électrolytes permettent de rétablir l’équilibre osmotique cutané et facilitent le passage actif des nutriments et de l’eau dans les cellules de la peau.',
        options: [
          {
            id: 'opt-001',
            text: 'Rétablir l’équilibre osmotique et favoriser l’absorption cellulaire profonde par étanchéité',
            sort_order: 1,
          },
          {
            id: 'opt-002',
            text: 'Donner une coloration fluorescente sous lumière UV pour les réseaux sociaux',
            sort_order: 2,
          },
          {
            id: 'opt-003',
            text: 'Remplacer l’étape du nettoyage de peau en dissolvant le sébum',
            sort_order: 3,
          },
          {
            id: 'opt-004',
            text: 'Neutraliser les peelings acides sans utiliser d’eau',
            sort_order: 4,
          },
        ],
      },
      {
        id: 'q1111111-0002-4444-8888-000000000002',
        assessment_id: '99999999-1111-4444-8888-aaaaaaaaaaaa',
        question_text: 'Quelles sont les caractéristiques clés du masque Hydrojelly® 24K Gold & Truffle ? (Plusieurs réponses)',
        question_type: 'multiple_choice',
        sort_order: 2,
        is_required: true,
        explanation: 'Il contient de l’or pur 24K et de la truffe blanche d’Alba, et a une action raffermissante et coup d’éclat.',
        options: [
          {
            id: 'opt-005',
            text: 'Action anti-âge tenseur immédiate et illumination du teint',
            sort_order: 1,
          },
          {
            id: 'opt-006',
            text: 'Contient de l’or pur 24 carats et de la truffe blanche',
            sort_order: 2,
          },
          {
            id: 'opt-007',
            text: 'Destiné exclusivement aux peaux grasses comédogènes',
            sort_order: 3,
          },
          {
            id: 'opt-008',
            text: 'Peut s’appliquer sur les paupières fermées et les lèvres',
            sort_order: 4,
          },
        ],
      },
      {
        id: 'q1111111-0003-4444-8888-000000000003',
        assessment_id: '99999999-1111-4444-8888-aaaaaaaaaaaa',
        question_text: 'Quel est le ratio idéal de préparation pour un masque visage complet ?',
        question_type: 'single_choice',
        sort_order: 3,
        is_required: true,
        options: [
          {
            id: 'opt-009',
            text: '1,5 doseur de poudre pour 1 doseur d’eau fraîche purifiée',
            sort_order: 1,
          },
          {
            id: 'opt-010',
            text: '3 doseurs de poudre pour 1 doseur d’eau bouillante',
            sort_order: 2,
          },
          {
            id: 'opt-011',
            text: '1 doseur de poudre pour 2 doseurs d’huile végétale',
            sort_order: 3,
          },
        ],
      },
      {
        id: 'q1111111-0004-4444-8888-000000000004',
        assessment_id: '99999999-1111-4444-8888-aaaaaaaaaaaa',
        question_text: 'Combien d’applications complètes en cabine permet un pot professionnel de 500g d’Hydrojelly ?',
        question_type: 'single_choice',
        sort_order: 4,
        is_required: true,
        options: [
          {
            id: 'opt-012',
            text: 'Environ 25 applications',
            sort_order: 1,
          },
          {
            id: 'opt-013',
            text: 'Environ 5 applications seulement',
            sort_order: 2,
          },
          {
            id: 'opt-014',
            text: 'Plus de 80 applications',
            sort_order: 3,
          },
        ],
      },
      {
        id: 'q1111111-0005-4444-8888-000000000005',
        assessment_id: '99999999-1111-4444-8888-aaaaaaaaaaaa',
        question_text: 'Comment décririez-vous en une phrase le bénéfice financier pour une esthéticienne qui implante Esthemax ?',
        question_type: 'free_text',
        sort_order: 5,
        is_required: false,
      },
    ],
  },
};

export const MOCK_PROGRESS: CommercialProgress = {
  user_id: DEMO_USERS.active_commercial.id,
  overall_progress_percentage: 65,
  total_training_days: 3,
  completed_training_days: 0,
  total_modules: 9,
  completed_modules: 3,
  total_assessments: 3,
  passed_assessments: 0,
  average_score_percentage: 85,
  last_activity_at: '2026-09-12T15:10:00Z',
  current_training_day: INITIAL_TRAINING_DAYS[0],
  last_viewed_module: {
    id: MODULE_IDS.J1_M3,
    title: 'Ampoules, Sérums & Poudres Exfoliantes',
    training_day_id: TRAINING_DAY_IDS.J1,
    training_day_title: 'J1 – Marque et Produits',
    viewed_at: '2026-09-12T15:10:00Z',
  },
  days_progress: [
    {
      training_day_id: TRAINING_DAY_IDS.J1,
      code: 'J1',
      title: 'Marque et Produits',
      status: 'in_progress',
      progress_percentage: 75,
      completed_modules: 3,
      total_modules: 4,
      assessment_passed: false,
      assessment_score: null,
      completed_at: null,
    },
    {
      training_day_id: TRAINING_DAY_IDS.J2,
      code: 'J2',
      title: 'Force de Vente',
      status: 'available',
      progress_percentage: 0,
      completed_modules: 0,
      total_modules: 3,
      assessment_passed: false,
      assessment_score: null,
      completed_at: null,
    },
    {
      training_day_id: TRAINING_DAY_IDS.J3,
      code: 'J3',
      title: 'Clients Potentiels',
      status: 'locked',
      progress_percentage: 0,
      completed_modules: 0,
      total_modules: 2,
      assessment_passed: false,
      assessment_score: null,
      completed_at: null,
    },
  ],
  recent_activities: [
    {
      id: 'act-001',
      type: 'module_viewed',
      title: 'Module consulté : Ampoules, Sérums & Poudres Exfoliantes',
      timestamp: '2026-09-12T15:10:00Z',
      training_day_code: 'J1',
    },
    {
      id: 'act-002',
      type: 'module_viewed',
      title: 'Module consulté : La Révolution des Masques Hydrojelly®',
      timestamp: '2026-09-12T11:40:00Z',
      training_day_code: 'J1',
    },
    {
      id: 'act-003',
      type: 'module_viewed',
      title: 'Module consulté : Introduction à la Marque Esthemax',
      timestamp: '2026-09-12T10:15:00Z',
      training_day_code: 'J1',
    },
    {
      id: 'act-004',
      type: 'training_day_started',
      title: 'Formation démarrée : J1 – Marque et Produits',
      timestamp: '2026-09-12T10:00:00Z',
      training_day_code: 'J1',
    },
  ],
};
