import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { ShieldAlert, LogOut, Mail } from 'lucide-react';

export const BlockedAccountPage: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-[#FFF9F7] flex items-center justify-center p-4 antialiased">
      <div className="w-full max-w-md bg-white border border-[#F0E5E9] rounded-3xl p-8 text-center shadow-xl">
        <div className="w-16 h-16 rounded-2xl bg-rose-50 text-[#C2415D] flex items-center justify-center mx-auto mb-4 border border-rose-100">
          <ShieldAlert className="w-8 h-8" />
        </div>

        <h1 className="text-xl font-bold text-[#241B22] mb-2">
          Accès Commercial Suspendu
        </h1>

        <p className="text-sm text-[#766A72] leading-relaxed mb-6">
          Votre compte utilisateur (<strong>{user?.email}</strong>) est actuellement{' '}
          {user?.status === 'blocked' ? 'bloqué' : 'inactif'}.
          <br />
          Par mesure de sécurité, vous ne pouvez pas accéder aux supports de formation ni aux modules de vente Esthemax.
        </p>

        <div className="bg-[#FFF9F7] border border-[#F0E5E9] rounded-2xl p-4 mb-6 text-left text-xs text-[#766A72] space-y-2">
          <div className="font-bold text-[#241B22] flex items-center gap-1.5">
            <Mail className="w-4 h-4 text-[#D41472]" />
            <span>Que faire ?</span>
          </div>
          <p>
            Veuillez vous rapprocher de la Direction Commerciale Esthemax ou contacter votre tuteur de formation pour réactiver vos accès.
          </p>
        </div>

        <button
          type="button"
          onClick={handleLogout}
          className="w-full py-3.5 px-4 rounded-xl bg-[#D41472] hover:bg-[#A90F59] text-white text-xs font-bold flex items-center justify-center gap-2 transition-colors min-h-[44px] shadow-sm"
        >
          <LogOut className="w-4 h-4" />
          <span>Se déconnecter</span>
        </button>
      </div>
    </div>
  );
};

export default BlockedAccountPage;
