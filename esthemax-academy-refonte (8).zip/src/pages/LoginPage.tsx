import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  Eye,
  EyeOff,
  Lock,
  UserRound,
  AlertCircle,
  BookOpen,
  Award,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

export const LoginPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, isAuthenticated, isCommercial, isAdmin, sessionExpiredNotice, clearSessionExpiredNotice } = useAuth();

  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<{ loginId?: string; password?: string }>({});

  const redirectUrl = (location.state as any)?.from?.pathname || (isAdmin ? '/admin' : '/commercial');

  // If already authenticated, redirect
  useEffect(() => {
    if (isAuthenticated) {
      if (isCommercial || isAdmin) {
        navigate(redirectUrl, { replace: true });
      }
    }
  }, [isAuthenticated, isCommercial, isAdmin, navigate, redirectUrl]);

  const validateForm = () => {
    const errors: { loginId?: string; password?: string } = {};
    if (!loginId.trim()) {
      errors.loginId = 'Veuillez saisir votre identifiant commercial.';
    }

    if (!password) {
      errors.password = 'Veuillez saisir votre mot de passe.';
    } else if (password.length < 4) {
      errors.password = 'Le mot de passe doit comporter au moins 4 caractères.';
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    clearSessionExpiredNotice();

    if (!validateForm()) return;

    setIsSubmitting(true);
    try {
      const loggedUser = await login(loginId.trim(), password, remember);

      if (loggedUser.status === 'blocked' || loggedUser.status === 'inactive') {
        navigate('/blocked', { replace: true });
        return;
      }

      navigate(loggedUser.role === 'admin' ? '/admin' : '/commercial', { replace: true });
    } catch (err: any) {
      if (err.accountStatus === 'blocked') {
        setErrorMessage('Votre compte est bloqué. Veuillez contacter votre responsable de formation Esthemax.');
      } else if (err.accountStatus === 'inactive') {
        setErrorMessage('Votre compte commercial est actuellement inactif.');
      } else if (err.status === 401 || err.message === 'Invalid email or password') {
        setErrorMessage('Identifiants incorrects. Veuillez vérifier votre identifiant et votre mot de passe.');
      } else if (err.status === 0) {
        setErrorMessage('Impossible de contacter le serveur. Veuillez vérifier votre connexion Internet.');
      } else {
        setErrorMessage(err.message || 'Une erreur est survenue lors de la connexion.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF7F5] flex flex-col justify-between antialiased selection:bg-[#D41472] selection:text-white relative overflow-hidden">
      {/* Glowing Ambient Background Halos */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden" aria-hidden="true">
        <div className="absolute top-[-10%] left-[-10%] w-[50vw] h-[50vw] min-w-[350px] min-h-[350px] rounded-full bg-[#FCE7F3]/70 blur-[130px] animate-orb-1" />
        <div className="absolute bottom-[-10%] right-[-5%] w-[45vw] h-[45vw] min-w-[320px] min-h-[320px] rounded-full bg-[#FDF3E7]/80 blur-[120px] animate-orb-2" />
        <div className="absolute top-[40%] left-[20%] w-[35vw] h-[35vw] min-w-[260px] min-h-[260px] rounded-full bg-[#FDF0F5]/90 blur-[110px]" />
      </div>

      {/* Top Banner */}
      <header className="relative z-10 w-full bg-white/70 backdrop-blur-md border-b border-white/80 py-2.5 px-4 text-center">
        <div className="inline-flex items-center gap-2 text-[11px] font-black tracking-wider uppercase text-[#D41472]">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Plateforme Officielle d'Accréditation Commerciale Esthemax</span>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="relative z-10 flex-1 flex flex-col lg:flex-row items-center justify-center p-4 sm:p-6 lg:p-12 gap-8 lg:gap-16 max-w-6xl mx-auto w-full">
        {/* Brand & Introduction Section */}
        <div className="w-full lg:w-1/2 flex flex-col justify-center max-w-lg lg:max-w-none text-[#1E161D]">
          <div className="mb-6 flex items-center gap-3">
            <img
              src="https://www.esthemax-morocco.com/wp-content/uploads/2023/12/esthemaxl-logo.png"
              alt="Esthemax Logo"
              className="h-12 w-auto object-contain"
            />
            <span className="text-xs font-black uppercase tracking-widest px-3 py-1 rounded-full bg-[#FCE7F3] text-[#D41472] border border-[#FCE7F3]">
              Academy
            </span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black mb-4 leading-tight tracking-tight text-[#1E161D]">
            L'excellence commerciale <span className="text-[#D41472]">Esthemax</span>
          </h1>

          <p className="text-xs sm:text-sm mb-8 leading-relaxed text-[#6E626B]">
            Espace certifiant réservé à nos délégués et conseillers beauté. Maîtrisez les protocoles Hydrojelly®, la science des électrolytes et développez vos ventes auprès des instituts partenaires.
          </p>

          <div className="space-y-3.5">
            <div className="flex items-start gap-3.5 p-4 rounded-[22px] glass-card shadow-xs">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 bg-[#FCE7F3] text-[#D41472]">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-xs sm:text-sm text-[#1E161D]">Parcours J1, J2 & J3</h3>
                <p className="text-xs text-[#6E626B] mt-0.5">Modules interactifs, fiches techniques et démonstrations cabine.</p>
              </div>
            </div>

            <div className="flex items-start gap-3.5 p-4 rounded-[22px] glass-card shadow-xs">
              <div className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 bg-[#FDF3E7] text-[#C59B27]">
                <Award className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-extrabold text-xs sm:text-sm text-[#1E161D]">Accréditation Officielle</h3>
                <p className="text-xs text-[#6E626B] mt-0.5">Quiz d'évaluation requis pour l'obtention du certificat de délégué agréé.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Form Card (Glassmorphism) */}
        <div className="w-full lg:w-1/2 flex items-center justify-center max-w-md">
          <div className="w-full glass-card rounded-[32px] p-6 sm:p-8 shadow-2xl border border-white/90 space-y-5">
            {/* Session Expired Alert */}
            {sessionExpiredNotice && (
              <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 text-[#C47A16] text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>Votre session a expiré. Veuillez vous reconnecter.</span>
              </div>
            )}

            {/* Error Alert */}
            {errorMessage && (
              <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-[#C2415D] text-xs flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            <div>
              <h2 className="text-xl sm:text-2xl font-black text-[#1E161D]">Connexion</h2>
              <p className="text-xs text-[#6E626B] mt-0.5">
                Accédez à votre espace d'apprentissage personnalisé.
              </p>
            </div>

            {/* Login Form */}
            <form onSubmit={handleSubmit} noValidate className="space-y-4">
              {/* Email Field */}
              <div>
                <label
                  htmlFor="login-id"
                  className="block text-xs font-black text-[#6E626B] uppercase tracking-wider mb-1"
                >
                  Identifiant commercial
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#6E626B]">
                    <UserRound className="w-4 h-4" />
                  </div>
                  <input
                    id="login-id"
                    type="text"
                    autoComplete="username"
                    value={loginId}
                    onChange={(e) => setLoginId(e.target.value)}
                    placeholder="ex. sihamf"
                    className="w-full pl-10 pr-4 py-3 rounded-2xl glass-card text-xs sm:text-sm text-[#1E161D] placeholder-gray-400 focus:outline-none focus:border-[#D41472] focus:ring-2 focus:ring-[#D41472]/20 transition-all"
                  />
                </div>
                {fieldErrors.loginId && (
                  <p className="text-xs text-[#C2415D] mt-1 font-semibold">{fieldErrors.loginId}</p>
                )}
              </div>

              {/* Password Field */}
              <div>
                <label
                  htmlFor="login-password"
                  className="block text-xs font-black text-[#6E626B] uppercase tracking-wider mb-1"
                >
                  Mot de Passe
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#6E626B]">
                    <Lock className="w-4 h-4" />
                  </div>
                  <input
                    id="login-password"
                    type={showPassword ? 'text' : 'password'}
                    autoComplete="current-password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-11 py-3 rounded-2xl glass-card text-xs sm:text-sm text-[#1E161D] placeholder-gray-400 focus:outline-none focus:border-[#D41472] focus:ring-2 focus:ring-[#D41472]/20 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#6E626B] hover:text-[#1E161D]"
                    aria-label={showPassword ? 'Masquer' : 'Afficher'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {fieldErrors.password && (
                  <p className="text-xs text-[#C2415D] mt-1 font-semibold">{fieldErrors.password}</p>
                )}
              </div>

              {/* Remember me */}
              <div className="flex items-center pt-1">
                <input
                  id="remember-me"
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="w-4 h-4 rounded-md border-[#EFE6EB] cursor-pointer accent-[#D41472]"
                />
                <label
                  htmlFor="remember-me"
                  className="ml-2 text-xs text-[#6E626B] cursor-pointer select-none font-semibold"
                >
                  Rester connecté sur cet appareil
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full mt-3 py-3.5 px-4 rounded-2xl text-white text-xs sm:text-sm font-black tracking-wide shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2 min-h-[48px] bg-[#D41472] hover:bg-[#A90F59] active:scale-95 disabled:opacity-60 cursor-pointer"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Connexion en cours...</span>
                  </>
                ) : (
                  <>
                    <span>Accéder à l'Academy</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 py-4 text-center text-xs font-semibold text-[#6E626B]">
        &copy; {new Date().getFullYear()} Esthemax Academy France & International. Tous droits réservés.
      </footer>
    </div>
  );
};

export default LoginPage;
