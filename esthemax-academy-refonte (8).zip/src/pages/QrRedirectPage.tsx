import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getTrainingDays } from '../api/commercialTrainingApi';
import { QrCode, AlertCircle, ArrowRight } from 'lucide-react';

export const QrRedirectPage: React.FC = () => {
  const { code } = useParams<{ code: string }>();
  const { isAuthenticated, isLoading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [checking, setChecking] = useState(true);
  const [errorNotice, setErrorNotice] = useState<string | null>(null);

  useEffect(() => {
    if (isLoading) return;

    // If unauthenticated, redirect to login with state preserving the QR destination
    if (!isAuthenticated) {
      navigate('/login', { state: { from: location }, replace: true });
      return;
    }

    // Authenticated: find corresponding training day
    async function resolveCode() {
      try {
        const days = await getTrainingDays();
        const targetCode = (code || '').toUpperCase();
        const matched = days.find(
          (d) => d.code.toUpperCase() === targetCode || d.id.toLowerCase() === (code || '').toLowerCase()
        );

        if (!matched) {
          setErrorNotice(`Aucune journée de formation ne correspond au code « ${code} ».`);
          setChecking(false);
          return;
        }

        if (matched.status === 'locked') {
          setErrorNotice(
            matched.lock_reason ||
              `La journée de formation ${matched.code} est actuellement verrouillée. Veuillez compléter les prérequis.`
          );
          setChecking(false);
          return;
        }

        // Navigate using the valid UUID
        navigate(`/commercial/training-days/${matched.id}`, { replace: true });
      } catch (e: any) {
        setErrorNotice(e.message || 'Erreur lors de la validation du code QR/NFC.');
        setChecking(false);
      }
    }

    resolveCode();
  }, [code, isAuthenticated, isLoading, navigate, location]);

  if (checking) {
    return (
      <div className="min-h-screen bg-[#FFF9F7] flex items-center justify-center p-4">
        <div className="bg-white border border-[#F0E5E9] rounded-3xl p-6 sm:p-8 text-center shadow-md max-w-sm w-full space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-[#FCE7F3] text-[#D41472] flex items-center justify-center mx-auto">
            <QrCode className="w-7 h-7 animate-pulse" />
          </div>
          <div className="text-sm font-bold text-[#241B22]">Validation de l'accès QR / NFC...</div>
          <p className="text-xs text-[#766A72]">Vérification de vos permissions commerciales</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFF9F7] flex items-center justify-center p-4">
      <div className="bg-white border border-[#F0E5E9] rounded-3xl p-6 sm:p-8 text-center shadow-lg max-w-md w-full space-y-4">
        <div className="w-14 h-14 rounded-2xl bg-amber-50 text-[#C47A16] flex items-center justify-center mx-auto">
          <AlertCircle className="w-7 h-7" />
        </div>
        <h2 className="text-lg font-bold text-[#241B22]">Accès via QR Code</h2>
        <p className="text-xs sm:text-sm text-[#766A72] leading-relaxed">{errorNotice}</p>
        <div className="pt-2">
          <Link
            to="/commercial"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#D41472] text-white text-xs font-bold hover:bg-[#A90F59] transition-colors shadow-sm"
          >
            <span>Aller au tableau de bord</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default QrRedirectPage;
