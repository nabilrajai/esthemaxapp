import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { getTrainingDays } from '../../api/commercialTrainingApi';
import { getProgress } from '../../api/commercialProgressApi';
import {
  BookOpen,
  Clock,
  ArrowRight,
  CheckCircle2,
  Lock,
  Play,
  FileQuestion,
  Sparkles,
  TrendingUp,
  FileText,
  Eye,
  X,
  Award,
  Zap,
  Flame,
  ChevronRight,
  ShieldCheck,
} from 'lucide-react';
import CommercialLoadingState from '../../components/commercial/CommercialLoadingState';
import CommercialErrorState from '../../components/commercial/CommercialErrorState';

export const CommercialDashboardPage: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // State for PDF viewer modal
  const [selectedPdf, setSelectedPdf] = useState<{ title: string; url: string } | null>(null);

  // PDF Documentation Data
  const documents = [
    { id: 1, title: 'Catalogue Produits & Protocoles 2026', size: '2.4 MB', url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
    { id: 2, title: 'Guide d’Argumentaire Commercial Esthemax', size: '1.1 MB', url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
    { id: 3, title: 'Protocoles Hydrojelly® Essentiels Cabine', size: '3.5 MB', url: 'https://www.w3.org/WAI/ER/tests/xhtml/testfiles/resources/pdf/dummy.pdf' },
  ];

  const {
    data: trainingDays,
    isLoading: isDaysLoading,
    error: daysError,
    refetch: refetchDays,
  } = useQuery({
    queryKey: ['commercial', 'training-days'],
    queryFn: getTrainingDays,
  });

  const {
    data: progress,
    isLoading: isProgressLoading,
    error: progressError,
    refetch: refetchProgress,
  } = useQuery({
    queryKey: ['commercial', 'progress'],
    queryFn: getProgress,
  });

  if (isDaysLoading || isProgressLoading) {
    return <CommercialLoadingState type="dashboard" />;
  }

  if (daysError || progressError) {
    return (
      <CommercialErrorState
        title="Impossible de charger le tableau de bord"
        message="Une erreur est survenue lors de la récupération de vos formations. Veuillez réessayer."
        onRetry={() => {
          refetchDays();
          refetchProgress();
        }}
      />
    );
  }

  const days = trainingDays || [];

  // Calculate dynamic states
  const completedDays = days.filter((d) => d.status === 'completed');
  const inProgressDay = days.find((d) => d.status === 'in_progress');
  const availableDay = days.find((d) => d.status === 'available');
  const activeDay = inProgressDay || availableDay || days[0];

  const overallProgress = progress?.overall_progress_percentage || 0;
  const isCompletedAll = completedDays.length === days.length && days.length > 0;

  // Pending assessment
  const pendingAssessmentDay = days.find(
    (d) => d.assessment_status === 'pending' || (d.progress_percentage === 100 && d.assessment_status !== 'passed')
  );

  const completedModules = progress?.completed_modules || 0;
  const totalModules = progress?.total_modules || 12;
  const averageScore = progress?.average_score_percentage || 90;
  const learningTimeMinutes = progress?.completed_modules ? progress.completed_modules * 18 : 135;

  // SVG Circular progress math (calibrated to viewBox 0 0 100 100)
  const circleRadius = 38;
  const circumference = 2 * Math.PI * circleRadius;
  const strokeDashoffset = circumference - (overallProgress / 100) * circumference;

  const firstName = user?.name ? user.name.split(' ')[0] : 'Commercial';

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300" id="commercial-dashboard-view">
      {/* 2030 Mobile-App Personalized Header */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 sm:gap-4">
          <div
            className="w-12 h-12 sm:w-14 sm:h-14 rounded-[20px] text-white font-black text-lg sm:text-xl flex items-center justify-center shadow-lg ring-2 ring-white"
            style={{ backgroundColor: '#D41472' }}
          >
            {user?.name?.charAt(0) || 'C'}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs font-bold text-[#6E626B]">Bienvenue sur l’Academy</span>
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            </div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-black text-[#1E161D] tracking-tight">
              Bonjour, {firstName}
            </h1>
          </div>
        </div>

        <div className="hidden sm:flex items-center gap-2">
          <div className="glass-card px-3.5 py-1.5 rounded-full text-xs font-bold text-[#D41472] flex items-center gap-1.5">
            <Flame className="w-4 h-4 fill-[#D41472]" />
            <span>Série de 3 jours</span>
          </div>
        </div>
      </div>

      {/* Redesigned 2030 Luxury Hero Card with Perfectly Centered Compact Percentage Gauge */}
      <div className="relative overflow-hidden rounded-[32px] bg-gradient-to-br from-[#D41472] via-[#B81161] to-[#780A40] text-white p-6 sm:p-8 lg:p-10 shadow-2xl shadow-[#D41472]/20 border border-white/20">
        {/* Soft Ambient Light Halos */}
        <div className="absolute top-0 right-0 w-96 h-96 opacity-25 rounded-full bg-white blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-72 h-72 opacity-20 rounded-full bg-[#FDF3E7] blur-3xl pointer-events-none" />
        <div className="absolute inset-0 bg-radial from-white/10 to-transparent pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6 lg:gap-10">
          <div className="space-y-3.5 max-w-xl">
            {/* Elegant Tag */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/15 backdrop-blur-md text-white text-[11px] sm:text-xs font-black tracking-wider uppercase border border-white/25 shadow-2xs">
              <Sparkles className="w-3.5 h-3.5 text-[#FDF3E7]" />
              <span>Espace Commercial Esthemax</span>
            </div>

            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight leading-tight text-white drop-shadow-xs">
              {isCompletedAll
                ? 'Expertise Commerciale Certifiée'
                : activeDay
                ? `${activeDay.code} : ${activeDay.title}`
                : 'Parcours de Formation'}
            </h2>

            <p className="text-xs sm:text-sm text-white/90 leading-relaxed font-medium">
              {isCompletedAll
                ? 'Félicitations ! Vous maîtrisez l’ensemble des protocoles, produits et argumentaires de vente Esthemax.'
                : activeDay
                ? `Poursuivez les modules de la journée ${activeDay.code} et validez vos compétences pour obtenir votre certification.`
                : 'Accédez à vos modules, protocoles et quiz certifiants.'}
            </p>

            {/* Quick Action Button & Micro-Indicators */}
            <div className="pt-2 flex flex-wrap items-center gap-3">
              {activeDay && activeDay.status !== 'locked' && (
                <button
                  type="button"
                  onClick={() => navigate(`/commercial/training-days/${activeDay.id}`)}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl bg-white text-[#1E161D] hover:bg-[#FAF7F5] text-xs sm:text-sm font-black shadow-lg hover:shadow-2xl transition-all duration-200 min-h-[48px] active:scale-95"
                >
                  <Play className="w-4 h-4 fill-[#D41472] text-[#D41472]" />
                  <span>
                    {activeDay.status === 'in_progress' ? 'Reprendre la formation' : 'Continuer la formation'}
                  </span>
                  <ArrowRight className="w-4 h-4 ml-0.5 text-[#D41472]" />
                </button>
              )}

              <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-black/15 backdrop-blur-md text-[11px] font-bold text-white/90 border border-white/10">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                <span>
                  {trainingDays.filter((d) => d.status === 'completed').length} / {trainingDays.length} Journées Validées
                </span>
              </div>
            </div>
          </div>

          {/* Redesigned Minimalist Progress Dial with Small, Centered Percentage */}
          <div className="shrink-0 flex items-center justify-center self-center md:self-auto">
            <div className="relative w-28 h-28 sm:w-32 sm:h-32 rounded-full p-2 bg-white/10 backdrop-blur-xl border border-white/20 shadow-inner flex items-center justify-center">
              {/* Scaled SVG circular ring with responsive viewBox */}
              <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
                {/* Background Ring */}
                <circle
                  cx="50"
                  cy="50"
                  r={circleRadius}
                  stroke="rgba(255, 255, 255, 0.2)"
                  strokeWidth="6"
                  fill="none"
                />
                {/* Active Progress Arc */}
                <circle
                  cx="50"
                  cy="50"
                  r={circleRadius}
                  stroke="#FFFFFF"
                  strokeWidth="6"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className="transition-all duration-1000 ease-out"
                  fill="none"
                />
              </svg>

              {/* Dead-Center Small Percentage Text & Status */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none select-none">
                <span className="text-base sm:text-lg font-black text-white tracking-tight leading-none">
                  {overallProgress}%
                </span>
                <span className="text-[9px] sm:text-[10px] font-extrabold text-white/75 uppercase tracking-wider leading-none mt-1">
                  Global
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Compact Glassmorphism KPI Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-5">
        {/* Total Progress */}
        <div className="glass-card-interactive rounded-[24px] p-4 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6E626B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Progression</span>
            <div className="w-8 h-8 rounded-xl bg-[#FCE7F3] flex items-center justify-center text-[#D41472]">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-[#1E161D]">
              {overallProgress}%
            </div>
            <div className="text-[11px] text-[#6E626B] mt-1 font-semibold">Parcours global</div>
          </div>
        </div>

        {/* Modules Completed */}
        <div className="glass-card-interactive rounded-[24px] p-4 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6E626B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Modules</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 flex items-center justify-center text-[#16866A]">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-[#1E161D]">
              {completedModules} <span className="text-xs font-semibold text-[#6E626B]">/ {totalModules}</span>
            </div>
            <div className="text-[11px] text-[#6E626B] mt-1 font-semibold">Supports validés</div>
          </div>
        </div>

        {/* Average Score */}
        <div className="glass-card-interactive rounded-[24px] p-4 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6E626B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Score Moyen</span>
            <div className="w-8 h-8 rounded-xl bg-[#FDF3E7] flex items-center justify-center text-[#C59B27]">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-[#1E161D]">
              {averageScore}%
            </div>
            <div className="text-[11px] text-[#6E626B] mt-1 font-semibold">Aux évaluations</div>
          </div>
        </div>

        {/* Learning Time */}
        <div className="glass-card-interactive rounded-[24px] p-4 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6E626B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Temps Passé</span>
            <div className="w-8 h-8 rounded-xl bg-[#FDF0F5] flex items-center justify-center text-[#D41472]">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black text-[#1E161D]">
              {learningTimeMinutes} <span className="text-xs font-semibold text-[#6E626B]">min</span>
            </div>
            <div className="text-[11px] text-[#6E626B] mt-1 font-semibold">Formation active</div>
          </div>
        </div>
      </div>

      {/* Pending Questionnaire Alert if any */}
      {pendingAssessmentDay && (
        <div className="glass-card rounded-[24px] p-4 sm:p-5 border-[#C47A16]/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-sm bg-gradient-to-r from-[#FDF3E7]/60 to-white">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-[#C47A16]/15 text-[#C47A16] flex items-center justify-center shrink-0">
              <FileQuestion className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-extrabold text-[#1E161D]">
                Quiz en attente : {pendingAssessmentDay.code} – {pendingAssessmentDay.title}
              </h4>
              <p className="text-xs text-[#6E626B] mt-0.5">
                Validez vos connaissances pour certifier cette journée et débloquer la suite du cursus.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => navigate(`/commercial/training-days/${pendingAssessmentDay.id}/assessment`)}
            className="px-5 py-2.5 rounded-xl bg-[#D41472] hover:bg-[#A90F59] text-white text-xs font-bold shrink-0 min-h-[44px] transition-all shadow-md active:scale-95"
          >
            Passer le quiz &rarr;
          </button>
        </div>
      )}

      {/* "Continuer la formation" Quick Resume Card */}
      {progress?.last_viewed_module && (
        <div className="glass-card-interactive rounded-[28px] p-5 sm:p-6 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#D41472] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Reprendre là où vous vous étiez arrêté</span>
            </span>
            <span className="text-[10px] font-semibold text-[#6E626B]">Dernière consultation</span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-1">
            <div className="space-y-1">
              <div className="text-xs font-bold text-[#6E626B]">
                {progress.last_viewed_module.training_day_title || 'Formation Commerciale Esthemax'}
              </div>
              <h3 className="text-lg font-black text-[#1E161D]">
                {progress.last_viewed_module.title}
              </h3>
            </div>

            <button
              type="button"
              onClick={() =>
                navigate(
                  `/commercial/training-days/${progress.last_viewed_module?.training_day_id}/modules/${progress.last_viewed_module?.id}`
                )
              }
              className="inline-flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-[#D41472] hover:bg-[#A90F59] text-white text-xs font-extrabold shadow-md hover:shadow-lg transition-all min-h-[46px] active:scale-95"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Reprendre ce module</span>
            </button>
          </div>
        </div>
      )}

      {/* Prochaines Formations (Training Days J1, J2, J3) */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-[#1E161D]">Prochaines formations</h2>
            <p className="text-xs text-[#6E626B]">Votre parcours certifiant Esthemax Academy</p>
          </div>
          <Link
            to="/commercial/training-days"
            className="text-xs font-extrabold text-[#D41472] hover:text-[#A90F59] flex items-center gap-1"
          >
            <span>Voir tout</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-5">
          {days.map((day) => {
            const isLocked = day.status === 'locked' || day.status === 'waiting';
            const isCompleted = day.status === 'completed';
            const isInProgress = day.status === 'in_progress';
            const isAvailable = day.status === 'available';

            return (
              <div
                key={day.id}
                className={`glass-card rounded-[26px] p-5 sm:p-6 flex flex-col justify-between transition-all duration-300 ${
                  isLocked
                    ? 'opacity-65 bg-white/50 border-white/60'
                    : 'glass-card-interactive'
                }`}
              >
                <div>
                  {/* Top Day Badge & Status */}
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="px-3 py-1 rounded-full bg-[#D41472] text-white text-xs font-black tracking-wider shadow-xs">
                      {day.code}
                    </span>
                    <span
                      className={`text-[11px] font-extrabold px-3 py-0.5 rounded-full ${
                        isCompleted
                          ? 'bg-emerald-50 text-[#16866A] border border-emerald-200'
                          : isInProgress
                          ? 'bg-[#FCE7F3] text-[#D41472] border border-[#FCE7F3]'
                          : isLocked
                          ? 'bg-gray-100 text-[#6E626B]'
                          : 'bg-[#FDF0F5] text-[#D41472] border border-[#FCE7F3]'
                      }`}
                    >
                      {isCompleted && 'Terminé'}
                      {isInProgress && 'En cours'}
                      {isAvailable && 'Disponible'}
                      {isLocked && 'Verrouillé'}
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-black text-[#1E161D] line-clamp-1">{day.title}</h3>
                  <p className="text-xs font-bold text-[#D41472] mt-0.5 line-clamp-1">{day.theme}</p>
                  <p className="text-xs text-[#6E626B] mt-2 line-clamp-2 leading-relaxed">
                    {day.description || 'Développez vos compétences sur les protocoles et produits de cette journée.'}
                  </p>
                </div>

                {/* Bottom Progress & Action */}
                <div className="mt-5 pt-4 border-t border-[#EFE6EB] space-y-3">
                  <div className="flex items-center justify-between text-[11px] font-semibold text-[#6E626B]">
                    <span>{day.modules_count || 4} modules</span>
                    <span>{day.progress_percentage || 0}% complété</span>
                  </div>

                  <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#D41472] rounded-full transition-all duration-500"
                      style={{ width: `${day.progress_percentage || 0}%` }}
                    />
                  </div>

                  <button
                    type="button"
                    disabled={isLocked}
                    onClick={() => navigate(`/commercial/training-days/${day.id}`)}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-extrabold flex items-center justify-center gap-2 min-h-[42px] transition-all ${
                      isLocked
                        ? 'bg-gray-100 text-[#6E626B] cursor-not-allowed'
                        : isCompleted
                        ? 'bg-white border border-[#EFE6EB] text-[#1E161D] hover:bg-[#FAF7F5]'
                        : 'bg-[#D41472] hover:bg-[#A90F59] text-white shadow-xs hover:shadow-md'
                    }`}
                  >
                    {isLocked ? (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        <span>Verrouillé</span>
                      </>
                    ) : isCompleted ? (
                      <>
                        <span>Revoir les modules</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </>
                    ) : (
                      <>
                        <span>Accéder à la journée</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* "Votre activité récente" Section */}
      <div className="space-y-4">
        <h2 className="text-lg sm:text-xl font-black text-[#1E161D]">Votre activité récente</h2>

        <div className="glass-card rounded-[28px] p-5 sm:p-6 divide-y divide-[#EFE6EB]">
          {progress?.recent_activities && progress.recent_activities.length > 0 ? (
            progress.recent_activities.map((act) => (
              <div key={act.id} className="py-3.5 first:pt-0 last:pb-0 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#FCE7F3] text-[#D41472] flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-extrabold text-[#1E161D]">{act.title}</h4>
                    <span className="text-[11px] text-[#6E626B]">Journée {act.training_day_code}</span>
                  </div>
                </div>
                <span className="text-[11px] text-[#6E626B] shrink-0 font-medium">
                  {new Date(act.timestamp).toLocaleDateString('fr-FR', {
                    day: 'numeric',
                    month: 'short',
                  })}
                </span>
              </div>
            ))
          ) : (
            <div className="py-4 text-center text-xs text-[#6E626B]">
              Aucune activité récente enregistrée.
            </div>
          )}
        </div>
      </div>

      {/* Documentation & Resources Section */}
      <div className="space-y-4">
        <h2 className="text-lg sm:text-xl font-black text-[#1E161D]">Documentation Commerciale</h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
          {documents.map((doc) => (
            <div
              key={doc.id}
              onClick={() => setSelectedPdf(doc)}
              className="glass-card-interactive rounded-[22px] p-4 cursor-pointer flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-9 h-9 rounded-xl bg-[#FDF0F5] text-[#D41472] flex items-center justify-center shrink-0">
                  <FileText className="w-4 h-4" />
                </div>
                <div className="min-w-0">
                  <h4 className="text-xs font-bold text-[#1E161D] truncate">{doc.title}</h4>
                  <span className="text-[10px] text-[#6E626B]">{doc.size} • PDF</span>
                </div>
              </div>
              <Eye className="w-4 h-4 text-[#D41472] shrink-0" />
            </div>
          ))}
        </div>
      </div>

      {/* PDF Viewer Modal */}
      {selectedPdf && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-3xl glass-card rounded-[32px] p-6 shadow-2xl border border-white/90 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-[#EFE6EB]">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#D41472]" />
                <h3 className="font-extrabold text-sm sm:text-base text-[#1E161D]">{selectedPdf.title}</h3>
              </div>
              <button
                type="button"
                onClick={() => setSelectedPdf(null)}
                className="p-1.5 rounded-full hover:bg-black/5 text-[#6E626B]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-6 text-center space-y-4">
              <div className="w-16 h-16 rounded-2xl bg-[#FDF0F5] text-[#D41472] flex items-center justify-center mx-auto">
                <FileText className="w-8 h-8" />
              </div>
              <p className="text-xs sm:text-sm text-[#6E626B] max-w-md mx-auto">
                Vous consultez le document de référence officiel Esthemax. Vous pouvez l'ouvrir en plein écran ou le télécharger.
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <a
                  href={selectedPdf.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 rounded-xl bg-[#D41472] text-white text-xs font-bold shadow-md hover:bg-[#A90F59] transition-all"
                >
                  Ouvrir le document PDF
                </a>
                <button
                  type="button"
                  onClick={() => setSelectedPdf(null)}
                  className="px-5 py-3 rounded-xl bg-white border border-[#EFE6EB] text-[#1E161D] text-xs font-bold"
                >
                  Fermer
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CommercialDashboardPage;
