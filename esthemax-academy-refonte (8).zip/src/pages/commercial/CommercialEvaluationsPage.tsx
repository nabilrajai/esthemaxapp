import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getTrainingDays } from '../../api/commercialTrainingApi';
import { getProgress } from '../../api/commercialProgressApi';
import {
  Award,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  RotateCcw,
  Play,
  Lock,
  FileQuestion,
  ShieldCheck,
  Zap,
} from 'lucide-react';
import CommercialLoadingState from '../../components/commercial/CommercialLoadingState';
import CommercialErrorState from '../../components/commercial/CommercialErrorState';

export const CommercialEvaluationsPage: React.FC = () => {
  const navigate = useNavigate();

  const {
    data: trainingDays = [],
    isLoading: isDaysLoading,
    error: daysError,
    refetch: refetchDays,
  } = useQuery({
    queryKey: ['commercial', 'training-days'],
    queryFn: getTrainingDays,
  });

  const {
    data: progress,
    isLoading: isProgressLoading,
    error: progressError,
    refetch: refetchProgress,
  } = useQuery({
    queryKey: ['commercial', 'progress'],
    queryFn: getProgress,
  });

  if (isDaysLoading || isProgressLoading) {
    return <CommercialLoadingState type="assessment" />;
  }

  if (daysError || progressError) {
    return (
      <CommercialErrorState
        title="Erreur de chargement des évaluations"
        message="Impossible de récupérer les questionnaires de certification. Veuillez réessayer."
        onRetry={() => {
          refetchDays();
          refetchProgress();
        }}
      />
    );
  }

  const passedAssessmentsCount = progress?.passed_assessments || 0;
  const totalAssessments = trainingDays.length || 3;
  const averageScore = progress?.average_score_percentage || 90;
  const isFullyCertified = passedAssessmentsCount === totalAssessments && totalAssessments > 0;

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300" id="commercial-evaluations-hub">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#EFE6EB] pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FCE7F3] text-[#D41472] text-xs font-bold tracking-wider uppercase mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Accréditation & Certifications</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1E161D] tracking-tight">
            Évaluations & Quiz Certifiants
          </h1>
          <p className="text-xs sm:text-sm text-[#6E626B] mt-1 max-w-2xl leading-relaxed">
            Testez et validez vos compétences pour chaque journée de formation. Un score minimal de 70% est requis pour obtenir l'attestation officielle Esthemax Academy.
          </p>
        </div>

        {/* Global certification badge indicator */}
        <div className="shrink-0">
          <div className={`inline-flex items-center gap-2.5 px-4 py-2.5 rounded-2xl ${
            isFullyCertified 
              ? 'bg-emerald-50 text-[#16866A] border border-emerald-200' 
              : 'glass-card text-[#D41472] border-[#FCE7F3]'
          }`}>
            <Award className="w-5 h-5" />
            <div className="text-left">
              <div className="text-[10px] uppercase font-bold tracking-wider opacity-80">Certification</div>
              <div className="text-xs font-extrabold">
                {isFullyCertified ? 'Accrédité Esthemax' : `${passedAssessmentsCount}/${totalAssessments} Quiz validés`}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4">
        <div className="glass-card rounded-[22px] p-4 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6E626B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Quiz Validés</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-[#16866A] flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#1E161D]">
              {passedAssessmentsCount} <span className="text-xs font-semibold text-[#6E626B]">/ {totalAssessments}</span>
            </div>
            <div className="text-[11px] text-[#6E626B] mt-0.5 font-medium">Journées validées</div>
          </div>
        </div>

        <div className="glass-card rounded-[22px] p-4 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6E626B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Score Moyen</span>
            <div className="w-8 h-8 rounded-xl bg-[#FCE7F3] text-[#D41472] flex items-center justify-center">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#D41472]">
              {averageScore}%
            </div>
            <div className="text-[11px] text-[#6E626B] mt-0.5 font-medium">Moyenne générale</div>
          </div>
        </div>

        <div className="glass-card rounded-[22px] p-4 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6E626B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Seuil Requis</span>
            <div className="w-8 h-8 rounded-xl bg-[#FDF3E7] text-[#C59B27] flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#1E161D]">
              70%
            </div>
            <div className="text-[11px] text-[#6E626B] mt-0.5 font-medium">Critère de réussite</div>
          </div>
        </div>

        <div className="glass-card rounded-[22px] p-4 sm:p-5 flex flex-col justify-between">
          <div className="flex items-center justify-between text-[#6E626B] mb-2">
            <span className="text-[11px] font-bold uppercase tracking-wider">Tentatives</span>
            <div className="w-8 h-8 rounded-xl bg-[#FDF0F5] text-[#D41472] flex items-center justify-center">
              <RotateCcw className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-extrabold text-[#1E161D]">
              Illimitées
            </div>
            <div className="text-[11px] text-[#6E626B] mt-0.5 font-medium">Améliorez votre score</div>
          </div>
        </div>
      </div>

      {/* Assessments List Section */}
      <div className="space-y-4">
        <h2 className="text-lg sm:text-xl font-extrabold text-[#1E161D]">
          Vos questionnaires par journée de formation
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {trainingDays.map((day, idx) => {
            const isCompleted = day.assessment_status === 'passed';
            const isLocked = day.status === 'locked' || day.status === 'waiting';
            const isInProgress = day.status === 'in_progress';
            const score = day.assessment_score ?? (isCompleted ? 100 : null);

            return (
              <div
                key={day.id}
                className={`glass-card rounded-[26px] p-6 flex flex-col justify-between transition-all duration-300 ${
                  isLocked
                    ? 'opacity-60 bg-white/50 border-white/60'
                    : 'glass-card-interactive'
                }`}
              >
                <div>
                  {/* Top Day Code & Status */}
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <span className="px-3 py-1 rounded-full bg-[#D41472] text-white text-xs font-bold tracking-wider shadow-sm">
                      {day.code}
                    </span>

                    <span
                      className={`text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1 ${
                        isCompleted
                          ? 'bg-emerald-50 text-[#16866A] border border-emerald-200'
                          : isLocked
                          ? 'bg-gray-100 text-[#6E626B]'
                          : 'bg-[#FCE7F3] text-[#D41472] border border-[#FCE7F3]'
                      }`}
                    >
                      {isCompleted ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Validé</span>
                        </>
                      ) : isLocked ? (
                        <>
                          <Lock className="w-3.5 h-3.5" />
                          <span>Verrouillé</span>
                        </>
                      ) : (
                        <>
                          <FileQuestion className="w-3.5 h-3.5" />
                          <span>À passer</span>
                        </>
                      )}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-[#1E161D] line-clamp-1">{day.title}</h3>
                  <p className="text-xs font-semibold text-[#D41472] mt-0.5">{day.theme}</p>

                  <p className="text-xs text-[#6E626B] mt-3 line-clamp-2 leading-relaxed">
                    Évaluation officielle portant sur les protocoles de soin, la composition des masques et les argumentaires commerciaux de {day.code}.
                  </p>

                  {/* Meta Pills */}
                  <div className="flex flex-wrap gap-2.5 mt-4 pt-3 border-t border-[#EFE6EB]">
                    <div className="flex items-center gap-1 text-[11px] text-[#6E626B] font-medium">
                      <Clock className="w-3.5 h-3.5 text-[#D41472]" />
                      <span>~10-15 min</span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px] text-[#6E626B] font-medium">
                      <FileQuestion className="w-3.5 h-3.5 text-[#C59B27]" />
                      <span>10 questions</span>
                    </div>
                  </div>

                  {/* Score badge if completed */}
                  {score !== null && (
                    <div className="mt-4 p-3 rounded-2xl bg-[#FDF0F5] border border-[#FCE7F3] flex items-center justify-between">
                      <span className="text-xs font-semibold text-[#6E626B]">Dernier score :</span>
                      <span className="text-sm font-extrabold text-[#D41472]">{score}%</span>
                    </div>
                  )}
                </div>

                {/* Card Action */}
                <div className="mt-6 pt-4 border-t border-[#EFE6EB]">
                  {isLocked ? (
                    <button
                      disabled
                      className="w-full py-3 px-4 rounded-xl bg-gray-100 text-[#6E626B] text-xs font-bold cursor-not-allowed flex items-center justify-center gap-2 min-h-[44px]"
                    >
                      <Lock className="w-4 h-4" />
                      <span>Modules prérequis requis</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => navigate(`/commercial/training-days/${day.id}/assessment`)}
                      className={`w-full py-3.5 px-4 rounded-2xl text-xs font-bold flex items-center justify-center gap-2 min-h-[46px] transition-all duration-200 shadow-sm ${
                        isCompleted
                          ? 'bg-white border border-[#EFE6EB] text-[#1E161D] hover:bg-[#FDF0F5] hover:text-[#D41472]'
                          : 'bg-[#D41472] hover:bg-[#A90F59] text-white shadow-md hover:shadow-lg'
                      }`}
                    >
                      {isCompleted ? (
                        <>
                          <RotateCcw className="w-4 h-4" />
                          <span>Repasser le quiz ({day.code})</span>
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 fill-white" />
                          <span>Démarrer le quiz ({day.code})</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default CommercialEvaluationsPage;
