import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { getModuleById, completeModule } from '../../api/commercialTrainingApi';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  Clock,
  BookOpen,
  Sparkles,
  FileQuestion,
  Share2,
  Bookmark,
  Check,
} from 'lucide-react';
import CommercialLoadingState from '../../components/commercial/CommercialLoadingState';
import CommercialErrorState from '../../components/commercial/CommercialErrorState';
import CommercialTextBlock from '../../components/commercial/content/CommercialTextBlock';
import CommercialImageBlock from '../../components/commercial/content/CommercialImageBlock';
import CommercialVideoBlock from '../../components/commercial/content/CommercialVideoBlock';
import CommercialCalloutBlock from '../../components/commercial/content/CommercialCalloutBlock';
import CommercialProductCard from '../../components/commercial/content/CommercialProductCard';
import CommercialDocumentBlock from '../../components/commercial/content/CommercialDocumentBlock';

export const CommercialModuleViewerPage: React.FC = () => {
  const { trainingDayId, moduleId } = useParams<{
    trainingDayId: string;
    moduleId: string;
  }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [savedLocally, setSavedLocally] = useState(false);

  // Fetch module content
  const {
    data: moduleData,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ['commercial', 'module', moduleId],
    queryFn: () => getModuleById(moduleId!),
    enabled: !!moduleId,
  });

  // Complete module mutation
  const completeMutation = useMutation({
    mutationFn: () => completeModule(moduleId!),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['commercial'] });
    },
  });

  if (isLoading) {
    return <CommercialLoadingState type="module-viewer" />;
  }

  if (error || !moduleData) {
    return (
      <CommercialErrorState
        title="Impossible de charger le module"
        message="Le contenu pédagogique n'a pas pu être chargé. Veuillez réessayer."
        onRetry={() => refetch()}
      />
    );
  }

  const isCompleted = moduleData.is_completed || completeMutation.isSuccess;
  const blocks = moduleData.content_blocks || [];

  const handleToggleComplete = () => {
    if (!isCompleted) {
      completeMutation.mutate();
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 sm:space-y-8 animate-in fade-in duration-300 pb-24" id="commercial-module-viewer">
      {/* Top Glass Navigation Bar */}
      <div className="sticky top-14 lg:top-4 z-30 flex items-center justify-between gap-3 p-3 rounded-2xl glass-card backdrop-blur-xl border border-white/90 shadow-sm">
        <button
          type="button"
          onClick={() => navigate(`/commercial/training-days/${trainingDayId}`)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl hover:bg-black/5 text-xs font-bold text-[#1E161D] transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-[#D41472]" />
          <span>Retour à la journée</span>
        </button>

        <div className="flex items-center gap-2">
          {moduleData.estimated_read_minutes && (
            <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-[#6E626B] bg-[#FAF7F5] px-2.5 py-1 rounded-full border border-[#EFE6EB]">
              <Clock className="w-3 h-3 text-[#D41472]" />
              <span>{moduleData.estimated_read_minutes} min</span>
            </span>
          )}

          <button
            type="button"
            onClick={() => setSavedLocally(!savedLocally)}
            className={`p-2 rounded-xl transition-colors ${
              savedLocally ? 'bg-[#FCE7F3] text-[#D41472]' : 'hover:bg-black/5 text-[#6E626B]'
            }`}
            title="Enregistrer pour plus tard"
          >
            <Bookmark className={`w-4 h-4 ${savedLocally ? 'fill-[#D41472]' : ''}`} />
          </button>
        </div>
      </div>

      {/* Module Title Header Card */}
      <div className="glass-card rounded-[32px] p-6 sm:p-10 shadow-md border border-white/90 space-y-4">
        <div className="flex items-center gap-2">
          <span className="px-3 py-1 rounded-full bg-[#FCE7F3] text-[#D41472] text-xs font-black tracking-wider uppercase">
            Module de Formation
          </span>
          {isCompleted && (
            <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-emerald-50 text-[#16866A] text-xs font-bold border border-emerald-200">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Validé</span>
            </span>
          )}
        </div>

        <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#1E161D] tracking-tight leading-tight">
          {moduleData.title}
        </h1>

        {moduleData.summary && (
          <p className="text-sm sm:text-base text-[#6E626B] leading-relaxed border-l-2 border-[#D41472] pl-4">
            {moduleData.summary}
          </p>
        )}
      </div>

      {/* Content Blocks List */}
      <div className="space-y-6">
        {blocks.map((block) => {
          switch (block.type) {
            case 'text':
              return <CommercialTextBlock key={block.id} block={block} />;
            case 'image':
              return <CommercialImageBlock key={block.id} block={block} />;
            case 'video':
              return <CommercialVideoBlock key={block.id} block={block} />;
            case 'callout':
              return <CommercialCalloutBlock key={block.id} block={block} />;
            case 'product_card':
              return <CommercialProductCard key={block.id} block={block} />;
            case 'document':
              return <CommercialDocumentBlock key={block.id} block={block} />;
            default:
              return null;
          }
        })}
      </div>

      {/* Floating Bottom Action Bar */}
      <div className="fixed bottom-20 lg:bottom-6 left-0 right-0 z-40 pointer-events-none px-4">
        <div className="pointer-events-auto max-w-2xl mx-auto glass-dock rounded-[28px] p-3 shadow-2xl border border-white/90 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleToggleComplete}
            disabled={completeMutation.isPending}
            className={`flex-1 py-3 px-4 rounded-2xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 transition-all duration-200 min-h-[46px] shadow-sm active:scale-95 ${
              isCompleted
                ? 'bg-emerald-50 border border-emerald-200 text-[#16866A]'
                : 'bg-[#D41472] hover:bg-[#A90F59] text-white'
            }`}
          >
            {isCompleted ? (
              <>
                <Check className="w-4 h-4 stroke-[3]" />
                <span>Module validé</span>
              </>
            ) : completeMutation.isPending ? (
              <span>Enregistrement...</span>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Marquer comme terminé</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => navigate(`/commercial/training-days/${trainingDayId}`)}
            className="py-3 px-5 rounded-2xl glass-card hover:bg-white text-[#1E161D] text-xs sm:text-sm font-extrabold flex items-center justify-center gap-1.5 transition-all min-h-[46px]"
          >
            <span>Sommaire</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default CommercialModuleViewerPage;
