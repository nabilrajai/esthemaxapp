import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import {
  User as UserIcon,
  Mail,
  Phone,
  MapPin,
  Building,
  Award,
  LogOut,
  Bell,
  Lock,
  ChevronRight,
  ShieldCheck,
  Sparkles,
  HelpCircle,
  FileText,
  CheckCircle2,
  X,
  Save,
} from 'lucide-react';

export const CommercialProfilePage: React.FC = () => {
  const { user, logout, updateProfile } = useAuth();
  const navigate = useNavigate();

  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [isHelpModalOpen, setIsHelpModalOpen] = useState(false);
  const [isLogoutDialogOpen, setIsLogoutDialogOpen] = useState(false);

  // Edit form state
  const [name, setName] = useState(user?.name || '');
  const [phone, setPhone] = useState(user?.phone || '+33 6 12 34 56 78');
  const [region, setRegion] = useState(user?.region || 'Île-de-France & Nord');
  const [sector, setSector] = useState(user?.sector || 'Instituts & Spas Premium');

  // Password form state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [passwordSuccess, setPasswordSuccess] = useState(false);

  // Notification toggles
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifWeekly, setNotifWeekly] = useState(true);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (updateProfile) {
      await updateProfile({
        name,
        phone,
        region,
        sector,
      });
    }
    setIsEditModalOpen(false);
  };

  const handleSavePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordSuccess(true);
    setTimeout(() => {
      setPasswordSuccess(false);
      setIsPasswordModalOpen(false);
      setCurrentPassword('');
      setNewPassword('');
    }, 1500);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6 sm:space-y-8 animate-in fade-in duration-300 pb-20" id="commercial-profile-view">
      {/* Identity Card (Mobile-App Style) */}
      <div className="glass-card rounded-[32px] p-6 sm:p-8 shadow-lg border border-white/90 text-center sm:text-left flex flex-col sm:flex-row items-center gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-40 h-40 bg-[#FCE7F3]/50 rounded-full blur-2xl pointer-events-none" />

        <div className="relative">
          <div
            className="w-20 h-20 sm:w-24 sm:h-24 rounded-[28px] text-white font-black text-2xl sm:text-3xl flex items-center justify-center shadow-xl ring-4 ring-white"
            style={{ backgroundColor: '#D41472' }}
          >
            {user?.name?.charAt(0) || 'C'}
          </div>
          <span className="absolute bottom-0 right-0 w-6 h-6 rounded-full bg-emerald-500 ring-2 ring-white flex items-center justify-center text-white text-[10px]">
            ✓
          </span>
        </div>

        <div className="space-y-1.5 flex-1">
          <div className="inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-[#FCE7F3] text-[#D41472] text-[10px] font-extrabold uppercase tracking-wider">
            <Sparkles className="w-3 h-3" />
            <span>Délégué Commercial Esthemax</span>
          </div>

          <h1 className="text-xl sm:text-2xl font-black text-[#1E161D]">
            {user?.name || 'Commercial Esthemax'}
          </h1>

          <p className="text-xs text-[#6E626B] font-semibold">{user?.email}</p>

          <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1 text-xs text-[#6E626B]">
            <span className="glass-card px-2.5 py-1 rounded-full text-[11px] font-bold">
              {region}
            </span>
            <span className="glass-card px-2.5 py-1 rounded-full text-[11px] font-bold">
              {sector}
            </span>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setIsEditModalOpen(true)}
          className="px-4 py-2.5 rounded-2xl glass-card hover:bg-white text-xs font-black text-[#1E161D] border border-white/90 shadow-2xs hover:shadow-xs transition-all"
        >
          Modifier
        </button>
      </div>

      {/* Quick Metrics Row */}
      <div className="grid grid-cols-3 gap-3">
        <div className="glass-card rounded-[22px] p-4 text-center">
          <div className="text-xl sm:text-2xl font-black text-[#D41472]">3 / 3</div>
          <div className="text-[10px] sm:text-[11px] font-bold text-[#6E626B] mt-0.5">Certifications</div>
        </div>
        <div className="glass-card rounded-[22px] p-4 text-center">
          <div className="text-xl sm:text-2xl font-black text-[#1E161D]">12</div>
          <div className="text-[10px] sm:text-[11px] font-bold text-[#6E626B] mt-0.5">Modules Validés</div>
        </div>
        <div className="glass-card rounded-[22px] p-4 text-center">
          <div className="text-xl sm:text-2xl font-black text-[#C59B27]">92%</div>
          <div className="text-[10px] sm:text-[11px] font-bold text-[#6E626B] mt-0.5">Score Moyen</div>
        </div>
      </div>

      {/* Settings Navigation Groups */}
      <div className="space-y-4">
        <h2 className="text-sm font-extrabold uppercase tracking-wider text-[#6E626B] px-1">
          Paramètres du compte
        </h2>

        <div className="glass-card rounded-[28px] divide-y divide-[#EFE6EB] overflow-hidden">
          {/* Item 1: Edit Profile */}
          <div
            onClick={() => setIsEditModalOpen(true)}
            className="p-4 sm:p-5 flex items-center justify-between cursor-pointer hover:bg-white/60 transition-colors"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-[#FCE7F3] text-[#D41472] flex items-center justify-center">
                <UserIcon className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-black text-[#1E161D]">Informations personnelles</h3>
                <p className="text-[11px] text-[#6E626B]">Nom, téléphone, région et secteur</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6E626B]" />
          </div>

          {/* Item 2: Password */}
          <div
            onClick={() => setIsPasswordModalOpen(true)}
            className="p-4 sm:p-5 flex items-center justify-between cursor-pointer hover:bg-white/60 transition-colors"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-[#FDF3E7] text-[#C59B27] flex items-center justify-center">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-black text-[#1E161D]">Sécurité & Mot de passe</h3>
                <p className="text-[11px] text-[#6E626B]">Modifier vos accès de connexion</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6E626B]" />
          </div>

          {/* Item 3: Notifications toggles */}
          <div className="p-4 sm:p-5 flex items-center justify-between">
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-[#FDF0F5] text-[#D41472] flex items-center justify-center">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-black text-[#1E161D]">Alertes & Rappels de formation</h3>
                <p className="text-[11px] text-[#6E626B]">Recevoir les notifications de nouveaux modules</p>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={notifEmail}
                onChange={() => setNotifEmail(!notifEmail)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#D41472]" />
            </label>
          </div>

          {/* Item 4: Support */}
          <div
            onClick={() => setIsHelpModalOpen(true)}
            className="p-4 sm:p-5 flex items-center justify-between cursor-pointer hover:bg-white/60 transition-colors"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-[#16866A] flex items-center justify-center">
                <HelpCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs sm:text-sm font-black text-[#1E161D]">Centre d'Aide & Support</h3>
                <p className="text-[11px] text-[#6E626B]">Assistance pédagogique & Hotline Esthemax</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-[#6E626B]" />
          </div>
        </div>
      </div>

      {/* Logout Action */}
      <div className="pt-2">
        <button
          type="button"
          onClick={() => setIsLogoutDialogOpen(true)}
          className="w-full p-4 rounded-[24px] glass-card text-[#C2415D] hover:bg-rose-50/60 text-xs sm:text-sm font-black flex items-center justify-center gap-2 border border-rose-100 transition-all min-h-[48px]"
        >
          <LogOut className="w-4 h-4" />
          <span>Se déconnecter</span>
        </button>
      </div>

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-lg glass-card rounded-[32px] p-6 sm:p-8 shadow-2xl border border-white/90 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-[#EFE6EB]">
              <h3 className="text-base sm:text-lg font-black text-[#1E161D]">Modifier mes coordonnées</h3>
              <button
                type="button"
                onClick={() => setIsEditModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-black/5 text-[#6E626B]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4 pt-4">
              <div>
                <label className="block text-xs font-bold text-[#6E626B] mb-1">Nom complet</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl glass-card text-xs sm:text-sm focus:outline-none focus:border-[#D41472]"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#6E626B] mb-1">Numéro de téléphone</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl glass-card text-xs sm:text-sm focus:outline-none focus:border-[#D41472]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#6E626B] mb-1">Région commerciale</label>
                <input
                  type="text"
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl glass-card text-xs sm:text-sm focus:outline-none focus:border-[#D41472]"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-[#6E626B] mb-1">Secteur d'activité</label>
                <input
                  type="text"
                  value={sector}
                  onChange={(e) => setSector(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl glass-card text-xs sm:text-sm focus:outline-none focus:border-[#D41472]"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-4 border-t border-[#EFE6EB]">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl glass-card text-xs font-bold"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-[#D41472] hover:bg-[#A90F59] text-white text-xs font-black shadow-md"
                >
                  Enregistrer
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Password Modal */}
      {isPasswordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md glass-card rounded-[32px] p-6 sm:p-8 shadow-2xl border border-white/90 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-[#EFE6EB]">
              <h3 className="text-base sm:text-lg font-black text-[#1E161D]">Changer de mot de passe</h3>
              <button
                type="button"
                onClick={() => setIsPasswordModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-black/5 text-[#6E626B]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {passwordSuccess ? (
              <div className="py-8 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-[#16866A] mx-auto" />
                <h4 className="text-sm font-black text-[#1E161D]">Mot de passe mis à jour !</h4>
              </div>
            ) : (
              <form onSubmit={handleSavePassword} className="space-y-4 pt-4">
                <div>
                  <label className="block text-xs font-bold text-[#6E626B] mb-1">Mot de passe actuel</label>
                  <input
                    type="password"
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl glass-card text-xs sm:text-sm focus:outline-none focus:border-[#D41472]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#6E626B] mb-1">Nouveau mot de passe</label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl glass-card text-xs sm:text-sm focus:outline-none focus:border-[#D41472]"
                    required
                    minLength={6}
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-4 border-t border-[#EFE6EB]">
                  <button
                    type="button"
                    onClick={() => setIsPasswordModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl glass-card text-xs font-bold"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-xl bg-[#D41472] hover:bg-[#A90F59] text-white text-xs font-black shadow-md"
                  >
                    Mettre à jour
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Support / Help Modal */}
      {isHelpModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-lg glass-card rounded-[32px] p-6 sm:p-8 shadow-2xl border border-white/90 animate-in zoom-in-95 duration-200 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#EFE6EB]">
              <div className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-[#D41472]" />
                <h3 className="text-base font-black text-[#1E161D]">Support Commercial Esthemax</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsHelpModalOpen(false)}
                className="p-1.5 rounded-full hover:bg-black/5 text-[#6E626B]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 py-2 text-xs sm:text-sm text-[#6E626B]">
              <p>
                Vous avez une question sur un protocole cabine, un ingrédient ou une grille tarifaire ? Nos formateurs sont à votre écoute :
              </p>

              <div className="p-4 rounded-2xl bg-white/80 border border-white space-y-2">
                <div className="flex items-center gap-2 font-bold text-[#1E161D]">
                  <Mail className="w-4 h-4 text-[#D41472]" />
                  <span>academy@esthemax.com</span>
                </div>
                <div className="flex items-center gap-2 font-bold text-[#1E161D]">
                  <Phone className="w-4 h-4 text-[#D41472]" />
                  <span>+33 1 89 71 00 00 (Lundi au Vendredi, 9h-18h)</span>
                </div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setIsHelpModalOpen(false)}
              className="w-full py-2.5 rounded-xl bg-[#D41472] text-white text-xs font-bold"
            >
              Fermer
            </button>
          </div>
        </div>
      )}

      {/* Logout Confirmation Dialog */}
      {isLogoutDialogOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-sm glass-card rounded-[32px] p-6 shadow-2xl border border-white/90 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-[#C2415D] flex items-center justify-center mx-auto">
              <LogOut className="w-6 h-6" />
            </div>
            <h3 className="text-base font-black text-[#1E161D]">Confirmer la déconnexion ?</h3>
            <p className="text-xs text-[#6E626B]">
              Votre progression sera automatiquement enregistrée sur votre compte.
            </p>
            <div className="flex items-center gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setIsLogoutDialogOpen(false)}
                className="flex-1 py-2.5 rounded-xl glass-card text-xs font-bold"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={handleLogout}
                className="flex-1 py-2.5 rounded-xl bg-[#C2415D] hover:bg-rose-700 text-white text-xs font-black shadow-md"
              >
                Déconnexion
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CommercialProfilePage;
