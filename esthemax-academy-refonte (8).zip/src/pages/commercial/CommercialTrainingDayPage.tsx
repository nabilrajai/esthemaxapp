import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { getTrainingDayById } from '../../api/commercialTrainingApi';
import {
  ArrowLeft,
  BookOpen,
  Clock,
  CheckCircle2,
  FileQuestion,
  Lock,
  Play,
  Sparkles,
  ChevronRight,
  Award,
  Layers,
  Code,
} from 'lucide-react';
import CommercialLoadingState from '../../components/commercial/CommercialLoadingState';
import CommercialErrorState from '../../components/commercial/CommercialErrorState';
import CommercialCodeProjectViewer from '../../components/commercial/content/CommercialCodeProjectViewer';

export const CommercialTrainingDayPage: React.FC = () => {
  const { trainingDayId } = useParams<{ trainingDayId: string }>();
  const navigate = useNavigate();

  const {
    data: trainingDay,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ['commercial', 'training-day', trainingDayId],
    queryFn: () => getTrainingDayById(trainingDayId!),
    enabled: !!trainingDayId,
  });

  if (isLoading) {
    return <CommercialLoadingState type="training-day" />;
  }

  if (error || !trainingDay) {
    return (
      <CommercialErrorState
        title="Journée de formation introuvable"
        message="Impossible de charger le contenu de cette session. Veuillez vérifier votre accès."
        onRetry={() => refetch()}
      />
    );
  }

  const modules = (trainingDay as any).modules || [];
  const isLocked = trainingDay.status === 'locked' || trainingDay.status === 'waiting';
  const progressPercent = trainingDay.progress_percentage || 0;
  const isCompleted = trainingDay.status === 'completed';

  // Find next module to continue
  const nextModule = modules.find((m: any) => !m.is_completed) || modules[0];

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300" id="commercial-training-day-view">
      {/* Top Mobile Bar Navigation / Back Button */}
      <div className="flex items-center justify-between gap-3">
        <button
          type="button"
          onClick={() => navigate('/commercial/training-days')}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card hover:bg-white text-xs font-bold text-[#1E161D] transition-all"
        >
          <ArrowLeft className="w-4 h-4 text-[#D41472]" />
          <span>Toutes les formations</span>
        </button>

        <span className="text-xs font-extrabold px-3 py-1 rounded-full bg-[#FCE7F3] text-[#D41472]">
          {trainingDay.code}
        </span>
      </div>

      {/* Main Glass Header Card */}
      <div className="relative overflow-hidden rounded-[28px] sm:rounded-[32px] glass-card p-6 sm:p-8 lg:p-10 shadow-lg border border-white/90">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#D41472] text-white text-xs font-black tracking-wider uppercase shadow-xs">
              <span>Journée {trainingDay.code}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#1E161D] tracking-tight">
              {trainingDay.title}
            </h1>

            <div className="text-sm sm:text-base font-bold text-[#D41472]">
              {trainingDay.theme}
            </div>

            <p className="text-xs sm:text-sm text-[#6E626B] leading-relaxed">
              {trainingDay.description ||
                'Explorez les protocoles, les actifs clés et maîtrisez le discours commercial auprès de vos clients instituts.'}
            </p>

            {/* Quick badges row */}
            <div className="flex flex-wrap items-center gap-3 pt-2 text-xs font-bold text-[#6E626B]">
              <span className="flex items-center gap-1.5 glass-card px-3 py-1.5 rounded-full">
                <BookOpen className="w-4 h-4 text-[#D41472]" />
                <span>{modules.length} modules théoriques & pratiques</span>
              </span>
              <span className="flex items-center gap-1.5 glass-card px-3 py-1.5 rounded-full">
                <Clock className="w-4 h-4 text-[#C59B27]" />
                <span>{trainingDay.estimated_duration_minutes || 45} min estimées</span>
              </span>
              {(trainingDay as any).formation_url && (
                <a
                  href={(trainingDay as any).formation_url}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#D41472] text-white hover:bg-[#A90F59]"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Ouvrir la formation {trainingDay.code}</span>
                </a>
              )}
            </div>
          </div>

          {/* Progress gauge */}
          <div className="shrink-0 p-5 rounded-[24px] bg-[#FAF7F5] border border-[#EFE6EB] flex flex-col items-center justify-center text-center min-w-[180px]">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-[#6E626B] mb-1">
              Progression J{trainingDay.code.replace('J', '')}
            </span>
            <div className="text-3xl sm:text-4xl font-black text-[#D41472]">
              {progressPercent}%
            </div>
            <div className="w-full h-2 bg-gray-200 rounded-full mt-3 overflow-hidden">
              <div
                className="h-full bg-[#D41472] rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="text-[11px] text-[#6E626B] mt-2 font-semibold">
              {modules.filter((m: any) => m.is_completed).length} / {modules.length} complétés
            </span>
          </div>
        </div>
      </div>

      {/* Modules List Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg sm:text-xl font-black text-[#1E161D]">
              Modules d'apprentissage
            </h2>
            <p className="text-xs text-[#6E626B]">Suivez les modules dans l'ordre recommandé</p>
          </div>
        </div>

        <div className="space-y-3.5">
          {modules.map((module: any, index: number) => {
            const isModCompleted = module.is_completed;

            return (
              <div
                key={module.id}
                onClick={() =>
                  navigate(`/commercial/training-days/${trainingDay.id}/modules/${module.id}`)
                }
                className={`glass-card-interactive rounded-[24px] p-5 cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all duration-200 ${
                  isModCompleted ? 'bg-white/90' : ''
                }`}
              >
                <div className="flex items-start sm:items-center gap-3.5">
                  {/* Step Index Badge */}
                  <div
                    className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 font-extrabold text-sm ${
                      isModCompleted
                        ? 'bg-emerald-50 text-[#16866A] border border-emerald-200'
                        : 'bg-[#FCE7F3] text-[#D41472]'
                    }`}
                  >
                    {isModCompleted ? (
                      <CheckCircle2 className="w-5 h-5" />
                    ) : (
                      <span>{index + 1}</span>
                    )}
                  </div>

                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#D41472]">
                        Module {index + 1}
                      </span>
                      {module.estimated_read_minutes && (
                        <span className="text-[10px] text-[#6E626B]">
                          • {module.estimated_read_minutes} min
                        </span>
                      )}
                    </div>
                    <h3 className="text-base font-bold text-[#1E161D]">{module.title}</h3>
                    {module.summary && (
                      <p className="text-xs text-[#6E626B] line-clamp-1">{module.summary}</p>
                    )}
                  </div>
                </div>

                <div className="shrink-0 flex items-center justify-end">
                  <button
                    type="button"
                    className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors min-h-[40px] ${
                      isModCompleted
                        ? 'bg-gray-100 text-[#1E161D] hover:bg-gray-200'
                        : 'bg-[#D41472] text-white hover:bg-[#A90F59] shadow-xs'
                    }`}
                  >
                    {isModCompleted ? (
                      <>
                        <span>Revoir</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-white" />
                        <span>Commencer</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Code Project / Ateliers Cabine if available */}
      {trainingDay.code_project && (
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Code className="w-5 h-5 text-[#D41472]" />
            <h2 className="text-lg sm:text-xl font-black text-[#1E161D]">
              Atelier Interactif & Simulation Cabine
            </h2>
          </div>
          <CommercialCodeProjectViewer project={trainingDay.code_project} />
        </div>
      )}

      {/* Assessment / Quiz Validation Section */}
      <div className="glass-card rounded-[28px] p-6 sm:p-8 border-[#FCE7F3] shadow-md bg-gradient-to-br from-white via-white to-[#FDF0F5]">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FDF3E7] text-[#C59B27] text-xs font-bold uppercase tracking-wider">
              <Award className="w-3.5 h-3.5" />
              <span>Validation des acquis</span>
            </div>

            <h3 className="text-xl sm:text-2xl font-black text-[#1E161D]">
              Quiz de Certification {trainingDay.code}
            </h3>

            <p className="text-xs sm:text-sm text-[#6E626B] leading-relaxed">
              Pour valider officiellement cette journée, complétez le quiz de fin de session. Un score d’au moins 70% est requis.
            </p>

            {trainingDay.assessment_score !== undefined && trainingDay.assessment_score !== null && (
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-50 text-[#16866A] text-xs font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Dernier score obtenu : {trainingDay.assessment_score}%</span>
              </div>
            )}
          </div>

          <div className="shrink-0">
            <button
              type="button"
              disabled={isLocked}
              onClick={() => navigate(`/commercial/training-days/${trainingDay.id}/assessment`)}
              className={`w-full sm:w-auto px-6 py-3.5 rounded-2xl text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 min-h-[48px] shadow-md transition-all active:scale-95 ${
                trainingDay.assessment_status === 'passed'
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                  : 'bg-[#D41472] hover:bg-[#A90F59] text-white'
              }`}
            >
              {trainingDay.assessment_status === 'passed' ? (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Quiz validé (Repasser)</span>
                </>
              ) : (
                <>
                  <FileQuestion className="w-4 h-4" />
                  <span>Démarrer le quiz ({trainingDay.code})</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommercialTrainingDayPage;
