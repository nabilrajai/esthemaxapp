import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { getTrainingDays } from '../../api/commercialTrainingApi';
import {
  Clock,
  BookOpen,
  Lock,
  ArrowRight,
  CheckCircle2,
  FileQuestion,
  Sparkles,
  Search,
  ChevronRight,
  Filter,
  Play,
  Award,
} from 'lucide-react';
import CommercialLoadingState from '../../components/commercial/CommercialLoadingState';
import CommercialErrorState from '../../components/commercial/CommercialErrorState';
import CommercialEmptyState from '../../components/commercial/CommercialEmptyState';

export const CommercialTrainingDaysPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'in_progress' | 'completed' | 'available'>('all');

  const {
    data: trainingDays,
    isLoading,
    error,
    refetch,
  } = useQuery({
    queryKey: ['commercial', 'training-days'],
    queryFn: getTrainingDays,
  });

  const days = useMemo(() => trainingDays || [], [trainingDays]);

  // Filter and search logic
  const filteredDays = useMemo(() => {
    return days.filter((day) => {
      // Filter tab
      if (selectedFilter === 'in_progress' && day.status !== 'in_progress') return false;
      if (selectedFilter === 'completed' && day.status !== 'completed') return false;
      if (selectedFilter === 'available' && day.status !== 'available') return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = day.title.toLowerCase().includes(q);
        const matchesTheme = day.theme?.toLowerCase().includes(q);
        const matchesCode = day.code?.toLowerCase().includes(q);
        const matchesDesc = day.description?.toLowerCase().includes(q);
        return matchesTitle || matchesTheme || matchesCode || matchesDesc;
      }

      return true;
    });
  }, [days, selectedFilter, searchQuery]);

  if (isLoading) {
    return <CommercialLoadingState type="training-days" />;
  }

  if (error) {
    return (
      <CommercialErrorState
        title="Erreur de chargement des journées de formation"
        message="Impossible de récupérer le catalogue des formations Esthemax. Veuillez vérifier votre connexion."
        onRetry={() => refetch()}
      />
    );
  }

  if (days.length === 0) {
    return (
      <CommercialEmptyState
        type="training-days"
        title="Aucune formation disponible"
        description="Vous n'avez actuellement aucune session de formation attribuée. Veuillez contacter votre responsable."
      />
    );
  }

  // Cover gradient banners per day code
  const getBannerGradient = (code: string) => {
    switch (code) {
      case 'J1':
        return 'from-[#D41472] to-[#A90F59]';
      case 'J2':
        return 'from-[#7E0A42] to-[#D41472]';
      case 'J3':
        return 'from-[#4A0E4E] to-[#A90F59]';
      default:
        return 'from-[#D41472] to-[#A90F59]';
    }
  };

  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300" id="commercial-training-days-view">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-[#EFE6EB] pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FCE7F3] text-[#D41472] text-xs font-bold tracking-wider uppercase mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Catalogue Officiel des Formations</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#1E161D] tracking-tight">
            Journées de Formation
          </h1>
          <p className="text-xs sm:text-sm text-[#6E626B] mt-1 max-w-2xl leading-relaxed">
            Maîtrisez la science des électrolytes, les masques Hydrojelly® et les techniques de closing cabine pour conseiller les instituts partenaires.
          </p>
        </div>

        {/* Global count pill */}
        <div className="shrink-0 text-xs font-bold text-[#6E626B] glass-card px-4 py-2 rounded-2xl">
          <span className="text-[#D41472] font-black">{days.filter(d => d.status === 'completed').length}</span> sur {days.length} formations certifiées
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="space-y-3 sm:space-y-0 sm:flex sm:items-center sm:justify-between gap-4">
        {/* Search Pill */}
        <div className="relative flex-1 max-w-md">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#6E626B]">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher une journée, un produit ou un thème..."
            className="w-full pl-10 pr-4 py-2.5 rounded-full glass-card text-xs sm:text-sm text-[#1E161D] placeholder-gray-400 focus:outline-none focus:border-[#D41472] focus:ring-2 focus:ring-[#D41472]/15 transition-all"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-[#6E626B] hover:text-[#1E161D] text-xs"
            >
              Effacer
            </button>
          )}
        </div>

        {/* Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          {[
            { key: 'all', label: 'Toutes' },
            { key: 'in_progress', label: 'En cours' },
            { key: 'available', label: 'À commencer' },
            { key: 'completed', label: 'Terminées' },
          ].map((tab) => (
            <button
              key={tab.key}
              type="button"
              onClick={() => setSelectedFilter(tab.key as any)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-bold whitespace-nowrap transition-all duration-200 ${
                selectedFilter === tab.key
                  ? 'bg-[#D41472] text-white shadow-xs'
                  : 'glass-card text-[#6E626B] hover:text-[#1E161D] hover:bg-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Training Days List / Grid */}
      {filteredDays.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
          {filteredDays.map((day) => {
            const isLocked = day.status === 'locked' || day.status === 'waiting';
            const isCompleted = day.status === 'completed';
            const isInProgress = day.status === 'in_progress';
            const isAvailable = day.status === 'available';

            return (
              <div
                key={day.id}
                className={`glass-card rounded-[28px] overflow-hidden flex flex-col justify-between transition-all duration-300 ${
                  isLocked
                    ? 'opacity-65 bg-white/50 border-white/60'
                    : 'glass-card-interactive'
                }`}
              >
                {/* Visual Top Banner */}
                <div className={`p-5 text-white bg-gradient-to-r ${getBannerGradient(day.code)} relative overflow-hidden`}>
                  <div className="absolute top-0 right-0 w-32 h-32 opacity-20 rounded-full bg-white blur-xl pointer-events-none" />

                  <div className="relative z-10 flex items-center justify-between gap-2">
                    <span className="px-3.5 py-1 rounded-full bg-white/20 backdrop-blur-md text-white text-xs font-black tracking-wider uppercase border border-white/30 shadow-xs">
                      {day.code}
                    </span>

                    <span
                      className={`text-[11px] font-extrabold px-3 py-0.5 rounded-full backdrop-blur-md ${
                        isCompleted
                          ? 'bg-emerald-500/90 text-white'
                          : isInProgress
                          ? 'bg-white text-[#D41472]'
                          : isLocked
                          ? 'bg-black/30 text-white/80'
                          : 'bg-white/90 text-[#1E161D]'
                      }`}
                    >
                      {isCompleted && 'Terminé'}
                      {isInProgress && 'En cours'}
                      {isAvailable && 'À commencer'}
                      {isLocked && 'Verrouillé'}
                    </span>
                  </div>

                  <div className="mt-4">
                    <h2 className="text-xl font-black text-white tracking-tight">{day.title}</h2>
                    <div className="text-xs font-semibold text-white/90 mt-0.5">{day.theme}</div>
                  </div>
                </div>

                {/* Card Body */}
                <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
                  <div>
                    <p className="text-xs sm:text-sm text-[#6E626B] leading-relaxed line-clamp-3">
                      {day.description || 'Apprenez les spécificités des masques et développez vos compétences commerciales.'}
                    </p>

                    {/* Meta Info Badges */}
                    <div className="flex flex-wrap items-center gap-3 mt-4 text-xs text-[#6E626B]">
                      <span className="flex items-center gap-1.5 font-bold">
                        <BookOpen className="w-3.5 h-3.5 text-[#D41472]" />
                        <span>{day.modules_count || 4} modules</span>
                      </span>

                      <span className="flex items-center gap-1.5 font-medium">
                        <Clock className="w-3.5 h-3.5 text-[#6E626B]" />
                        <span>{day.estimated_duration_minutes || 45} min</span>
                      </span>

                      {day.assessment_status && (
                        <span className="flex items-center gap-1.5 font-bold">
                          <FileQuestion className="w-3.5 h-3.5 text-[#C59B27]" />
                          <span>{day.assessment_status === 'passed' ? 'Quiz Validé' : 'Quiz Requis'}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Progress & Card Footer */}
                  <div className="pt-4 border-t border-[#EFE6EB] space-y-3">
                    <div className="flex items-center justify-between text-xs font-bold text-[#6E626B]">
                      <span>Progression</span>
                      <span className="text-[#D41472]">{day.progress_percentage || 0}%</span>
                    </div>

                    <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-[#D41472] rounded-full transition-all duration-500"
                        style={{ width: `${day.progress_percentage || 0}%` }}
                      />
                    </div>

                    <button
                      type="button"
                      disabled={isLocked}
                      onClick={() => navigate(`/commercial/training-days/${day.id}`)}
                      className={`w-full py-3 px-4 rounded-2xl text-xs font-black flex items-center justify-center gap-2 min-h-[44px] transition-all duration-200 active:scale-95 ${
                        isLocked
                          ? 'bg-gray-100 text-[#6E626B] cursor-not-allowed'
                          : isCompleted
                          ? 'bg-white border border-[#EFE6EB] text-[#1E161D] hover:bg-[#FAF7F5]'
                          : 'bg-[#D41472] hover:bg-[#A90F59] text-white shadow-md hover:shadow-lg'
                      }`}
                    >
                      {isLocked ? (
                        <>
                          <Lock className="w-4 h-4" />
                          <span>Journée Verrouillée</span>
                        </>
                      ) : isCompleted ? (
                        <>
                          <Award className="w-4 h-4 text-[#16866A]" />
                          <span>Revoir les modules</span>
                          <ChevronRight className="w-4 h-4 ml-auto" />
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 fill-white" />
                          <span>Accéder à la journée</span>
                          <ArrowRight className="w-4 h-4 ml-auto" />
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="p-10 text-center glass-card rounded-[32px] space-y-3">
          <Search className="w-8 h-8 text-[#6E626B] mx-auto opacity-50" />
          <h3 className="text-base font-extrabold text-[#1E161D]">Aucune formation trouvée</h3>
          <p className="text-xs text-[#6E626B] max-w-sm mx-auto">
            Aucun résultat ne correspond à votre filtre « {searchQuery || selectedFilter} ».
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setSelectedFilter('all');
            }}
            className="px-4 py-2 rounded-full bg-[#D41472] text-white text-xs font-bold shadow-xs"
          >
            Réinitialiser les filtres
          </button>
        </div>
      )}
    </div>
  );
};

export default CommercialTrainingDaysPage;
