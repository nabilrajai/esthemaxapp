/**
 * Esthemax Academy - Commercial Platform Type Definitions
 * All database identifiers are strictly UUID strings.
 */

export interface User {
  id: string; // UUID
  name: string;
  email: string;
  role: 'commercial' | 'admin';
  phone?: string | null;
  region?: string | null;
  sector?: string | null;
  avatar_url?: string | null;
  status: 'active' | 'blocked' | 'inactive';
  last_login_at?: string | null;
  created_at?: string;
}

export interface TrainingDay {
  id: string; // UUID - Never array index
  code: string; // e.g. "J1", "J2", "J3"
  title: string; // e.g. "Marque et Produits"
  theme: string; // e.g. "Univers Esthemax & Masques Hydrojelly"
  description?: string | null;
  status: 'available' | 'in_progress' | 'completed' | 'locked' | 'waiting' | 'closed' | 'needs_review';
  sort_order?: number;
  lock_reason?: string | null;
  modules_count?: number;
  completed_modules_count?: number;
  progress_percentage?: number;
  estimated_duration_minutes?: number;
  assessment_id?: string | null;
  assessment_status?: 'not_started' | 'passed' | 'failed' | 'pending' | 'locked';
  assessment_score?: number | null;
  code_project?: TrainingDayCodeProject | null;
}

export interface TrainingDayCodeProject {
  id: string;
  training_day_id: string;
  status: 'published' | 'draft' | 'archived';
  version?: string;
  html_code?: string;
  css_code?: string;
  js_code?: string;
  image_urls?: string[];
}

export interface ContentModule {
  id: string; // UUID
  training_day_id: string; // UUID
  title: string;
  summary?: string | null;
  sort_order: number;
  status: 'published' | 'draft' | 'archived';
  estimated_read_minutes?: number;
  is_completed?: boolean;
  viewed_at?: string | null;
  blocks_count?: number;
  content_blocks?: ContentBlock[];
}

export type ContentBlockType =
  | 'text'
  | 'image'
  | 'video'
  | 'callout'
  | 'product_card'
  | 'document';

export interface BaseContentBlock {
  id: string; // UUID
  module_id: string; // UUID
  sort_order: number;
  status: 'published' | 'draft' | 'archived';
  type: ContentBlockType;
}

export interface TextContentBlock extends BaseContentBlock {
  type: 'text';
  content: {
    html?: string;
    markdown?: string;
    text?: string;
  };
}

export interface ImageContentBlock extends BaseContentBlock {
  type: 'image';
  content: {
    url: string;
    alt?: string;
    caption?: string;
    aspect_ratio?: string;
  };
}

export interface VideoContentBlock extends BaseContentBlock {
  type: 'video';
  content: {
    url: string;
    provider?: 'youtube' | 'vimeo' | 'external';
    title?: string;
    duration_seconds?: number;
  };
}

export interface CalloutContentBlock extends BaseContentBlock {
  type: 'callout';
  content: {
    variant: 'info' | 'warning' | 'success' | 'tip' | 'note';
    title?: string;
    message: string;
  };
}

export interface ProductCardContentBlock extends BaseContentBlock {
  type: 'product_card';
  content: {
    product_name: string;
    tagline?: string;
    description: string;
    image_url?: string;
    pack_type?: string;
    benefits?: string[];
    skin_types?: string[];
    key_ingredients?: string[];
    recommended_usage?: string;
    price?: string | null; // only if approved
  };
}

export interface DocumentContentBlock extends BaseContentBlock {
  type: 'document';
  content: {
    title: string;
    file_name: string;
    preview_type: 'pdf_preview' | 'presentation_preview' | 'embedded';
    preview_url?: string;
    pages_count?: number;
  };
}

export type ContentBlock =
  | TextContentBlock
  | ImageContentBlock
  | VideoContentBlock
  | CalloutContentBlock
  | ProductCardContentBlock
  | DocumentContentBlock;

export interface Assessment {
  id: string; // UUID
  training_day_id: string; // UUID
  title: string;
  description?: string | null;
  passing_score_percentage: number;
  time_limit_minutes?: number | null;
  questions_count?: number;
  questions?: Question[];
  status: 'published' | 'draft' | 'archived';
}

export type QuestionType = 'single_choice' | 'multiple_choice' | 'free_text';

export interface QuestionOption {
  id: string; // UUID
  text: string;
  sort_order: number;
}

export interface Question {
  id: string; // UUID
  assessment_id: string; // UUID
  question_text: string;
  question_type: QuestionType;
  sort_order: number;
  is_required: boolean;
  explanation?: string | null;
  options?: QuestionOption[];
}

export interface AssessmentAttempt {
  id: string; // UUID
  assessment_id: string; // UUID
  training_day_id: string; // UUID
  user_id: string; // UUID
  status: 'in_progress' | 'submitted' | 'graded';
  score?: number | null;
  score_percentage?: number | null;
  passed?: boolean | null;
  started_at: string;
  submitted_at?: string | null;
  total_questions: number;
  answered_questions_count: number;
  answers: Record<string, string | string[]>; // question_id -> option_id or text
}

export interface AssessmentResult {
  attempt_id: string; // UUID
  assessment_id: string; // UUID
  training_day_id: string; // UUID
  score: number;
  score_percentage: number;
  passed: boolean;
  total_questions: number;
  correct_answers_count: number;
  passing_score_percentage: number;
  submitted_at: string;
  attempt_number: number;
  can_retry: boolean;
  message: string;
}

export type AssessmentAttemptResult = AssessmentResult;

export interface CommercialProgress {
  user_id: string;
  overall_progress_percentage: number;
  total_training_days: number;
  completed_training_days: number;
  total_modules: number;
  completed_modules: number;
  total_assessments: number;
  passed_assessments: number;
  average_score_percentage: number;
  last_activity_at?: string | null;
  current_training_day?: TrainingDay | null;
  last_viewed_module?: {
    id: string;
    title: string;
    training_day_id: string;
    training_day_title: string;
    viewed_at: string;
  } | null;
  days_progress: Array<{
    training_day_id: string;
    code: string;
    title: string;
    status: TrainingDay['status'];
    progress_percentage: number;
    completed_modules: number;
    total_modules: number;
    assessment_passed: boolean;
    assessment_score?: number | null;
    completed_at?: string | null;
  }>;
  training_days?: Array<{
    training_day_id: string;
    training_day_code: string;
    training_day_title: string;
    status: TrainingDay['status'];
    progress_percentage: number;
    completed_modules_count: number;
    total_modules_count: number;
    assessment_score_percentage?: number | null;
  }>;
  recent_activities: Array<{
    id: string;
    type: 'module_viewed' | 'training_day_started' | 'assessment_passed' | 'assessment_failed';
    title: string;
    timestamp: string;
    training_day_code: string;
  }>;
}

export interface ApiResponse<T> {
  data: T;
  message?: string;
  status?: string;
}
